/* =====================================================================
   Учебная практика ПМ.11, этап 2 — тестирование хранимых процедур
   Файл: realty_procedures_tests.sql
   СУБД: MySQL 8.0 (запускать в консоли mysql: source путь/к/файлу.sql)
   Запуск: после realty_procedures.sql, на базе с тестовыми данными этапа 1.

   Скрипт сам проверяет каждый сценарий и записывает результат в таблицу
   test_results со столбцом «Статус» (PASS / FAIL). Тестовые записи (клиенты,
   объекты, сделки) создаются по ходу и удаляются в конце, исходные данные
   этапа 1 не меняются. Журнал ошибок ErrorLog сохраняется.
   Процедуры выборки выводят свои результаты отдельными вкладками —
   итоговая таблица тестов выводится последней.
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;
SET SQL_SAFE_UPDATES = 0;   -- безопасный режим обновлений мешает тестовым DELETE/UPDATE

/* ---------------------------------------------------------------------
   Вспомогательные объекты
   --------------------------------------------------------------------- */
DROP TABLE IF EXISTS test_results;
CREATE TABLE test_results (
    N          INT AUTO_INCREMENT PRIMARY KEY,
    Процедура  VARCHAR(60),
    Сценарий   VARCHAR(150),
    Ожидается  VARCHAR(200),
    Фактически VARCHAR(500),
    Статус     VARCHAR(4)
);

DELIMITER $$

-- выполняет команду (обычно CALL ...) и возвращает номер и текст ошибки (NULL — без ошибки)
DROP PROCEDURE IF EXISTS t_run$$
CREATE PROCEDURE t_run(IN p_sql TEXT, OUT p_errno INT, OUT p_err VARCHAR(500))
BEGIN
    DECLARE v_no  INT;
    DECLARE v_msg VARCHAR(500);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_no = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        SET p_errno = v_no, p_err = CONCAT(v_no, ': ', v_msg);
    END;
    SET p_errno = NULL, p_err = NULL;
    SET @t_sql = p_sql;
    PREPARE t_stmt FROM @t_sql;
    EXECUTE t_stmt;
    DEALLOCATE PREPARE t_stmt;
END$$

-- негативный сценарий: команда должна завершиться ошибкой с номером p_errno
DROP PROCEDURE IF EXISTS t_expect_error$$
CREATE PROCEDURE t_expect_error(IN p_proc VARCHAR(60), IN p_case VARCHAR(150), IN p_errno INT, IN p_sql TEXT)
BEGIN
    DECLARE v_no  INT;
    DECLARE v_err VARCHAR(500);
    CALL t_run(p_sql, v_no, v_err);
    INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
    VALUES (p_proc, p_case, CONCAT('Ошибка ', p_errno), IFNULL(v_err, 'ошибки нет'), IF(v_no = p_errno, 'PASS', 'FAIL'));
END$$

DELIMITER ;

-- если предыдущий запуск прервался — убираем оставшиеся тестовые записи
DELETE FROM Deals      WHERE PropertyID IN (SELECT PropertyID FROM (SELECT PropertyID FROM Properties WHERE Address LIKE 'ТЕСТ:%') AS x)
                          OR ClientID IN (SELECT ClientID FROM (SELECT ClientID FROM Clients WHERE Phone IN ('+79990000001', '+79990000002', '+79990000003')) AS y);
DELETE FROM Properties WHERE Address LIKE 'ТЕСТ:%';
DELETE FROM Viewings   WHERE ClientID IN (SELECT ClientID FROM Clients WHERE Phone IN ('+79990000001', '+79990000002', '+79990000003'));
DELETE FROM Clients    WHERE Phone IN ('+79990000001', '+79990000002', '+79990000003');

SET @errBefore = (SELECT COUNT(*) FROM ErrorLog);
SET @vTime  = TIMESTAMP(CURDATE() + INTERVAL 30 DAY, '09:00:00');
SET @vTime2 = @vTime + INTERVAL 30 MINUTE;
SET @phone1 = (SELECT Phone FROM Clients WHERE ClientID = 1);
SET @C1 = NULL, @C2 = NULL, @P1 = NULL, @P2 = NULL, @P3 = NULL, @V1 = NULL, @Req1 = NULL, @D1 = NULL, @D2 = NULL;

/* =====================================================================
   1. Процедуры выборки
   ===================================================================== */
CALL t_run("CALL proc_Properties_Search('продажа', 1, NULL, NULL, NULL, 25000000, @found)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_Search', 'Квартиры на продажу до 25 млн', '3 объекта (как в ручном запросе)',
       IFNULL(@e, CONCAT(@found, ' объекта')), IF(@e IS NULL AND @found = 3, 'PASS', 'FAIL');

CALL t_expect_error('proc_Properties_Search', 'Недопустимый тип предложения «обмен»', 50004,
    "CALL proc_Properties_Search('обмен', NULL, NULL, NULL, NULL, NULL, @found)");

CALL t_run("CALL proc_Clients_GetByName('Ив', @found)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_GetByName', 'Фамилия начинается на «Ив»', '1 клиент (Иванов)',
       IFNULL(@e, CONCAT(@found, ' клиент')), IF(@e IS NULL AND @found = 1, 'PASS', 'FAIL');

CALL t_expect_error('proc_Properties_GetById', 'Несуществующий объект 99999', 50002,
    "CALL proc_Properties_GetById(99999)");

CALL t_run("CALL proc_Deals_GetByPeriod('2026-01-01', '2026-03-31', NULL, NULL, @found)", @no, @e);
SET @manual = (SELECT COUNT(*) FROM Deals WHERE DealDate BETWEEN '2026-01-01' AND '2026-03-31');
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Deals_GetByPeriod', 'Сделки за I квартал 2026', '9 сделок (как в ручном запросе)',
       IFNULL(@e, CONCAT(@found, ' сделок, ручной запрос: ', @manual)), IF(@e IS NULL AND @found = 9 AND @found = @manual, 'PASS', 'FAIL');

CALL t_run("CALL proc_Deals_GetByPeriod('2020-01-01', '2020-12-31', NULL, NULL, @found)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Deals_GetByPeriod', 'Период без сделок (2020 год)', 'Пустой результат без ошибки',
       IFNULL(@e, CONCAT(@found, ' строк')), IF(@e IS NULL AND @found = 0, 'PASS', 'FAIL');

CALL t_expect_error('proc_Deals_GetByPeriod', 'Дата начала позже даты окончания', 50004,
    "CALL proc_Deals_GetByPeriod('2026-12-31', '2026-01-01', NULL, NULL, @found)");

/* =====================================================================
   2. Клиенты: добавление, изменение, OUT
   ===================================================================== */
CALL t_run("CALL proc_Clients_Create('Тестов', 'Пётр', NULL, '1995-05-05', '+79990000001', NULL, @C1)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_Create', 'Корректные данные', 'Клиент создан, ID через OUT',
       IFNULL(@e, CONCAT('ClientID = ', @C1)),
       IF(@e IS NULL AND EXISTS (SELECT 1 FROM Clients WHERE ClientID = @C1), 'PASS', 'FAIL');

CALL t_expect_error('proc_Clients_Create', 'Телефон в неверном формате', 50004,
    "CALL proc_Clients_Create('Тестов', 'Иван', NULL, '1990-01-01', '8-999-123', NULL, @C2)");

CALL t_expect_error('proc_Clients_Create', 'Телефон уже есть у клиента №1', 50006,
    "CALL proc_Clients_Create('Двойник', 'Тест', NULL, '1990-01-01', @phone1, NULL, @C2)");

CALL t_expect_error('proc_Clients_Create', 'Клиент младше 18 лет', 50004,
    "CALL proc_Clients_Create('Юный', 'Тест', NULL, '2015-01-01', '+79990000002', NULL, @C2)");

SET @mail = CONCAT('p.testov', FLOOR(RAND() * 1000000), '@mail.ru');
CALL t_run("CALL proc_Clients_Update(@C1, NULL, @mail, NULL)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_Update', 'Добавить e-mail клиенту', 'E-mail сохранён',
       IFNULL(@e, (SELECT Email FROM Clients WHERE ClientID = @C1)),
       IF(@e IS NULL AND (SELECT Email FROM Clients WHERE ClientID = @C1) = @mail, 'PASS', 'FAIL');

CALL t_run("CALL proc_Clients_Update(@C1, @phone1, NULL, NULL)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_Update', 'Телефон другого клиента', 'Ошибка 50006, данные не изменены',
       IFNULL(@e, 'ошибки нет'),
       IF(@no = 50006 AND (SELECT Phone FROM Clients WHERE ClientID = @C1) = '+79990000001', 'PASS', 'FAIL');

/* =====================================================================
   3. Объекты: добавление с удобствами (транзакция), цена, откат
   ===================================================================== */
CALL t_run("CALL proc_Properties_Create(2, 4, 1, 9, 'продажа', 'ТЕСТ: ул. Братиславская, д. 31, кв. 7', 45, 11500000,
                                        2, 3, 9, NULL, NULL, '1, 2', @P1)", @no, @e);
SET @n = (SELECT COUNT(*) FROM PropertyFeatures WHERE PropertyID = @P1);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_Create', 'Объект с удобствами «1, 2»', 'Объект и 2 удобства созданы',
       IFNULL(@e, CONCAT('PropertyID = ', @P1, ', удобств: ', @n)), IF(@e IS NULL AND @P1 IS NOT NULL AND @n = 2, 'PASS', 'FAIL');

CALL t_expect_error('proc_Properties_Create', 'Несуществующий собственник', 50001,
    "CALL proc_Properties_Create(99999, 4, 1, 9, 'продажа', 'ТЕСТ: нет собственника', 40, 9000000,
                                 NULL, NULL, NULL, NULL, NULL, NULL, @P3)");

CALL t_expect_error('proc_Properties_Create', 'Несуществующее удобство «99»', 50004,
    "CALL proc_Properties_Create(2, 4, 1, 9, 'продажа', 'ТЕСТ: неверное удобство', 40, 9000000,
                                 NULL, NULL, NULL, NULL, NULL, '1,99', @P3)");

-- ошибка возникает ВНУТРИ транзакции (нарушение CHECK на 50 комнат) — проверяем полный откат
CALL t_run("CALL proc_Properties_Create(2, 4, 1, 9, 'продажа', 'ТЕСТ: откат транзакции', 40, 9000000,
                                        50, NULL, NULL, NULL, NULL, '1,2', @P3)", @no, @e);
SET @n = (SELECT COUNT(*) FROM Properties WHERE Address = 'ТЕСТ: откат транзакции');
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_Create', 'Ошибка внутри транзакции (50 комнат)', 'Ошибка 3819 (CHECK), ничего не создано',
       CONCAT(IFNULL(@e, 'ошибки нет'), '; строк с этим адресом: ', @n),
       IF(@no = 3819 AND @n = 0, 'PASS', 'FAIL');

CALL t_run("CALL proc_Properties_UpdatePrice(@P1, 11000000, @old)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_UpdatePrice', 'Снижение цены 11,5 → 11 млн', 'OldPrice = 11500000, цена 11000000',
       IFNULL(@e, CONCAT('OldPrice = ', @old, ', новая цена = ', (SELECT Price FROM Properties WHERE PropertyID = @P1))),
       IF(@e IS NULL AND @old = 11500000 AND (SELECT Price FROM Properties WHERE PropertyID = @P1) = 11000000, 'PASS', 'FAIL');

CALL t_expect_error('proc_Properties_UpdatePrice', 'Изменить цену проданного объекта №1', 50005,
    "CALL proc_Properties_UpdatePrice(1, 1000000, @old)");

CALL t_expect_error('proc_Properties_UpdatePrice', 'Отрицательная цена', 50004,
    "CALL proc_Properties_UpdatePrice(@P1, -5, @old)");

/* =====================================================================
   4. Заявки и показы
   ===================================================================== */
CALL t_run("CALL proc_Requests_Create(@C1, 'продажа', 1, 12000000, 9, 2, NULL, NULL, @Req1)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Requests_Create', 'Заявка на покупку квартиры в Марьино', 'Заявка «открыта», ID через OUT',
       IFNULL(@e, CONCAT('RequestID = ', @Req1, ', статус: ', (SELECT Status FROM Requests WHERE RequestID = @Req1))),
       IF(@e IS NULL AND (SELECT Status FROM Requests WHERE RequestID = @Req1) = 'открыта', 'PASS', 'FAIL');

CALL t_run("CALL proc_Viewings_Create(@P1, @C1, @vTime, NULL, @V1)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Viewings_Create', 'Показ через 30 дней, агент по умолчанию', 'Показ «запланирован», агент объекта',
       IFNULL(@e, CONCAT('ViewingID = ', @V1, ', агент ', (SELECT EmployeeID FROM Viewings WHERE ViewingID = @V1))),
       IF(@e IS NULL AND (SELECT EmployeeID FROM Viewings WHERE ViewingID = @V1) = 4, 'PASS', 'FAIL');

CALL t_expect_error('proc_Viewings_Create', 'У агента показ через 30 минут после другого', 50010,
    "CALL proc_Viewings_Create(22, 5, @vTime2, 4, @Vx)");

CALL t_expect_error('proc_Viewings_Create', 'Дата показа в прошлом', 50004,
    "CALL proc_Viewings_Create(@P1, @C1, '2020-01-01 12:00:00', NULL, @Vx)");

CALL t_run("CALL proc_Viewings_SetResult(@V1, 'понравилось', 'Готов вносить задаток')", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Viewings_SetResult', 'Зафиксировать «понравилось»', 'Результат сохранён',
       IFNULL(@e, (SELECT Result FROM Viewings WHERE ViewingID = @V1)),
       IF(@e IS NULL AND (SELECT Result FROM Viewings WHERE ViewingID = @V1) = 'понравилось', 'PASS', 'FAIL');

CALL t_expect_error('proc_Viewings_SetResult', 'Повторно изменить результат', 50005,
    "CALL proc_Viewings_SetResult(@V1, 'не понравилось', NULL)");

/* =====================================================================
   5. Сделки и платежи (транзакционные процедуры)
   ===================================================================== */
CALL t_expect_error('proc_Deals_Create', 'Сделка по проданному объекту №1', 50005,
    "CALL proc_Deals_Create(1, @C1, 2, NULL, NULL, NULL, NULL, @D1)");

CALL t_expect_error('proc_Deals_Create', 'Покупатель = собственник', 50004,
    "CALL proc_Deals_Create(@P1, 2, 4, NULL, NULL, NULL, NULL, @D1)");

CALL t_run("CALL proc_Deals_Create(@P1, @C1, 4, NULL, NULL, NULL, 200000, @D1)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Deals_Create', 'Корректная сделка с задатком 200 000',
       'Сделка «оформляется», объект «забронирован», задаток внесён, заявка «в работе»',
       IFNULL(@e, CONCAT('DealID = ', @D1, '; сделка: ', (SELECT Status FROM Deals WHERE DealID = @D1),
                         '; объект: ', (SELECT Status FROM Properties WHERE PropertyID = @P1),
                         '; платежей: ', (SELECT COUNT(*) FROM Payments WHERE DealID = @D1),
                         '; заявка: ', (SELECT Status FROM Requests WHERE RequestID = @Req1))),
       IF(@e IS NULL
          AND (SELECT Status FROM Deals WHERE DealID = @D1) = 'оформляется'
          AND (SELECT Status FROM Properties WHERE PropertyID = @P1) = 'забронирован'
          AND (SELECT SUM(Amount) FROM Payments WHERE DealID = @D1) = 200000
          AND (SELECT Status FROM Requests WHERE RequestID = @Req1) = 'в работе', 'PASS', 'FAIL');

CALL t_expect_error('proc_Payments_Add', 'Платёж больше цены договора', 50009,
    "CALL proc_Payments_Add(@D1, 50000000, 'перевод', 'основной платёж', @Pay)");

CALL t_run("CALL proc_Payments_Add(@D1, 3000000, 'перевод', 'основной платёж', @Pay)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Payments_Add', 'Частичная оплата 3 000 000', 'Платёж создан, ID через OUT',
       IFNULL(@e, CONCAT('PaymentID = ', @Pay)), IF(@e IS NULL AND @Pay IS NOT NULL, 'PASS', 'FAIL');

CALL t_run("CALL proc_Deals_Complete(@D1, 'ипотека')", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Deals_Complete', 'Завершение сделки купли-продажи',
       'Сделка «завершена», объект «продан», оплачено 100 %, заявка «закрыта»',
       IFNULL(@e, CONCAT('сделка: ', (SELECT Status FROM Deals WHERE DealID = @D1),
                         '; объект: ', (SELECT Status FROM Properties WHERE PropertyID = @P1),
                         '; оплачено ', (SELECT SUM(Amount) FROM Payments WHERE DealID = @D1),
                         ' из ', (SELECT Amount FROM Deals WHERE DealID = @D1),
                         '; заявка: ', (SELECT Status FROM Requests WHERE RequestID = @Req1))),
       IF(@e IS NULL
          AND (SELECT Status FROM Deals WHERE DealID = @D1) = 'завершена'
          AND (SELECT Status FROM Properties WHERE PropertyID = @P1) = 'продан'
          AND (SELECT SUM(Amount) FROM Payments WHERE DealID = @D1) = (SELECT Amount FROM Deals WHERE DealID = @D1)
          AND (SELECT Status FROM Requests WHERE RequestID = @Req1) = 'закрыта', 'PASS', 'FAIL');

CALL t_expect_error('proc_Deals_Complete', 'Повторное завершение той же сделки', 50008,
    "CALL proc_Deals_Complete(@D1, NULL)");

CALL t_expect_error('proc_Deals_Cancel', 'Расторгнуть завершённую сделку', 50008,
    "CALL proc_Deals_Cancel(@D1)");

-- аренда: создание и расторжение
CALL t_run("CALL proc_Properties_Create(2, 5, 1, 8, 'аренда', 'ТЕСТ: ул. Адмирала Лазарева, д. 70, кв. 3', 38, 55000,
                                        1, NULL, NULL, NULL, NULL, NULL, @P2)", @no, @e1);
CALL t_run("CALL proc_Deals_Create(@P2, @C1, 5, NULL, NULL, 6, NULL, @D2)", @no, @e2);
CALL t_run("CALL proc_Deals_Cancel(@D2)", @no, @e3);
SET @e = COALESCE(@e1, @e2, @e3);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Deals_Cancel', 'Расторжение оформляемой сделки аренды на 6 мес.', 'Сделка «расторгнута», объект снова «активен»',
       IFNULL(@e, CONCAT('сделка: ', (SELECT Status FROM Deals WHERE DealID = @D2),
                         '; объект: ', (SELECT Status FROM Properties WHERE PropertyID = @P2),
                         '; аренда до ', (SELECT LeaseEndDate FROM Deals WHERE DealID = @D2))),
       IF(@e IS NULL
          AND (SELECT Status FROM Deals WHERE DealID = @D2) = 'расторгнута'
          AND (SELECT Status FROM Properties WHERE PropertyID = @P2) = 'активен', 'PASS', 'FAIL');

/* =====================================================================
   6. Выходные параметры и коды результата
   ===================================================================== */
CALL t_run("CALL proc_Clients_GetStats(@C1, @n, @sum, @vc, @rc)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_GetStats', 'Статистика тестового клиента', 'Код 0; 1 сделка на 11 млн; 1 показ',
       IFNULL(@e, CONCAT('код ', @rc, '; сделок ', @n, '; сумма ', @sum, '; показов ', @vc)),
       IF(@e IS NULL AND @rc = 0 AND @n = 1 AND @sum = 11000000 AND @vc = 1, 'PASS', 'FAIL');

CALL t_run("CALL proc_Clients_GetStats(99999, @n, @sum, @vc, @rc)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_GetStats', 'Несуществующий клиент', 'Код -1',
       IFNULL(@e, CONCAT('код ', @rc)), IF(@e IS NULL AND @rc = -1, 'PASS', 'FAIL');

CALL t_run("CALL proc_Clients_Delete(@C1, @rc)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_Delete', 'Удалить клиента, у которого есть сделки', 'Код -2, клиент не удалён',
       IFNULL(@e, CONCAT('код ', @rc)),
       IF(@e IS NULL AND @rc = -2 AND EXISTS (SELECT 1 FROM Clients WHERE ClientID = @C1), 'PASS', 'FAIL');

CALL t_run("CALL proc_Clients_Create('Удаляев', 'Тест', NULL, '1990-01-01', '+79990000003', NULL, @C2)", @no, @e1);
CALL t_run("CALL proc_Clients_Delete(@C2, @rc)", @no, @e2);
SET @e = COALESCE(@e1, @e2);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Clients_Delete', 'Удалить нового клиента без истории', 'Код 0, клиент удалён',
       IFNULL(@e, CONCAT('код ', @rc)),
       IF(@e IS NULL AND @rc = 0 AND NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = @C2), 'PASS', 'FAIL');

CALL t_run("CALL proc_Properties_Delete(@P1, @rc)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_Delete', 'Удалить объект со сделкой', 'Код -2',
       IFNULL(@e, CONCAT('код ', @rc)), IF(@e IS NULL AND @rc = -2, 'PASS', 'FAIL');

CALL t_run("CALL proc_Properties_Delete(99999, @rc)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_Delete', 'Удалить несуществующий объект', 'Код -1',
       IFNULL(@e, CONCAT('код ', @rc)), IF(@e IS NULL AND @rc = -1, 'PASS', 'FAIL');

CALL t_run("CALL proc_Properties_Create(2, 6, 2, 6, 'аренда', 'ТЕСТ: снятие и удаление', 12, 20000,
                                        1, NULL, NULL, NULL, NULL, '4', @P3)", @no, @e1);
CALL t_run("CALL proc_Properties_Withdraw(@P3)", @no, @e2);
SET @e = COALESCE(@e1, @e2);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_Withdraw', 'Снять активный объект', 'Статус «снят»',
       IFNULL(@e, (SELECT Status FROM Properties WHERE PropertyID = @P3)),
       IF(@e IS NULL AND (SELECT Status FROM Properties WHERE PropertyID = @P3) = 'снят', 'PASS', 'FAIL');

CALL t_run("CALL proc_Properties_Delete(@P3, @rc)", @no, @e);
SET @n = (SELECT COUNT(*) FROM PropertyFeatures WHERE PropertyID = @P3);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Properties_Delete', 'Удалить объект без сделок', 'Код 0, удобства удалены каскадно',
       IFNULL(@e, CONCAT('код ', @rc, '; удобств осталось: ', @n)), IF(@e IS NULL AND @rc = 0 AND @n = 0, 'PASS', 'FAIL');

/* =====================================================================
   7. Отчётные процедуры (сверка с ручными запросами)
   ===================================================================== */
CALL t_run("CALL proc_Report_RevenueByPeriod('2026-01-01', '2026-06-30', @total)", @no, @e);
SET @manual = (SELECT SUM(CommissionAmount) FROM Deals
               WHERE Status = 'завершена' AND DealDate BETWEEN '2026-01-01' AND '2026-06-30');
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Report_RevenueByPeriod', 'Выручка за I полугодие 2026', 'Итог = ручному запросу SUM(CommissionAmount)',
       IFNULL(@e, CONCAT('итог ', @total, '; ручной запрос ', @manual)), IF(@e IS NULL AND @total = @manual, 'PASS', 'FAIL');

CALL t_run("CALL proc_Report_RevenueByPeriod('2020-01-01', '2020-12-31', @total)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Report_RevenueByPeriod', 'Период без сделок (2020 год)', 'Пустой результат, итог 0',
       IFNULL(@e, CONCAT('итог ', @total)), IF(@e IS NULL AND @total = 0, 'PASS', 'FAIL');

CALL t_run("CALL proc_Report_AgentPerformance('2025-01-01', '2026-12-31', @total)", @no, @e);
SET @manual = (SELECT SUM(CommissionAmount) FROM Deals WHERE Status = 'завершена' AND DealDate BETWEEN '2025-01-01' AND '2026-12-31');
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Report_AgentPerformance', 'Результативность агентов за 2025–2026', 'Сумма комиссий = ручному запросу',
       IFNULL(@e, CONCAT('сумма ', @total, '; ручной запрос ', @manual)), IF(@e IS NULL AND @total = @manual, 'PASS', 'FAIL');

CALL t_run("CALL proc_Report_RequestMatches(16, @found)", @no, @e);
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_Report_RequestMatches', 'Подбор под заявку №16 (Арбат, от 3 комн., от 90 м², до 80 млн)', '1 объект: ул. Арбат, д. 20, кв. 3',
       IFNULL(@e, CONCAT(@found, ' объект')), IF(@e IS NULL AND @found = 1, 'PASS', 'FAIL');

/* =====================================================================
   8. Журнал ошибок
   ===================================================================== */
SET @n = (SELECT COUNT(*) FROM ErrorLog) - @errBefore;
INSERT INTO test_results (Процедура, Сценарий, Ожидается, Фактически, Статус)
SELECT 'proc_ErrorLog_Add', 'Ошибки процедур модификации записаны в журнал', 'Не менее 15 новых записей в ErrorLog',
       CONCAT(@n, ' новых записей'), IF(@n >= 15, 'PASS', 'FAIL');

/* =====================================================================
   Уборка тестовых данных (исходные данные этапа 1 не затрагиваются)
   ===================================================================== */
DELETE FROM Deals      WHERE PropertyID IN (@P1, @P2);       -- платежи удаляются каскадно
DELETE FROM Properties WHERE PropertyID IN (@P1, @P2, @P3);  -- удобства и показы — каскадно
DELETE FROM Viewings   WHERE ClientID = @C1;
DELETE FROM Clients    WHERE ClientID IN (@C1, @C2);         -- заявки — каскадно

DROP PROCEDURE IF EXISTS t_expect_error;
DROP PROCEDURE IF EXISTS t_run;

/* =====================================================================
   Итог
   ===================================================================== */
SELECT N, Процедура, Сценарий, Ожидается, Фактически, Статус FROM test_results ORDER BY N;

SELECT COUNT(*)                                          AS `Всего тестов`,
       SUM(CASE WHEN Статус = 'PASS' THEN 1 ELSE 0 END)  AS Пройдено,
       SUM(CASE WHEN Статус = 'FAIL' THEN 1 ELSE 0 END)  AS `Не пройдено`
FROM test_results;

SELECT ErrorLogID, LoggedAt, ProcedureName, ErrorNumber, ErrorMessage
FROM ErrorLog ORDER BY ErrorLogID DESC LIMIT 10;
