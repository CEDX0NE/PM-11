/* =====================================================================
   Учебная практика ПМ.11, этап 2 — «Разработка хранимых процедур»
   Кейс-задача: «Информационная система риэлторского агентства «КлючДом»»
   Файл: realty_procedures.sql
   База данных: realty_pm11 (создана на этапе 1)
   СУБД: MySQL 8.0
   Автор: ______________________     Дата: 15.10.2026

   Стандарт именования: proc_<Таблица>_<Действие>
     Get*      — выборка
     Create    — добавление (возвращает ID новой записи через OUT)
     Update*   — изменение
     Delete    — удаление (возвращает код результата через OUT p_Result)
     Report_*  — отчётные процедуры
   Параметры процедур: p_<Имя>, локальные переменные: v_<Имя>
   (иначе в MySQL переменная с именем столбца «перекрывает» столбец).
   В MySQL у параметров процедур нет значений по умолчанию — необязательный
   параметр передаётся как NULL.

   Коды бизнес-ошибок (SIGNAL SQLSTATE '45000', MYSQL_ERRNO):
     50001 — клиент не найден            50006 — дубликат (телефон, e-mail, адрес)
     50002 — объект не найден            50007 — сделка не найдена
     50003 — сотрудник не найден/уволен  50008 — недопустимый статус сделки
     50004 — некорректные входные данные 50009 — сумма платежей больше суммы сделки
     50005 — объект недоступен           50010 — агент занят в это время
     50011 — показ/заявка не найдены

   Код результата (OUT p_Result) у процедур удаления и статистики:
      0 — успешно, -1 — запись не найдена, -2 — есть зависимые данные

   Скрипт можно запускать повторно (DROP PROCEDURE IF EXISTS).
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;

/* ---------------------------------------------------------------------
   0. Журнал ошибок
   --------------------------------------------------------------------- */
CREATE TABLE IF NOT EXISTS ErrorLog (
    ErrorLogID     INT           NOT NULL AUTO_INCREMENT,
    LoggedAt       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ProcedureName  VARCHAR(64)   NULL,
    ErrorNumber    INT           NULL,
    ErrorMessage   VARCHAR(1000) NULL,
    UserName       VARCHAR(100)  NULL,
    CONSTRAINT PK_ErrorLog PRIMARY KEY (ErrorLogID)
) ENGINE = InnoDB;

DELIMITER $$

/* ---------------------------------------------------------------------
   proc_ErrorLog_Add
   Назначение: записывает сведения об ошибке в таблицу ErrorLog.
               Вызывается из обработчиков ошибок других процедур.
   Параметры:  p_ProcedureName — имя процедуры; p_ErrorNumber — номер ошибки;
               p_ErrorMessage — текст ошибки.
   Результат:  строка в ErrorLog.
   Пример:     CALL proc_ErrorLog_Add('proc_Clients_Create', 50004, 'Текст');
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_ErrorLog_Add$$
CREATE PROCEDURE proc_ErrorLog_Add(
    IN p_ProcedureName VARCHAR(64),
    IN p_ErrorNumber   INT,
    IN p_ErrorMessage  VARCHAR(1000))
BEGIN
    INSERT INTO ErrorLog (ProcedureName, ErrorNumber, ErrorMessage, UserName)
    VALUES (p_ProcedureName, p_ErrorNumber, p_ErrorMessage, CURRENT_USER());
END$$

/* =====================================================================
   1. ПРОЦЕДУРЫ ВЫБОРКИ
   ===================================================================== */

/* ---------------------------------------------------------------------
   proc_Properties_GetAll
   Назначение: список объектов недвижимости с типом, районом и агентом.
   Параметры:  p_Status — статус объекта (NULL — все статусы);
               p_OfferType — 'продажа' / 'аренда' (NULL — оба).
   Результат:  набор строк, отсортированный по дате размещения.
   Пример:     CALL proc_Properties_GetAll('активен', NULL);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Properties_GetAll$$
CREATE PROCEDURE proc_Properties_GetAll(
    IN p_Status    VARCHAR(20),
    IN p_OfferType VARCHAR(10))
BEGIN
    SELECT p.PropertyID                          AS `№`,
           p.OfferType                           AS Предложение,
           t.Name                                AS ТипОбъекта,
           d.Name                                AS Район,
           p.Address                             AS Адрес,
           p.Area                                AS Площадь,
           p.Rooms                               AS Комнат,
           p.Price                               AS Цена,
           p.Status                              AS Статус,
           CONCAT(e.LastName, ' ', e.FirstName)  AS Агент,
           p.ListedAt                            AS Размещён
    FROM Properties    AS p
    JOIN PropertyTypes AS t ON t.TypeID     = p.TypeID
    JOIN Districts     AS d ON d.DistrictID = p.DistrictID
    JOIN Employees     AS e ON e.EmployeeID = p.EmployeeID
    WHERE (p_Status    IS NULL OR p.Status    = p_Status)
      AND (p_OfferType IS NULL OR p.OfferType = p_OfferType)
    ORDER BY p.ListedAt DESC;
END$$

/* ---------------------------------------------------------------------
   proc_Properties_GetById
   Назначение: карточка объекта: основные данные, собственник, удобства.
   Параметры:  p_PropertyID — код объекта.
   Результат:  два набора строк (карточка и список удобств);
               ошибка 50002, если объект не найден.
   Пример:     CALL proc_Properties_GetById(21);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Properties_GetById$$
CREATE PROCEDURE proc_Properties_GetById(IN p_PropertyID INT)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Properties WHERE PropertyID = p_PropertyID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50002, MESSAGE_TEXT = 'Объект недвижимости не найден.';
    END IF;

    SELECT p.PropertyID, p.OfferType, t.Name AS TypeName, d.Name AS District, p.Address,
           p.Area, p.Rooms, p.Floor, p.TotalFloors, p.BuildYear, p.Price, p.Status, p.ListedAt, p.Description,
           CONCAT(o.LastName, ' ', o.FirstName) AS OwnerName, o.Phone AS OwnerPhone,
           CONCAT(e.LastName, ' ', e.FirstName) AS AgentName, e.Phone AS AgentPhone
    FROM Properties    AS p
    JOIN PropertyTypes AS t ON t.TypeID     = p.TypeID
    JOIN Districts     AS d ON d.DistrictID = p.DistrictID
    JOIN Clients       AS o ON o.ClientID   = p.OwnerClientID
    JOIN Employees     AS e ON e.EmployeeID = p.EmployeeID
    WHERE p.PropertyID = p_PropertyID;

    SELECT f.FeatureID, f.Name AS Feature
    FROM PropertyFeatures AS pf
    JOIN Features         AS f ON f.FeatureID = pf.FeatureID
    WHERE pf.PropertyID = p_PropertyID
    ORDER BY f.Name;
END$$

/* ---------------------------------------------------------------------
   proc_Properties_Search
   Назначение: подбор активных объектов по параметрам (фильтр).
   Параметры:  p_OfferType — 'продажа' / 'аренда' (обязательный);
               p_TypeID, p_DistrictID, p_MinRooms, p_MinArea, p_MaxPrice —
               необязательные фильтры (NULL — не учитывать);
               p_Found OUT — сколько объектов найдено.
   Результат:  подходящие объекты, от дешёвых к дорогим.
   Пример:     CALL proc_Properties_Search('продажа', 1, NULL, NULL, NULL, 25000000, @found);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Properties_Search$$
CREATE PROCEDURE proc_Properties_Search(
    IN  p_OfferType  VARCHAR(10),
    IN  p_TypeID     INT,
    IN  p_DistrictID INT,
    IN  p_MinRooms   TINYINT,
    IN  p_MinArea    DECIMAL(8,2),
    IN  p_MaxPrice   DECIMAL(14,2),
    OUT p_Found      INT)
BEGIN
    IF p_OfferType IS NULL OR p_OfferType NOT IN ('продажа', 'аренда') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Тип предложения должен быть «продажа» или «аренда».';
    END IF;

    SELECT COUNT(*) INTO p_Found
    FROM Properties AS p
    WHERE p.Status    = 'активен'
      AND p.OfferType = p_OfferType
      AND (p_TypeID     IS NULL OR p.TypeID     = p_TypeID)
      AND (p_DistrictID IS NULL OR p.DistrictID = p_DistrictID)
      AND (p_MinRooms   IS NULL OR p.Rooms     >= p_MinRooms)
      AND (p_MinArea    IS NULL OR p.Area      >= p_MinArea)
      AND (p_MaxPrice   IS NULL OR p.Price     <= p_MaxPrice);

    SELECT p.PropertyID                               AS `№`,
           t.Name                                     AS ТипОбъекта,
           d.Name                                     AS Район,
           p.Address                                  AS Адрес,
           p.Rooms                                    AS Комнат,
           p.Area                                     AS Площадь,
           p.Price                                    AS Цена,
           CAST(p.Price / p.Area AS DECIMAL(14,0))    AS ЦенаЗаМ2,
           CONCAT(e.LastName, ' ', e.FirstName)       AS Агент
    FROM Properties    AS p
    JOIN PropertyTypes AS t ON t.TypeID     = p.TypeID
    JOIN Districts     AS d ON d.DistrictID = p.DistrictID
    JOIN Employees     AS e ON e.EmployeeID = p.EmployeeID
    WHERE p.Status    = 'активен'
      AND p.OfferType = p_OfferType
      AND (p_TypeID     IS NULL OR p.TypeID     = p_TypeID)
      AND (p_DistrictID IS NULL OR p.DistrictID = p_DistrictID)
      AND (p_MinRooms   IS NULL OR p.Rooms     >= p_MinRooms)
      AND (p_MinArea    IS NULL OR p.Area      >= p_MinArea)
      AND (p_MaxPrice   IS NULL OR p.Price     <= p_MaxPrice)
    ORDER BY p.Price;
END$$

/* ---------------------------------------------------------------------
   proc_Clients_GetByName
   Назначение: поиск клиентов по началу фамилии.
   Параметры:  p_LastName — первые буквы фамилии; p_Found OUT — сколько найдено.
   Результат:  список клиентов; ошибка 50004 при пустом параметре.
   Пример:     CALL proc_Clients_GetByName('Ив', @found);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Clients_GetByName$$
CREATE PROCEDURE proc_Clients_GetByName(
    IN  p_LastName VARCHAR(50),
    OUT p_Found    INT)
BEGIN
    IF p_LastName IS NULL OR TRIM(p_LastName) = '' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Укажите хотя бы первую букву фамилии.';
    END IF;

    SELECT COUNT(*) INTO p_Found FROM Clients WHERE LastName LIKE CONCAT(TRIM(p_LastName), '%');

    SELECT c.ClientID                                                          AS `№`,
           CONCAT_WS(' ', c.LastName, c.FirstName, c.MiddleName)               AS ФИО,
           c.Phone                                                             AS Телефон,
           c.Email                                                             AS Email,
           c.BirthDate                                                         AS ДатаРождения
    FROM Clients AS c
    WHERE c.LastName LIKE CONCAT(TRIM(p_LastName), '%')
    ORDER BY c.LastName, c.FirstName;
END$$

/* ---------------------------------------------------------------------
   proc_Clients_GetById
   Назначение: карточка клиента: данные, его объекты, его сделки.
   Параметры:  p_ClientID — код клиента.
   Результат:  три набора строк; ошибка 50001, если клиента нет.
   Пример:     CALL proc_Clients_GetById(1);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Clients_GetById$$
CREATE PROCEDURE proc_Clients_GetById(IN p_ClientID INT)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50001, MESSAGE_TEXT = 'Клиент не найден.';
    END IF;

    SELECT ClientID, LastName, FirstName, MiddleName, BirthDate, Phone, Email, RegisteredAt
    FROM Clients WHERE ClientID = p_ClientID;

    SELECT PropertyID, OfferType, Address, Price, Status          -- объекты, где клиент собственник
    FROM Properties WHERE OwnerClientID = p_ClientID;

    SELECT dl.DealID, dl.DealDate, dl.DealType, p.Address, dl.Amount, dl.Status  -- сделки клиента
    FROM Deals AS dl
    JOIN Properties AS p ON p.PropertyID = dl.PropertyID
    WHERE dl.ClientID = p_ClientID
    ORDER BY dl.DealDate;
END$$

/* ---------------------------------------------------------------------
   proc_Deals_GetByPeriod
   Назначение: журнал сделок за период с фильтрами.
   Параметры:  p_DateFrom, p_DateTo — границы периода (включительно);
               p_EmployeeID — агент (NULL — все); p_DealType — вид (NULL — все);
               p_Found OUT — сколько сделок найдено.
   Результат:  список сделок; ошибка 50004 при неверном периоде.
   Пример:     CALL proc_Deals_GetByPeriod('2026-01-01', '2026-03-31', NULL, NULL, @found);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Deals_GetByPeriod$$
CREATE PROCEDURE proc_Deals_GetByPeriod(
    IN  p_DateFrom   DATE,
    IN  p_DateTo     DATE,
    IN  p_EmployeeID INT,
    IN  p_DealType   VARCHAR(10),
    OUT p_Found      INT)
BEGIN
    IF p_DateFrom IS NULL OR p_DateTo IS NULL OR p_DateFrom > p_DateTo THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный период: дата начала позже даты окончания.';
    END IF;

    SELECT COUNT(*) INTO p_Found
    FROM Deals AS dl
    WHERE dl.DealDate BETWEEN p_DateFrom AND p_DateTo
      AND (p_EmployeeID IS NULL OR dl.EmployeeID = p_EmployeeID)
      AND (p_DealType   IS NULL OR dl.DealType   = p_DealType);

    SELECT dl.DealID                              AS `№`,
           dl.DealDate                            AS Дата,
           dl.DealType                            AS Вид,
           p.Address                              AS Объект,
           CONCAT(c.LastName, ' ', c.FirstName)   AS Клиент,
           CONCAT(e.LastName, ' ', e.FirstName)   AS Агент,
           dl.Amount                              AS Сумма,
           dl.CommissionAmount                    AS Комиссия,
           dl.Status                              AS Статус
    FROM Deals      AS dl
    JOIN Properties AS p ON p.PropertyID = dl.PropertyID
    JOIN Clients    AS c ON c.ClientID   = dl.ClientID
    JOIN Employees  AS e ON e.EmployeeID = dl.EmployeeID
    WHERE dl.DealDate BETWEEN p_DateFrom AND p_DateTo
      AND (p_EmployeeID IS NULL OR dl.EmployeeID = p_EmployeeID)
      AND (p_DealType   IS NULL OR dl.DealType   = p_DealType)
    ORDER BY dl.DealDate;
END$$

/* ---------------------------------------------------------------------
   proc_Viewings_GetSchedule
   Назначение: расписание показов агента (или всех агентов) за период.
   Параметры:  p_DateFrom, p_DateTo — период; p_EmployeeID — агент (NULL — все).
   Результат:  список показов по времени.
   Пример:     CALL proc_Viewings_GetSchedule('2026-10-15', '2026-10-31', NULL);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Viewings_GetSchedule$$
CREATE PROCEDURE proc_Viewings_GetSchedule(
    IN p_DateFrom   DATE,
    IN p_DateTo     DATE,
    IN p_EmployeeID INT)
BEGIN
    IF p_DateFrom IS NULL OR p_DateTo IS NULL OR p_DateFrom > p_DateTo THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный период.';
    END IF;

    SELECT v.ViewingID                            AS `№`,
           v.ViewingDateTime                      AS ДатаВремя,
           CONCAT(e.LastName, ' ', e.FirstName)   AS Агент,
           p.Address                              AS Объект,
           CONCAT(c.LastName, ' ', c.FirstName)   AS Клиент,
           c.Phone                                AS ТелефонКлиента,
           v.Result                               AS Результат
    FROM Viewings   AS v
    JOIN Properties AS p ON p.PropertyID = v.PropertyID
    JOIN Clients    AS c ON c.ClientID   = v.ClientID
    JOIN Employees  AS e ON e.EmployeeID = v.EmployeeID
    WHERE v.ViewingDateTime >= p_DateFrom
      AND v.ViewingDateTime <  p_DateTo + INTERVAL 1 DAY
      AND (p_EmployeeID IS NULL OR v.EmployeeID = p_EmployeeID)
    ORDER BY v.ViewingDateTime;
END$$

/* ---------------------------------------------------------------------
   proc_Payments_GetByDeal
   Назначение: платежи по сделке с нарастающим итогом.
   Параметры:  p_DealID — код сделки.
   Результат:  список платежей; ошибка 50007, если сделки нет.
   Пример:     CALL proc_Payments_GetByDeal(20);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Payments_GetByDeal$$
CREATE PROCEDURE proc_Payments_GetByDeal(IN p_DealID INT)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Deals WHERE DealID = p_DealID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50007, MESSAGE_TEXT = 'Сделка не найдена.';
    END IF;

    SELECT pay.PaymentID   AS `№`,
           pay.PaymentDate AS Дата,
           pay.Purpose     AS Назначение,
           pay.Method      AS Способ,
           pay.Amount      AS Сумма,
           SUM(pay.Amount) OVER (ORDER BY pay.PaymentDate, pay.PaymentID) AS Нарастающим
    FROM Payments AS pay
    WHERE pay.DealID = p_DealID
    ORDER BY pay.PaymentDate, pay.PaymentID;
END$$

/* =====================================================================
   2. ПРОЦЕДУРЫ ДОБАВЛЕНИЯ, ИЗМЕНЕНИЯ И УДАЛЕНИЯ
   Шаблон: обработчик ошибок (EXIT HANDLER) → проверки → транзакция.
   Обработчик: откат → запись в ErrorLog → повторная генерация ошибки
   с тем же номером для вызывающего кода.
   ===================================================================== */

/* ---------------------------------------------------------------------
   proc_Clients_Create
   Назначение: регистрация нового клиента.
   Параметры:  p_LastName, p_FirstName, p_MiddleName (может быть NULL),
               p_BirthDate, p_Phone (+7XXXXXXXXXX), p_Email (может быть NULL);
               p_ClientID OUT — код созданного клиента.
   Результат:  новая строка в Clients; ошибки 50004, 50006.
   Пример:     CALL proc_Clients_Create('Орлова', 'Алина', NULL, '1998-03-14',
                    '+79035550999', NULL, @id);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Clients_Create$$
CREATE PROCEDURE proc_Clients_Create(
    IN  p_LastName   VARCHAR(50),
    IN  p_FirstName  VARCHAR(50),
    IN  p_MiddleName VARCHAR(50),
    IN  p_BirthDate  DATE,
    IN  p_Phone      VARCHAR(12),
    IN  p_Email      VARCHAR(100),
    OUT p_ClientID   INT)
BEGIN
    DECLARE v_errno INT;
    DECLARE v_msg   VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Clients_Create', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_ClientID = NULL;
    IF NULLIF(TRIM(p_LastName), '') IS NULL OR NULLIF(TRIM(p_FirstName), '') IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Фамилия и имя клиента обязательны.';
    END IF;
    IF p_Phone IS NULL OR p_Phone NOT REGEXP '^\\+7[0-9]{10}$' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Телефон должен быть в формате +7XXXXXXXXXX.';
    END IF;
    IF p_BirthDate IS NULL OR p_BirthDate > CURDATE() - INTERVAL 18 YEAR THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Клиент должен быть совершеннолетним.';
    END IF;
    IF p_Email IS NOT NULL AND p_Email NOT LIKE '%_@_%._%' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный адрес e-mail.';
    END IF;
    IF EXISTS (SELECT 1 FROM Clients WHERE Phone = p_Phone) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50006, MESSAGE_TEXT = 'Клиент с таким телефоном уже зарегистрирован.';
    END IF;
    IF p_Email IS NOT NULL AND EXISTS (SELECT 1 FROM Clients WHERE Email = p_Email) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50006, MESSAGE_TEXT = 'Клиент с таким e-mail уже зарегистрирован.';
    END IF;

    INSERT INTO Clients (LastName, FirstName, MiddleName, BirthDate, Phone, Email)
    VALUES (TRIM(p_LastName), TRIM(p_FirstName), NULLIF(TRIM(p_MiddleName), ''), p_BirthDate, p_Phone, p_Email);

    SET p_ClientID = LAST_INSERT_ID();
END$$

/* ---------------------------------------------------------------------
   proc_Clients_Update
   Назначение: изменение контактных данных клиента.
   Параметры:  p_ClientID; p_Phone, p_Email, p_LastName — новые значения
               (NULL — оставить без изменений).
   Результат:  обновлённая строка; ошибки 50001, 50004, 50006.
   Пример:     CALL proc_Clients_Update(5, '+79035550998', NULL, NULL);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Clients_Update$$
CREATE PROCEDURE proc_Clients_Update(
    IN p_ClientID INT,
    IN p_Phone    VARCHAR(12),
    IN p_Email    VARCHAR(100),
    IN p_LastName VARCHAR(50))
BEGIN
    DECLARE v_errno INT;
    DECLARE v_msg   VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Clients_Update', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50001, MESSAGE_TEXT = 'Клиент не найден.';
    END IF;
    IF p_Phone IS NULL AND p_Email IS NULL AND p_LastName IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Не указано ни одного поля для изменения.';
    END IF;
    IF p_Phone IS NOT NULL AND p_Phone NOT REGEXP '^\\+7[0-9]{10}$' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Телефон должен быть в формате +7XXXXXXXXXX.';
    END IF;
    IF p_Email IS NOT NULL AND p_Email NOT LIKE '%_@_%._%' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный адрес e-mail.';
    END IF;
    IF p_Phone IS NOT NULL AND EXISTS (SELECT 1 FROM Clients WHERE Phone = p_Phone AND ClientID <> p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50006, MESSAGE_TEXT = 'Этот телефон уже принадлежит другому клиенту.';
    END IF;
    IF p_Email IS NOT NULL AND EXISTS (SELECT 1 FROM Clients WHERE Email = p_Email AND ClientID <> p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50006, MESSAGE_TEXT = 'Этот e-mail уже принадлежит другому клиенту.';
    END IF;

    UPDATE Clients
    SET Phone    = IFNULL(p_Phone, Phone),
        Email    = IFNULL(p_Email, Email),
        LastName = IFNULL(NULLIF(TRIM(p_LastName), ''), LastName)
    WHERE ClientID = p_ClientID;
END$$

/* ---------------------------------------------------------------------
   proc_Clients_Delete
   Назначение: удаление клиента без истории (нет объектов и сделок).
               Его заявки удаляются каскадно, показы — в той же транзакции.
   Параметры:  p_ClientID; p_Result OUT — код результата.
   Результат:  p_Result: 0 — удалён; -1 — не найден; -2 — есть объекты или сделки.
   Пример:     CALL proc_Clients_Delete(30, @rc); SELECT @rc;
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Clients_Delete$$
CREATE PROCEDURE proc_Clients_Delete(
    IN  p_ClientID INT,
    OUT p_Result   INT)
proc: BEGIN
    DECLARE v_errno INT;
    DECLARE v_msg   VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Clients_Delete', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SET p_Result = -1;
        LEAVE proc;
    END IF;
    IF EXISTS (SELECT 1 FROM Properties WHERE OwnerClientID = p_ClientID)
       OR EXISTS (SELECT 1 FROM Deals WHERE ClientID = p_ClientID) THEN
        SET p_Result = -2;
        LEAVE proc;
    END IF;

    START TRANSACTION;
        DELETE FROM Viewings WHERE ClientID = p_ClientID;
        DELETE FROM Clients  WHERE ClientID = p_ClientID;   -- заявки удалятся каскадно
    COMMIT;
    SET p_Result = 0;
END$$

/* ---------------------------------------------------------------------
   proc_Properties_Create
   Назначение: приём объекта в работу вместе со списком удобств
               (две таблицы — одна транзакция).
   Параметры:  p_OwnerClientID, p_EmployeeID, p_TypeID, p_DistrictID, p_OfferType,
               p_Address, p_Area, p_Price — обязательные;
               p_Rooms, p_Floor, p_TotalFloors, p_BuildYear, p_Description — могут быть NULL;
               p_FeatureIDs — коды удобств через запятую, например '1,2,5' (NULL — без удобств);
               p_PropertyID OUT — код созданного объекта.
   Результат:  строки в Properties и PropertyFeatures;
               ошибки 50001–50004, 50006. При ошибке не создаётся ничего.
   Пример:     CALL proc_Properties_Create(2, 4, 1, 9, 'продажа',
                    'ул. Братиславская, д. 31, кв. 7', 45, 11500000,
                    2, 3, 9, NULL, NULL, '1,2', @id);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Properties_Create$$
CREATE PROCEDURE proc_Properties_Create(
    IN  p_OwnerClientID INT,
    IN  p_EmployeeID    INT,
    IN  p_TypeID        INT,
    IN  p_DistrictID    INT,
    IN  p_OfferType     VARCHAR(10),
    IN  p_Address       VARCHAR(200),
    IN  p_Area          DECIMAL(8,2),
    IN  p_Price         DECIMAL(14,2),
    IN  p_Rooms         TINYINT,
    IN  p_Floor         SMALLINT,
    IN  p_TotalFloors   SMALLINT,
    IN  p_BuildYear     SMALLINT,
    IN  p_Description   VARCHAR(1000),
    IN  p_FeatureIDs    VARCHAR(200),
    OUT p_PropertyID    INT)
BEGIN
    DECLARE v_list  VARCHAR(200);
    DECLARE v_item  VARCHAR(200);
    DECLARE v_errno INT;
    DECLARE v_msg   VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        SET p_PropertyID = NULL;
        CALL proc_ErrorLog_Add('proc_Properties_Create', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_PropertyID = NULL;
    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_OwnerClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50001, MESSAGE_TEXT = 'Собственник (клиент) не найден.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Employees WHERE EmployeeID = p_EmployeeID AND IsActive) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50003, MESSAGE_TEXT = 'Агент не найден или не работает в агентстве.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM PropertyTypes WHERE TypeID = p_TypeID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Неизвестный тип объекта.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Districts WHERE DistrictID = p_DistrictID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Неизвестный район.';
    END IF;
    IF p_OfferType IS NULL OR p_OfferType NOT IN ('продажа', 'аренда') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Тип предложения должен быть «продажа» или «аренда».';
    END IF;
    IF NULLIF(TRIM(p_Address), '') IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Адрес объекта обязателен.';
    END IF;
    IF p_Area IS NULL OR p_Area <= 0 OR p_Price IS NULL OR p_Price <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Площадь и цена должны быть больше нуля.';
    END IF;
    IF p_Floor IS NOT NULL AND p_TotalFloors IS NOT NULL AND p_Floor > p_TotalFloors THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Этаж не может быть больше этажности дома.';
    END IF;
    IF EXISTS (SELECT 1 FROM Properties WHERE Address = TRIM(p_Address)) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50006, MESSAGE_TEXT = 'Объект с таким адресом уже есть в базе.';
    END IF;
    -- проверка списка удобств '1,2,5': каждый элемент — существующий код
    SET v_list = TRIM(IFNULL(p_FeatureIDs, ''));
    WHILE v_list <> '' DO
        SET v_item = TRIM(SUBSTRING_INDEX(v_list, ',', 1));
        SET v_list = IF(LOCATE(',', v_list) > 0, TRIM(SUBSTRING(v_list, LOCATE(',', v_list) + 1)), '');
        IF v_item NOT REGEXP '^[0-9]+$'
           OR NOT EXISTS (SELECT 1 FROM Features WHERE FeatureID = CAST(v_item AS UNSIGNED)) THEN
            SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'В списке удобств есть несуществующий код.';
        END IF;
    END WHILE;

    START TRANSACTION;
        INSERT INTO Properties (OwnerClientID, EmployeeID, TypeID, DistrictID, OfferType, Address,
                                Area, Rooms, Floor, TotalFloors, BuildYear, Price, Description)
        VALUES (p_OwnerClientID, p_EmployeeID, p_TypeID, p_DistrictID, p_OfferType, TRIM(p_Address),
                p_Area, p_Rooms, p_Floor, p_TotalFloors, p_BuildYear, p_Price, p_Description);

        SET p_PropertyID = LAST_INSERT_ID();

        IF p_FeatureIDs IS NOT NULL THEN
            INSERT INTO PropertyFeatures (PropertyID, FeatureID)
            SELECT p_PropertyID, FeatureID
            FROM Features
            WHERE FIND_IN_SET(FeatureID, REPLACE(p_FeatureIDs, ' ', '')) > 0;
        END IF;
    COMMIT;
END$$

/* ---------------------------------------------------------------------
   proc_Properties_UpdatePrice
   Назначение: изменение цены активного объекта.
   Параметры:  p_PropertyID, p_NewPrice; p_OldPrice OUT — прежняя цена.
   Результат:  обновлённая цена; ошибки 50002, 50004, 50005.
   Пример:     CALL proc_Properties_UpdatePrice(22, 14500000, @old); SELECT @old;
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Properties_UpdatePrice$$
CREATE PROCEDURE proc_Properties_UpdatePrice(
    IN  p_PropertyID INT,
    IN  p_NewPrice   DECIMAL(14,2),
    OUT p_OldPrice   DECIMAL(14,2))
BEGIN
    DECLARE v_Status VARCHAR(20) DEFAULT NULL;
    DECLARE v_errno  INT;
    DECLARE v_msg    VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Properties_UpdatePrice', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_OldPrice = NULL;
    SELECT Price, Status INTO p_OldPrice, v_Status FROM Properties WHERE PropertyID = p_PropertyID;
    IF v_Status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50002, MESSAGE_TEXT = 'Объект недвижимости не найден.';
    END IF;
    IF p_NewPrice IS NULL OR p_NewPrice <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Новая цена должна быть больше нуля.';
    END IF;
    IF v_Status <> 'активен' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50005, MESSAGE_TEXT = 'Цену можно менять только у активного объекта.';
    END IF;

    UPDATE Properties SET Price = p_NewPrice WHERE PropertyID = p_PropertyID;
END$$

/* ---------------------------------------------------------------------
   proc_Properties_Withdraw
   Назначение: снятие объекта с продажи/аренды по решению собственника.
               Запланированные показы этого объекта отменяются.
   Параметры:  p_PropertyID.
   Результат:  статус «снят», показы «отменён»; ошибки 50002, 50005.
   Пример:     CALL proc_Properties_Withdraw(23);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Properties_Withdraw$$
CREATE PROCEDURE proc_Properties_Withdraw(IN p_PropertyID INT)
BEGIN
    DECLARE v_Status VARCHAR(20) DEFAULT NULL;
    DECLARE v_errno  INT;
    DECLARE v_msg    VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Properties_Withdraw', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SELECT Status INTO v_Status FROM Properties WHERE PropertyID = p_PropertyID;
    IF v_Status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50002, MESSAGE_TEXT = 'Объект недвижимости не найден.';
    END IF;
    IF v_Status <> 'активен' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50005, MESSAGE_TEXT = 'Снять можно только активный объект.';
    END IF;

    START TRANSACTION;
        UPDATE Properties SET Status = 'снят' WHERE PropertyID = p_PropertyID;
        UPDATE Viewings
        SET Result = 'отменён', Comment = 'Объект снят с продажи'
        WHERE PropertyID = p_PropertyID AND Result = 'запланирован';
    COMMIT;
END$$

/* ---------------------------------------------------------------------
   proc_Properties_Delete
   Назначение: удаление ошибочно внесённого объекта без сделок
               (удобства и показы удаляются каскадно).
   Параметры:  p_PropertyID; p_Result OUT — код результата.
   Результат:  p_Result: 0 — удалён; -1 — не найден; -2 — по объекту есть сделки.
   Пример:     CALL proc_Properties_Delete(40, @rc); SELECT @rc;
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Properties_Delete$$
CREATE PROCEDURE proc_Properties_Delete(
    IN  p_PropertyID INT,
    OUT p_Result     INT)
proc: BEGIN
    DECLARE v_errno INT;
    DECLARE v_msg   VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Properties_Delete', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    IF NOT EXISTS (SELECT 1 FROM Properties WHERE PropertyID = p_PropertyID) THEN
        SET p_Result = -1;
        LEAVE proc;
    END IF;
    IF EXISTS (SELECT 1 FROM Deals WHERE PropertyID = p_PropertyID) THEN
        SET p_Result = -2;
        LEAVE proc;
    END IF;

    DELETE FROM Properties WHERE PropertyID = p_PropertyID;
    SET p_Result = 0;
END$$

/* ---------------------------------------------------------------------
   proc_Requests_Create
   Назначение: регистрация заявки клиента на подбор объекта.
   Параметры:  p_ClientID, p_OfferType, p_TypeID, p_MaxBudget — обязательные;
               p_DistrictID, p_MinRooms, p_MinArea, p_EmployeeID — могут быть NULL;
               p_RequestID OUT — код заявки.
   Результат:  новая заявка (статус «открыта» или «в работе», если назначен агент).
   Пример:     CALL proc_Requests_Create(7, 'аренда', 1, 70000, NULL, NULL, NULL, NULL, @id);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Requests_Create$$
CREATE PROCEDURE proc_Requests_Create(
    IN  p_ClientID   INT,
    IN  p_OfferType  VARCHAR(10),
    IN  p_TypeID     INT,
    IN  p_MaxBudget  DECIMAL(14,2),
    IN  p_DistrictID INT,
    IN  p_MinRooms   TINYINT,
    IN  p_MinArea    DECIMAL(8,2),
    IN  p_EmployeeID INT,
    OUT p_RequestID  INT)
BEGIN
    DECLARE v_errno INT;
    DECLARE v_msg   VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Requests_Create', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_RequestID = NULL;
    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50001, MESSAGE_TEXT = 'Клиент не найден.';
    END IF;
    IF p_OfferType IS NULL OR p_OfferType NOT IN ('продажа', 'аренда') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Тип предложения должен быть «продажа» или «аренда».';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM PropertyTypes WHERE TypeID = p_TypeID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Неизвестный тип объекта.';
    END IF;
    IF p_DistrictID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM Districts WHERE DistrictID = p_DistrictID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Неизвестный район.';
    END IF;
    IF p_MaxBudget IS NULL OR p_MaxBudget <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Бюджет должен быть больше нуля.';
    END IF;
    IF p_EmployeeID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM Employees WHERE EmployeeID = p_EmployeeID AND IsActive) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50003, MESSAGE_TEXT = 'Агент не найден или не работает в агентстве.';
    END IF;

    INSERT INTO Requests (ClientID, EmployeeID, OfferType, TypeID, DistrictID, MinRooms, MinArea, MaxBudget, Status)
    VALUES (p_ClientID, p_EmployeeID, p_OfferType, p_TypeID, p_DistrictID, p_MinRooms, p_MinArea, p_MaxBudget,
            IF(p_EmployeeID IS NULL, 'открыта', 'в работе'));

    SET p_RequestID = LAST_INSERT_ID();
END$$

/* ---------------------------------------------------------------------
   proc_Viewings_Create
   Назначение: запись клиента на показ объекта.
   Параметры:  p_PropertyID, p_ClientID, p_ViewingDateTime;
               p_EmployeeID — агент (NULL — ответственный агент объекта);
               p_ViewingID OUT — код показа.
   Результат:  показ со статусом «запланирован»;
               ошибки 50001, 50002, 50003, 50004, 50005, 50010.
   Пример:     CALL proc_Viewings_Create(22, 5, '2026-10-25 12:00:00', NULL, @id);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Viewings_Create$$
CREATE PROCEDURE proc_Viewings_Create(
    IN  p_PropertyID      INT,
    IN  p_ClientID        INT,
    IN  p_ViewingDateTime DATETIME,
    IN  p_EmployeeID      INT,
    OUT p_ViewingID       INT)
BEGIN
    DECLARE v_Status  VARCHAR(20) DEFAULT NULL;
    DECLARE v_OwnerID INT;
    DECLARE v_AgentID INT;
    DECLARE v_errno   INT;
    DECLARE v_msg     VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Viewings_Create', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_ViewingID = NULL;
    SELECT Status, OwnerClientID, EmployeeID INTO v_Status, v_OwnerID, v_AgentID
    FROM Properties WHERE PropertyID = p_PropertyID;

    IF v_Status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50002, MESSAGE_TEXT = 'Объект недвижимости не найден.';
    END IF;
    IF v_Status <> 'активен' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50005, MESSAGE_TEXT = 'Показ возможен только для активного объекта.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50001, MESSAGE_TEXT = 'Клиент не найден.';
    END IF;
    IF p_ClientID = v_OwnerID THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Собственнику не нужно показывать его собственный объект.';
    END IF;
    IF p_ViewingDateTime IS NULL OR p_ViewingDateTime <= NOW() THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Показ можно назначить только на будущее время.';
    END IF;

    SET p_EmployeeID = IFNULL(p_EmployeeID, v_AgentID);
    IF NOT EXISTS (SELECT 1 FROM Employees WHERE EmployeeID = p_EmployeeID AND IsActive) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50003, MESSAGE_TEXT = 'Агент не найден или не работает в агентстве.';
    END IF;
    -- у агента не должно быть другого показа ближе чем за час
    IF EXISTS (SELECT 1 FROM Viewings
               WHERE EmployeeID = p_EmployeeID AND Result <> 'отменён'
                 AND ABS(TIMESTAMPDIFF(MINUTE, ViewingDateTime, p_ViewingDateTime)) < 60) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50010, MESSAGE_TEXT = 'У агента уже есть показ в это время (интервал не менее часа).';
    END IF;

    INSERT INTO Viewings (PropertyID, ClientID, EmployeeID, ViewingDateTime)
    VALUES (p_PropertyID, p_ClientID, p_EmployeeID, p_ViewingDateTime);

    SET p_ViewingID = LAST_INSERT_ID();
END$$

/* ---------------------------------------------------------------------
   proc_Viewings_SetResult
   Назначение: фиксация результата показа.
   Параметры:  p_ViewingID; p_Result — 'понравилось' / 'не понравилось' / 'отменён';
               p_Comment — может быть NULL.
   Результат:  обновлённый показ; ошибки 50011, 50004, 50005.
   Пример:     CALL proc_Viewings_SetResult(27, 'понравилось', 'Готов к задатку');
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Viewings_SetResult$$
CREATE PROCEDURE proc_Viewings_SetResult(
    IN p_ViewingID INT,
    IN p_Result    VARCHAR(20),
    IN p_Comment   VARCHAR(500))
BEGIN
    DECLARE v_Current VARCHAR(20) DEFAULT NULL;
    DECLARE v_errno   INT;
    DECLARE v_msg     VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Viewings_SetResult', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SELECT Result INTO v_Current FROM Viewings WHERE ViewingID = p_ViewingID;
    IF v_Current IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50011, MESSAGE_TEXT = 'Показ не найден.';
    END IF;
    IF p_Result IS NULL OR p_Result NOT IN ('понравилось', 'не понравилось', 'отменён') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Результат: понравилось, не понравилось или отменён.';
    END IF;
    IF v_Current <> 'запланирован' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50005, MESSAGE_TEXT = 'Результат уже зафиксирован, изменить его нельзя.';
    END IF;

    UPDATE Viewings
    SET Result = p_Result, Comment = IFNULL(p_Comment, Comment)
    WHERE ViewingID = p_ViewingID;
END$$

/* ---------------------------------------------------------------------
   proc_Payments_Add
   Назначение: регистрация платежа по сделке.
   Параметры:  p_DealID, p_Amount, p_Method, p_Purpose;
               p_PaymentID OUT — код платежа.
   Результат:  новый платёж; ошибки 50004, 50007, 50008, 50009.
               По сделке купли-продажи сумма задатка и основных платежей
               не может превышать цену договора.
   Пример:     CALL proc_Payments_Add(20, 1000000, 'перевод', 'основной платёж', @id);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Payments_Add$$
CREATE PROCEDURE proc_Payments_Add(
    IN  p_DealID    INT,
    IN  p_Amount    DECIMAL(14,2),
    IN  p_Method    VARCHAR(20),
    IN  p_Purpose   VARCHAR(30),
    OUT p_PaymentID INT)
BEGIN
    DECLARE v_DealType   VARCHAR(10) DEFAULT NULL;
    DECLARE v_DealStatus VARCHAR(15);
    DECLARE v_DealAmount DECIMAL(14,2);
    DECLARE v_Paid       DECIMAL(14,2);
    DECLARE v_errno      INT;
    DECLARE v_msg        VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Payments_Add', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_PaymentID = NULL;
    SELECT DealType, Status, Amount INTO v_DealType, v_DealStatus, v_DealAmount
    FROM Deals WHERE DealID = p_DealID;

    IF v_DealType IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50007, MESSAGE_TEXT = 'Сделка не найдена.';
    END IF;
    IF v_DealStatus = 'расторгнута' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50008, MESSAGE_TEXT = 'Нельзя принимать платежи по расторгнутой сделке.';
    END IF;
    IF p_Amount IS NULL OR p_Amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Сумма платежа должна быть больше нуля.';
    END IF;
    IF p_Method IS NULL OR p_Method NOT IN ('наличные', 'банковская карта', 'перевод', 'ипотека') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Неизвестный способ оплаты.';
    END IF;
    IF p_Purpose IS NULL OR p_Purpose NOT IN ('задаток', 'основной платёж', 'арендная плата', 'комиссия агентства') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Неизвестное назначение платежа.';
    END IF;
    IF v_DealType = 'продажа' AND p_Purpose = 'арендная плата' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Арендная плата не принимается по сделке купли-продажи.';
    END IF;

    IF v_DealType = 'продажа' AND p_Purpose IN ('задаток', 'основной платёж') THEN
        SELECT IFNULL(SUM(Amount), 0) INTO v_Paid FROM Payments
        WHERE DealID = p_DealID AND Purpose IN ('задаток', 'основной платёж');
        IF v_Paid + p_Amount > v_DealAmount THEN
            SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50009, MESSAGE_TEXT = 'Сумма платежей превысит цену договора.';
        END IF;
    END IF;

    INSERT INTO Payments (DealID, Amount, Method, Purpose)
    VALUES (p_DealID, p_Amount, p_Method, p_Purpose);

    SET p_PaymentID = LAST_INSERT_ID();
END$$

/* =====================================================================
   3. ПРОЦЕДУРЫ С ВЫХОДНЫМИ ПАРАМЕТРАМИ И КОДОМ РЕЗУЛЬТАТА
   (кроме уже приведённых Create-процедур с OUT-параметром ID)
   ===================================================================== */

/* ---------------------------------------------------------------------
   proc_Clients_GetStats
   Назначение: статистика клиента как покупателя/арендатора.
   Параметры:  p_ClientID;
               p_DealsCount OUT — число завершённых сделок;
               p_TotalAmount OUT — сумма этих сделок;
               p_ViewingsCount OUT — число показов;
               p_Result OUT — 0 — успешно, -1 — клиент не найден.
   Результат:  значения выходных параметров.
   Пример:     CALL proc_Clients_GetStats(16, @n, @sum, @v, @rc);
               SELECT @rc, @n, @sum, @v;
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Clients_GetStats$$
CREATE PROCEDURE proc_Clients_GetStats(
    IN  p_ClientID      INT,
    OUT p_DealsCount    INT,
    OUT p_TotalAmount   DECIMAL(16,2),
    OUT p_ViewingsCount INT,
    OUT p_Result        INT)
proc: BEGIN
    SET p_DealsCount = NULL, p_TotalAmount = NULL, p_ViewingsCount = NULL;
    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SET p_Result = -1;
        LEAVE proc;
    END IF;

    SELECT COUNT(*), IFNULL(SUM(Amount), 0) INTO p_DealsCount, p_TotalAmount
    FROM Deals
    WHERE ClientID = p_ClientID AND Status = 'завершена';

    SELECT COUNT(*) INTO p_ViewingsCount FROM Viewings WHERE ClientID = p_ClientID;
    SET p_Result = 0;
END$$

/* =====================================================================
   4. ТРАНЗАКЦИОННЫЕ ПРОЦЕДУРЫ (несколько таблиц, обработчик ошибок)
   ===================================================================== */

/* ---------------------------------------------------------------------
   proc_Deals_Create
   Назначение: оформление сделки по активному объекту.
               В одной транзакции: создаётся сделка (статус «оформляется»),
               объект бронируется, при наличии вносится задаток,
               заявка клиента переводится в статус «в работе».
   Параметры:  p_PropertyID, p_ClientID (покупатель/арендатор), p_EmployeeID;
               p_Amount — цена договора (NULL — цена объекта);
               p_CommissionAmount — комиссия (NULL — 3 % для продажи,
                                    50 % месячной платы для аренды);
               p_LeaseMonths — срок аренды в месяцах (NULL — 12);
               p_Deposit — сумма задатка (NULL — без задатка);
               p_DealID OUT — код сделки.
   Результат:  ошибки 50001–50005; при любой ошибке не меняется ничего.
   Пример:     CALL proc_Deals_Create(22, 5, 4, NULL, NULL, NULL, 200000, @id);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Deals_Create$$
CREATE PROCEDURE proc_Deals_Create(
    IN  p_PropertyID       INT,
    IN  p_ClientID         INT,
    IN  p_EmployeeID       INT,
    IN  p_Amount           DECIMAL(14,2),
    IN  p_CommissionAmount DECIMAL(12,2),
    IN  p_LeaseMonths      INT,
    IN  p_Deposit          DECIMAL(14,2),
    OUT p_DealID           INT)
BEGIN
    DECLARE v_Status    VARCHAR(20) DEFAULT NULL;
    DECLARE v_OfferType VARCHAR(10);
    DECLARE v_Price     DECIMAL(14,2);
    DECLARE v_OwnerID   INT;
    DECLARE v_TypeID    INT;
    DECLARE v_LeaseEnd  DATE DEFAULT NULL;
    DECLARE v_Today     DATE DEFAULT (CURDATE());
    DECLARE v_errno     INT;
    DECLARE v_msg       VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        SET p_DealID = NULL;
        CALL proc_ErrorLog_Add('proc_Deals_Create', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_DealID = NULL;
    SELECT Status, OfferType, Price, OwnerClientID, TypeID
    INTO v_Status, v_OfferType, v_Price, v_OwnerID, v_TypeID
    FROM Properties WHERE PropertyID = p_PropertyID;

    IF v_Status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50002, MESSAGE_TEXT = 'Объект недвижимости не найден.';
    END IF;
    IF v_Status <> 'активен' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50005, MESSAGE_TEXT = 'Объект недоступен для сделки (забронирован, продан, сдан или снят).';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50001, MESSAGE_TEXT = 'Покупатель/арендатор не найден.';
    END IF;
    IF p_ClientID = v_OwnerID THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Покупатель не может совпадать с собственником объекта.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Employees WHERE EmployeeID = p_EmployeeID AND IsActive) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50003, MESSAGE_TEXT = 'Агент не найден или не работает в агентстве.';
    END IF;

    SET p_Amount = IFNULL(p_Amount, v_Price);
    IF p_Amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Цена договора должна быть больше нуля.';
    END IF;
    SET p_CommissionAmount = IFNULL(p_CommissionAmount,
                                    IF(v_OfferType = 'продажа', ROUND(p_Amount * 0.03, -2), ROUND(p_Amount * 0.5, -2)));
    IF p_CommissionAmount < 0 OR p_CommissionAmount > p_Amount THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Комиссия должна быть от 0 до суммы договора.';
    END IF;
    IF v_OfferType = 'аренда' THEN
        SET p_LeaseMonths = IFNULL(p_LeaseMonths, 12);
        IF p_LeaseMonths NOT BETWEEN 1 AND 120 THEN
            SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Срок аренды должен быть от 1 до 120 месяцев.';
        END IF;
        SET v_LeaseEnd = v_Today + INTERVAL p_LeaseMonths MONTH - INTERVAL 1 DAY;
    END IF;
    IF p_Deposit IS NOT NULL AND (p_Deposit <= 0 OR p_Deposit > p_Amount) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Задаток должен быть больше нуля и не больше цены договора.';
    END IF;

    START TRANSACTION;
        INSERT INTO Deals (PropertyID, ClientID, EmployeeID, DealType, DealDate, Amount,
                           CommissionAmount, LeaseEndDate, Status)
        VALUES (p_PropertyID, p_ClientID, p_EmployeeID, v_OfferType, v_Today, p_Amount,
                p_CommissionAmount, v_LeaseEnd, 'оформляется');
        SET p_DealID = LAST_INSERT_ID();

        UPDATE Properties SET Status = 'забронирован' WHERE PropertyID = p_PropertyID;

        IF p_Deposit IS NOT NULL THEN
            INSERT INTO Payments (DealID, PaymentDate, Amount, Method, Purpose)
            VALUES (p_DealID, v_Today, p_Deposit, 'перевод', 'задаток');
        END IF;

        UPDATE Requests
        SET Status = 'в работе', EmployeeID = IFNULL(EmployeeID, p_EmployeeID)
        WHERE ClientID = p_ClientID AND OfferType = v_OfferType AND TypeID = v_TypeID
          AND Status IN ('открыта', 'в работе');

        -- запланированные показы этого объекта другим клиентам отменяются
        UPDATE Viewings
        SET Result = 'отменён', Comment = 'Объект забронирован'
        WHERE PropertyID = p_PropertyID AND Result = 'запланирован' AND ClientID <> p_ClientID;
    COMMIT;
END$$

/* ---------------------------------------------------------------------
   proc_Deals_Complete
   Назначение: завершение сделки. В одной транзакции:
               — продажа: вносится остаток цены (основной платёж);
               — аренда: вносятся первый месяц аренды и комиссия агентства;
               — сделка → «завершена», объект → «продан»/«сдан»,
                 заявки клиента на такой объект → «закрыта».
   Параметры:  p_DealID; p_PaymentMethod — способ оплаты остатка (NULL — 'перевод').
   Результат:  ошибки 50004, 50007, 50008; при ошибке не меняется ничего.
   Пример:     CALL proc_Deals_Complete(20, 'ипотека');
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Deals_Complete$$
CREATE PROCEDURE proc_Deals_Complete(
    IN p_DealID        INT,
    IN p_PaymentMethod VARCHAR(20))
BEGIN
    DECLARE v_Status     VARCHAR(15) DEFAULT NULL;
    DECLARE v_DealType   VARCHAR(10);
    DECLARE v_Amount     DECIMAL(14,2);
    DECLARE v_Commission DECIMAL(12,2);
    DECLARE v_PropertyID INT;
    DECLARE v_ClientID   INT;
    DECLARE v_TypeID     INT;
    DECLARE v_Paid       DECIMAL(14,2);
    DECLARE v_Today      DATE DEFAULT (CURDATE());
    DECLARE v_errno      INT;
    DECLARE v_msg        VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Deals_Complete', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_PaymentMethod = IFNULL(p_PaymentMethod, 'перевод');
    SELECT dl.Status, dl.DealType, dl.Amount, dl.CommissionAmount, dl.PropertyID, dl.ClientID, p.TypeID
    INTO v_Status, v_DealType, v_Amount, v_Commission, v_PropertyID, v_ClientID, v_TypeID
    FROM Deals AS dl
    JOIN Properties AS p ON p.PropertyID = dl.PropertyID
    WHERE dl.DealID = p_DealID;

    IF v_Status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50007, MESSAGE_TEXT = 'Сделка не найдена.';
    END IF;
    IF v_Status <> 'оформляется' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50008, MESSAGE_TEXT = 'Завершить можно только сделку в статусе «оформляется».';
    END IF;
    IF p_PaymentMethod NOT IN ('наличные', 'банковская карта', 'перевод', 'ипотека') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Неизвестный способ оплаты.';
    END IF;

    START TRANSACTION;
        IF v_DealType = 'продажа' THEN
            SELECT IFNULL(SUM(Amount), 0) INTO v_Paid FROM Payments
            WHERE DealID = p_DealID AND Purpose IN ('задаток', 'основной платёж');
            IF v_Amount - v_Paid > 0 THEN
                INSERT INTO Payments (DealID, PaymentDate, Amount, Method, Purpose)
                VALUES (p_DealID, v_Today, v_Amount - v_Paid, p_PaymentMethod, 'основной платёж');
            END IF;
        ELSE
            INSERT INTO Payments (DealID, PaymentDate, Amount, Method, Purpose)
            VALUES (p_DealID, v_Today, v_Amount, p_PaymentMethod, 'арендная плата');
            IF v_Commission > 0 THEN
                INSERT INTO Payments (DealID, PaymentDate, Amount, Method, Purpose)
                VALUES (p_DealID, v_Today, v_Commission, p_PaymentMethod, 'комиссия агентства');
            END IF;
        END IF;

        UPDATE Deals SET Status = 'завершена' WHERE DealID = p_DealID;

        UPDATE Properties
        SET Status = IF(v_DealType = 'продажа', 'продан', 'сдан')
        WHERE PropertyID = v_PropertyID;

        UPDATE Requests
        SET Status = 'закрыта'
        WHERE ClientID = v_ClientID AND OfferType = v_DealType AND TypeID = v_TypeID
          AND Status IN ('открыта', 'в работе');
    COMMIT;
END$$

/* ---------------------------------------------------------------------
   proc_Deals_Cancel
   Назначение: расторжение сделки, которая ещё оформляется.
               Сделка → «расторгнута», объект снова «активен».
               Внесённый задаток остаётся в истории платежей.
   Параметры:  p_DealID.
   Результат:  ошибки 50007, 50008; при ошибке не меняется ничего.
   Пример:     CALL proc_Deals_Cancel(21);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Deals_Cancel$$
CREATE PROCEDURE proc_Deals_Cancel(IN p_DealID INT)
BEGIN
    DECLARE v_Status     VARCHAR(15) DEFAULT NULL;
    DECLARE v_PropertyID INT;
    DECLARE v_errno      INT;
    DECLARE v_msg        VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Deals_Cancel', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SELECT Status, PropertyID INTO v_Status, v_PropertyID FROM Deals WHERE DealID = p_DealID;
    IF v_Status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50007, MESSAGE_TEXT = 'Сделка не найдена.';
    END IF;
    IF v_Status <> 'оформляется' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50008, MESSAGE_TEXT = 'Расторгнуть можно только сделку в статусе «оформляется».';
    END IF;

    START TRANSACTION;
        UPDATE Deals      SET Status = 'расторгнута' WHERE DealID = p_DealID;
        UPDATE Properties SET Status = 'активен'
        WHERE PropertyID = v_PropertyID AND Status = 'забронирован';
    COMMIT;
END$$

/* =====================================================================
   5. ОТЧЁТНЫЕ ПРОЦЕДУРЫ (GROUP BY, JOIN, агрегаты)
   ===================================================================== */

/* ---------------------------------------------------------------------
   proc_Report_RevenueByPeriod
   Назначение: выручка агентства (комиссия) по месяцам и видам сделок.
   Параметры:  p_DateFrom, p_DateTo — период;
               p_TotalCommission OUT — итоговая выручка за период.
   Результат:  строки «год — месяц — вид сделки»; пустой набор и 0,
               если сделок нет; ошибка 50004 при неверном периоде.
   Пример:     CALL proc_Report_RevenueByPeriod('2026-01-01', '2026-06-30', @total);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Report_RevenueByPeriod$$
CREATE PROCEDURE proc_Report_RevenueByPeriod(
    IN  p_DateFrom        DATE,
    IN  p_DateTo          DATE,
    OUT p_TotalCommission DECIMAL(16,2))
BEGIN
    IF p_DateFrom IS NULL OR p_DateTo IS NULL OR p_DateFrom > p_DateTo THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный период: дата начала позже даты окончания.';
    END IF;

    SELECT YEAR(dl.DealDate)          AS Год,
           MONTH(dl.DealDate)         AS Месяц,
           dl.DealType                AS Вид,
           COUNT(*)                   AS Сделок,
           SUM(dl.Amount)             AS ОбъёмСделок,
           SUM(dl.CommissionAmount)   AS Выручка,
           CAST(AVG(dl.CommissionAmount) AS DECIMAL(12,2)) AS СредняяКомиссия
    FROM Deals AS dl
    WHERE dl.Status = 'завершена'
      AND dl.DealDate BETWEEN p_DateFrom AND p_DateTo
    GROUP BY YEAR(dl.DealDate), MONTH(dl.DealDate), dl.DealType
    ORDER BY Год, Месяц, Вид;

    SELECT IFNULL(SUM(CommissionAmount), 0) INTO p_TotalCommission
    FROM Deals
    WHERE Status = 'завершена' AND DealDate BETWEEN p_DateFrom AND p_DateTo;
END$$

/* ---------------------------------------------------------------------
   proc_Report_AgentPerformance
   Назначение: результативность агентов за период: показы, сделки,
               конверсия показов в сделки, комиссия и доля агента.
   Параметры:  p_DateFrom, p_DateTo;
               p_TotalCommission OUT — сумма комиссий всех агентов за период.
   Результат:  строка на каждого агента (включая агентов без сделок).
   Пример:     CALL proc_Report_AgentPerformance('2026-01-01', '2026-12-31', @total);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Report_AgentPerformance$$
CREATE PROCEDURE proc_Report_AgentPerformance(
    IN  p_DateFrom        DATE,
    IN  p_DateTo          DATE,
    OUT p_TotalCommission DECIMAL(16,2))
BEGIN
    IF p_DateFrom IS NULL OR p_DateTo IS NULL OR p_DateFrom > p_DateTo THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный период.';
    END IF;

    WITH v AS (
        SELECT EmployeeID, COUNT(*) AS Viewings
        FROM Viewings
        WHERE ViewingDateTime >= p_DateFrom
          AND ViewingDateTime <  p_DateTo + INTERVAL 1 DAY
          AND Result <> 'отменён'
        GROUP BY EmployeeID
    ), d AS (
        SELECT EmployeeID,
               COUNT(*)                                               AS Deals,
               SUM(CASE WHEN DealType = 'продажа' THEN 1 ELSE 0 END)  AS Sales,
               SUM(CASE WHEN DealType = 'аренда'  THEN 1 ELSE 0 END)  AS Rents,
               SUM(CommissionAmount)                                  AS Commission
        FROM Deals
        WHERE Status = 'завершена' AND DealDate BETWEEN p_DateFrom AND p_DateTo
        GROUP BY EmployeeID
    )
    SELECT e.EmployeeID                                       AS `№`,
           CONCAT(e.LastName, ' ', e.FirstName)               AS Агент,
           pos.Title                                          AS Должность,
           IFNULL(v.Viewings, 0)                              AS Показов,
           IFNULL(d.Deals, 0)                                 AS Сделок,
           IFNULL(d.Sales, 0)                                 AS Продаж,
           IFNULL(d.Rents, 0)                                 AS Аренд,
           CAST(IF(IFNULL(v.Viewings, 0) = 0, 0, 100.0 * IFNULL(d.Deals, 0) / v.Viewings) AS DECIMAL(5,1)) AS `Конверсия, %`,
           IFNULL(d.Commission, 0)                            AS КомиссияАгентства,
           CAST(IFNULL(d.Commission, 0) * e.CommissionShare / 100 AS DECIMAL(12,2)) AS ДоляАгента
    FROM Employees AS e
    JOIN Positions AS pos ON pos.PositionID = e.PositionID
    LEFT JOIN v ON v.EmployeeID = e.EmployeeID
    LEFT JOIN d ON d.EmployeeID = e.EmployeeID
    WHERE e.CommissionShare > 0 AND e.IsActive
    ORDER BY КомиссияАгентства DESC;

    SELECT IFNULL(SUM(dl.CommissionAmount), 0) INTO p_TotalCommission
    FROM Deals AS dl
    JOIN Employees AS e ON e.EmployeeID = dl.EmployeeID
    WHERE dl.Status = 'завершена' AND dl.DealDate BETWEEN p_DateFrom AND p_DateTo
      AND e.CommissionShare > 0 AND e.IsActive;
END$$

/* ---------------------------------------------------------------------
   proc_Report_DistrictMarket
   Назначение: обзор рынка по районам: число активных предложений,
               средняя / минимальная / максимальная цена, средняя цена за м²,
               число завершённых сделок за всё время.
   Параметры:  p_OfferType — 'продажа' / 'аренда'.
   Результат:  строка на каждый район.
   Пример:     CALL proc_Report_DistrictMarket('продажа');
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Report_DistrictMarket$$
CREATE PROCEDURE proc_Report_DistrictMarket(IN p_OfferType VARCHAR(10))
BEGIN
    IF p_OfferType IS NULL OR p_OfferType NOT IN ('продажа', 'аренда') THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Тип предложения должен быть «продажа» или «аренда».';
    END IF;

    SELECT d.Name                                                               AS Район,
           COUNT(DISTINCT CASE WHEN p.Status = 'активен' THEN p.PropertyID END) AS АктивныхПредложений,
           CAST(AVG(CASE WHEN p.Status = 'активен' THEN p.Price END) AS DECIMAL(14,0))          AS СредняяЦена,
           MIN(CASE WHEN p.Status = 'активен' THEN p.Price END)                                 AS МинЦена,
           MAX(CASE WHEN p.Status = 'активен' THEN p.Price END)                                 AS МаксЦена,
           CAST(AVG(CASE WHEN p.Status = 'активен' THEN p.Price / p.Area END) AS DECIMAL(14,0)) AS СредняяЦенаЗаМ2,
           COUNT(dl.DealID)                                                     AS ЗавершённыхСделок
    FROM Districts       AS d
    LEFT JOIN Properties AS p  ON p.DistrictID = d.DistrictID AND p.OfferType = p_OfferType
    LEFT JOIN Deals      AS dl ON dl.PropertyID = p.PropertyID AND dl.Status = 'завершена'
    GROUP BY d.DistrictID, d.Name
    ORDER BY СредняяЦенаЗаМ2 DESC;
END$$

/* ---------------------------------------------------------------------
   proc_Report_RequestMatches
   Назначение: подбор активных объектов под конкретную заявку клиента.
   Параметры:  p_RequestID; p_Found OUT — сколько объектов подходит.
   Результат:  подходящие объекты с запасом бюджета; ошибка 50011.
   Пример:     CALL proc_Report_RequestMatches(16, @found);
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_Report_RequestMatches$$
CREATE PROCEDURE proc_Report_RequestMatches(
    IN  p_RequestID INT,
    OUT p_Found     INT)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Requests WHERE RequestID = p_RequestID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50011, MESSAGE_TEXT = 'Заявка не найдена.';
    END IF;

    DROP TEMPORARY TABLE IF EXISTS tmp_matches;
    CREATE TEMPORARY TABLE tmp_matches AS
    SELECT r.RequestID                            AS Заявка,
           CONCAT(c.LastName, ' ', c.FirstName)   AS Клиент,
           p.PropertyID                           AS `№ объекта`,
           d.Name                                 AS Район,
           p.Address                              AS Адрес,
           p.Rooms                                AS Комнат,
           p.Area                                 AS Площадь,
           p.Price                                AS Цена,
           r.MaxBudget - p.Price                  AS ЗапасБюджета
    FROM Requests   AS r
    JOIN Clients    AS c ON c.ClientID = r.ClientID
    JOIN Properties AS p ON p.TypeID    = r.TypeID
                        AND p.OfferType = r.OfferType
                        AND p.Status    = 'активен'
                        AND p.Price    <= r.MaxBudget
                        AND p.OwnerClientID <> r.ClientID
                        AND (r.DistrictID IS NULL OR p.DistrictID = r.DistrictID)
                        AND (r.MinRooms   IS NULL OR p.Rooms     >= r.MinRooms)
                        AND (r.MinArea    IS NULL OR p.Area      >= r.MinArea)
    JOIN Districts  AS d ON d.DistrictID = p.DistrictID
    WHERE r.RequestID = p_RequestID;

    SELECT COUNT(*) INTO p_Found FROM tmp_matches;
    SELECT * FROM tmp_matches ORDER BY Цена;
    DROP TEMPORARY TABLE tmp_matches;
END$$

DELIMITER ;

/* ---------------------------------------------------------------------
   Список созданных процедур
   --------------------------------------------------------------------- */
SELECT ROUTINE_NAME AS Процедура, CREATED AS Создана, LAST_ALTERED AS Изменена
FROM information_schema.ROUTINES
WHERE ROUTINE_SCHEMA = 'realty_pm11' AND ROUTINE_TYPE = 'PROCEDURE'
ORDER BY ROUTINE_NAME;
