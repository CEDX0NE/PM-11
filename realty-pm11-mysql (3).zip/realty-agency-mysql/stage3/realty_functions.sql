/* =====================================================================
   Учебная практика ПМ.11, этап 3 — «Разработка пользовательских функций»
   Кейс-задача: «Информационная система риэлторского агентства «КлючДом»»
   Файл: realty_functions.sql
   База данных: realty_pm11 (этапы 1–2)
   СУБД: MySQL 8.0 — запускать в консоли mysql: source путь/к/realty_functions.sql
   Автор: ______________________     Дата: 19.10.2026

   В MySQL пользовательские функции бывают только скалярными
   (CREATE FUNCTION ... RETURNS <тип>). Табличных функций в MySQL нет,
   поэтому типы из задания реализованы так:
     1. Скалярные функции      — fn_<Имя>       (CREATE FUNCTION)
     2. Аналог inline-табличных — tvf_<Имя>     (представление, которое
                                  «параметризуется» условием WHERE; MySQL
                                  подставляет его текст в запрос — алгоритм MERGE)
     3. Аналог многооператорных — proc_tvf_<Имя> (процедура: по шагам заполняет
                                  временную таблицу tvf_<Имя>, которую затем можно
                                  использовать в SELECT и JOIN текущего сеанса)

   Характеристики функций (DETERMINISTIC / NO SQL / READS SQL DATA) указаны
   явно: без них MySQL с включённым двоичным журналом (по умолчанию в 8.0)
   отказывается создавать функцию (ошибка 1418).
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;

DELIMITER $$

/* =====================================================================
   1. СКАЛЯРНЫЕ ФУНКЦИИ
   ===================================================================== */

/* ---------------------------------------------------------------------
   fn_CommissionDefault
   Назначение: стандартная комиссия агентства по сделке:
               продажа — 3 % цены, аренда — 50 % месячной платы,
               с округлением до сотен рублей.
   Параметры:  p_DealType — 'продажа' / 'аренда'; p_Amount — сумма договора.
   Возвращает: DECIMAL(12,2); NULL, если сумма или вид сделки не заданы
               или вид сделки неизвестен; 0 при сумме ≤ 0.
   Пример:     SELECT fn_CommissionDefault('продажа', 10000000);  -- 300000.00
   --------------------------------------------------------------------- */
DROP FUNCTION IF EXISTS fn_CommissionDefault$$
CREATE FUNCTION fn_CommissionDefault(p_DealType VARCHAR(10), p_Amount DECIMAL(14,2))
RETURNS DECIMAL(12,2)
DETERMINISTIC NO SQL
BEGIN
    IF p_Amount IS NULL OR p_DealType IS NULL THEN
        RETURN NULL;
    END IF;
    IF p_Amount <= 0 THEN
        RETURN 0;
    END IF;
    RETURN CASE p_DealType
               WHEN 'продажа' THEN ROUND(p_Amount * 0.03, -2)
               WHEN 'аренда'  THEN ROUND(p_Amount * 0.50, -2)
               ELSE NULL
           END;
END$$

/* ---------------------------------------------------------------------
   fn_PricePerM2
   Назначение: цена за квадратный метр.
   Параметры:  p_Price — цена (или аренда в месяц); p_Area — площадь, м².
   Возвращает: DECIMAL(14,2); NULL, если цена или площадь не заданы
               или площадь ≤ 0 (защита от деления на ноль).
   Пример:     SELECT fn_PricePerM2(10000000, 50);  -- 200000.00
   --------------------------------------------------------------------- */
DROP FUNCTION IF EXISTS fn_PricePerM2$$
CREATE FUNCTION fn_PricePerM2(p_Price DECIMAL(14,2), p_Area DECIMAL(8,2))
RETURNS DECIMAL(14,2)
DETERMINISTIC NO SQL
BEGIN
    IF p_Price IS NULL OR p_Area IS NULL OR p_Area <= 0 THEN
        RETURN NULL;
    END IF;
    RETURN ROUND(p_Price / p_Area, 2);
END$$

/* ---------------------------------------------------------------------
   fn_FormatRub
   Назначение: денежная сумма в читаемом виде для отчётов: «32 570 000 ₽».
   Параметры:  p_Amount — сумма.
   Возвращает: VARCHAR(30); NULL, если сумма не задана.
   Пример:     SELECT fn_FormatRub(32570000);  -- '32 570 000 ₽'
   --------------------------------------------------------------------- */
DROP FUNCTION IF EXISTS fn_FormatRub$$
CREATE FUNCTION fn_FormatRub(p_Amount DECIMAL(16,2))
RETURNS VARCHAR(30)
DETERMINISTIC NO SQL
BEGIN
    IF p_Amount IS NULL THEN
        RETURN NULL;
    END IF;
    RETURN CONCAT(REPLACE(FORMAT(p_Amount, 0), ',', ' '), ' ₽');
END$$

/* ---------------------------------------------------------------------
   fn_AgeYears
   Назначение: полный возраст в годах на сегодняшнюю дату.
   Параметры:  p_BirthDate — дата рождения.
   Возвращает: INT; NULL, если дата не задана или ещё не наступила.
   Пример:     SELECT fn_AgeYears('2000-05-20');
   Примечание: функция недетерминированная — результат зависит от CURDATE().
   --------------------------------------------------------------------- */
DROP FUNCTION IF EXISTS fn_AgeYears$$
CREATE FUNCTION fn_AgeYears(p_BirthDate DATE)
RETURNS INT
NOT DETERMINISTIC NO SQL
BEGIN
    IF p_BirthDate IS NULL OR p_BirthDate > CURDATE() THEN
        RETURN NULL;
    END IF;
    RETURN TIMESTAMPDIFF(YEAR, p_BirthDate, CURDATE());
END$$

/* ---------------------------------------------------------------------
   fn_ClientShortName
   Назначение: фамилия и инициалы клиента: «Иванов С. А.».
   Параметры:  p_ClientID — код клиента.
   Возвращает: VARCHAR(70); NULL, если клиента нет.
   Пример:     SELECT fn_ClientShortName(1);  -- 'Иванов С. А.'
   --------------------------------------------------------------------- */
DROP FUNCTION IF EXISTS fn_ClientShortName$$
CREATE FUNCTION fn_ClientShortName(p_ClientID INT)
RETURNS VARCHAR(70)
READS SQL DATA
BEGIN
    DECLARE v_name VARCHAR(70) DEFAULT NULL;
    SELECT CONCAT(LastName, ' ', LEFT(FirstName, 1), '.',
                  IF(MiddleName IS NULL OR MiddleName = '', '', CONCAT(' ', LEFT(MiddleName, 1), '.')))
    INTO v_name
    FROM Clients
    WHERE ClientID = p_ClientID;
    RETURN v_name;
END$$

/* ---------------------------------------------------------------------
   fn_DealPaidPercent
   Назначение: какая доля цены договора уже оплачена, в процентах.
               Продажа — задаток и основные платежи; аренда — арендная плата
               (комиссия агентства не учитывается).
   Параметры:  p_DealID — код сделки.
   Возвращает: DECIMAL(5,1) от 0 до 100; NULL, если сделки нет.
   Пример:     SELECT fn_DealPaidPercent(20);  -- 2.2 (внесён только задаток)
   --------------------------------------------------------------------- */
DROP FUNCTION IF EXISTS fn_DealPaidPercent$$
CREATE FUNCTION fn_DealPaidPercent(p_DealID INT)
RETURNS DECIMAL(5,1)
READS SQL DATA
BEGIN
    DECLARE v_type   VARCHAR(10) DEFAULT NULL;
    DECLARE v_amount DECIMAL(14,2);
    DECLARE v_paid   DECIMAL(16,2);

    SELECT DealType, Amount INTO v_type, v_amount FROM Deals WHERE DealID = p_DealID;
    IF v_type IS NULL OR v_amount IS NULL OR v_amount <= 0 THEN
        RETURN NULL;
    END IF;

    SELECT IFNULL(SUM(Amount), 0) INTO v_paid
    FROM Payments
    WHERE DealID = p_DealID
      AND Purpose IN (IF(v_type = 'продажа', 'задаток', 'арендная плата'),
                      IF(v_type = 'продажа', 'основной платёж', 'арендная плата'));

    RETURN LEAST(100, ROUND(v_paid / v_amount * 100, 1));
END$$

DELIMITER ;

/* =====================================================================
   2. АНАЛОГ INLINE-ТАБЛИЧНЫХ ФУНКЦИЙ — «параметризуемые» представления
   В SQL Server это была бы функция RETURNS TABLE с одним SELECT.
   В MySQL тот же результат даёт представление: параметры передаются
   условием WHERE, а MySQL встраивает текст представления в запрос
   (ALGORITHM = MERGE), поэтому фильтр работает по индексам таблиц.
   ===================================================================== */

/* ---------------------------------------------------------------------
   tvf_ClientDeals
   Назначение: сделки клиента (как покупателя или арендатора) с объектом,
               агентом и процентом оплаты.
   «Параметры»: ClientID, DealDate (через WHERE).
   Пример:     SELECT * FROM tvf_ClientDeals
               WHERE ClientID = 16 AND DealDate BETWEEN '2026-01-01' AND '2026-12-31';
   --------------------------------------------------------------------- */
CREATE OR REPLACE ALGORITHM = MERGE VIEW tvf_ClientDeals AS
SELECT dl.ClientID,
       dl.DealID,
       dl.DealDate,
       dl.DealType,
       p.Address,
       dl.Amount,
       dl.CommissionAmount,
       dl.Status,
       fn_ClientShortName(dl.ClientID)          AS Клиент,
       CONCAT(e.LastName, ' ', e.FirstName)     AS Агент,
       fn_DealPaidPercent(dl.DealID)            AS ОплаченоПроцентов
FROM Deals      AS dl
JOIN Properties AS p ON p.PropertyID = dl.PropertyID
JOIN Employees  AS e ON e.EmployeeID = dl.EmployeeID;

/* ---------------------------------------------------------------------
   tvf_ActiveOffers
   Назначение: актуальные предложения с типом, районом, ценой за м²
               и ценой в читаемом виде — основа для подбора под заявку.
   «Параметры»: OfferType, TypeID, DistrictID, Rooms, Area, Price (через WHERE)
               или условия соединения с таблицей Requests.
   Пример:     SELECT * FROM tvf_ActiveOffers
               WHERE OfferType = 'продажа' AND TypeID = 1 AND Price <= 25000000;
   --------------------------------------------------------------------- */
CREATE OR REPLACE ALGORITHM = MERGE VIEW tvf_ActiveOffers AS
SELECT p.PropertyID,
       p.OfferType,
       p.TypeID,
       t.Name                                AS TypeName,
       p.DistrictID,
       d.Name                                AS District,
       p.Address,
       p.Rooms,
       p.Area,
       p.Price,
       p.OwnerClientID,
       fn_PricePerM2(p.Price, p.Area)        AS PricePerM2,
       fn_FormatRub(p.Price)                 AS PriceText,
       DATEDIFF(CURDATE(), p.ListedAt)       AS DaysListed
FROM Properties    AS p
JOIN PropertyTypes AS t ON t.TypeID     = p.TypeID
JOIN Districts     AS d ON d.DistrictID = p.DistrictID
WHERE p.Status = 'активен';

/* =====================================================================
   3. АНАЛОГ МНОГООПЕРАТОРНЫХ ТАБЛИЧНЫХ ФУНКЦИЙ — процедура + временная таблица
   В SQL Server это была бы функция RETURNS @t TABLE (...), заполняемая по шагам.
   В MySQL функция не может вернуть таблицу, поэтому процедура создаёт временную
   таблицу tvf_<Имя>, заполняет её в несколько шагов с ветвлениями IF/ELSEIF
   и выводит. Временная таблица живёт до конца сеанса, поэтому после CALL
   её можно использовать в SELECT и JOIN как результат функции.
   ===================================================================== */

DELIMITER $$

/* ---------------------------------------------------------------------
   proc_tvf_AgentRating
   Назначение: рейтинг агентов за период. Для каждого агента считаются
               сделки, показы, конверсия и комиссия, затем по правилам
               присваивается категория:
                 «лидер»        — комиссия агентства ≥ 1 000 000 руб.;
                 «стабильно»    — иначе, если сделок ≥ 3;
                 «развивается»  — иначе, если есть хотя бы одна сделка;
                 «нет сделок»   — сделок за период нет.
   Параметры:  p_DateFrom, p_DateTo — период.
   Результат:  временная таблица tvf_AgentRating (и её вывод);
               ошибка 50004 при неверном периоде.
   Пример:     CALL proc_tvf_AgentRating('2026-01-01', '2026-12-31');
               SELECT * FROM tvf_AgentRating WHERE Rating = 'лидер';
   Почему не inline: результат строится в несколько шагов — сначала
               агрегаты по двум разным таблицам (сделки и показы), затем
               расчёт конверсии и классификация с ветвлениями.
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_tvf_AgentRating$$
CREATE PROCEDURE proc_tvf_AgentRating(IN p_DateFrom DATE, IN p_DateTo DATE)
BEGIN
    DECLARE v_done     BOOLEAN DEFAULT FALSE;
    DECLARE v_id       INT;
    DECLARE v_deals    INT;
    DECLARE v_views    INT;
    DECLARE v_comm     DECIMAL(16,2);
    DECLARE v_rating   VARCHAR(20);
    DECLARE cur CURSOR FOR
        SELECT EmployeeID FROM Employees WHERE CommissionShare > 0 AND IsActive ORDER BY EmployeeID;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    IF p_DateFrom IS NULL OR p_DateTo IS NULL OR p_DateFrom > p_DateTo THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный период.';
    END IF;

    -- шаг 1: пустая «таблица-результат»
    DROP TEMPORARY TABLE IF EXISTS tvf_AgentRating;
    CREATE TEMPORARY TABLE tvf_AgentRating (
        EmployeeID   INT PRIMARY KEY,
        Agent        VARCHAR(101),
        Deals        INT,
        Viewings     INT,
        Conversion   DECIMAL(5,1),
        Commission   DECIMAL(16,2),
        Rating       VARCHAR(20)
    );

    -- шаг 2: построчный расчёт показателей и классификация
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_id;
        IF v_done THEN
            LEAVE read_loop;
        END IF;

        SELECT COUNT(*), IFNULL(SUM(CommissionAmount), 0) INTO v_deals, v_comm
        FROM Deals
        WHERE EmployeeID = v_id AND Status = 'завершена' AND DealDate BETWEEN p_DateFrom AND p_DateTo;

        SELECT COUNT(*) INTO v_views
        FROM Viewings
        WHERE EmployeeID = v_id AND Result <> 'отменён'
          AND ViewingDateTime >= p_DateFrom AND ViewingDateTime < p_DateTo + INTERVAL 1 DAY;

        IF v_comm >= 1000000 THEN
            SET v_rating = 'лидер';
        ELSEIF v_deals >= 3 THEN
            SET v_rating = 'стабильно';
        ELSEIF v_deals >= 1 THEN
            SET v_rating = 'развивается';
        ELSE
            SET v_rating = 'нет сделок';
        END IF;

        INSERT INTO tvf_AgentRating (EmployeeID, Agent, Deals, Viewings, Conversion, Commission, Rating)
        SELECT v_id, CONCAT(LastName, ' ', FirstName), v_deals, v_views,
               IF(v_views = 0, 0, ROUND(100.0 * v_deals / v_views, 1)), v_comm, v_rating
        FROM Employees WHERE EmployeeID = v_id;
    END LOOP;
    CLOSE cur;

    -- шаг 3: вывод результата
    SELECT * FROM tvf_AgentRating ORDER BY Commission DESC;
END$$

/* ---------------------------------------------------------------------
   proc_tvf_ListingStatus
   Назначение: оценка актуальных предложений относительно рынка.
               Для каждого активного объекта цена за м² сравнивается со
               средней ценой за м² объектов того же типа, вида предложения
               и района (по всем объектам базы, включая проданные):
                 «ниже рынка» — меньше 95 % средней;
                 «выше рынка» — больше 105 % средней;
                 «в рынке»    — в остальных случаях.
               Отдельно отмечаются объекты, которые размещены более 90 дней
               («залежался» — повод пересмотреть цену).
   Параметры:  нет.
   Результат:  временная таблица tvf_ListingStatus (и её вывод).
   Пример:     CALL proc_tvf_ListingStatus();
               SELECT * FROM tvf_ListingStatus WHERE MarketStatus = 'выше рынка';
   Почему не inline: сначала нужно посчитать средние по группам,
               затем сравнить с ними каждый объект и классифицировать.
   --------------------------------------------------------------------- */
DROP PROCEDURE IF EXISTS proc_tvf_ListingStatus$$
CREATE PROCEDURE proc_tvf_ListingStatus()
BEGIN
    -- шаг 1: средняя цена за м² по группам «тип + вид предложения + район»
    DROP TEMPORARY TABLE IF EXISTS tmp_market_avg;
    CREATE TEMPORARY TABLE tmp_market_avg AS
    SELECT TypeID, OfferType, DistrictID, AVG(fn_PricePerM2(Price, Area)) AS AvgPerM2, COUNT(*) AS Objects
    FROM Properties
    GROUP BY TypeID, OfferType, DistrictID;

    -- шаг 2: «таблица-результат» с активными объектами
    DROP TEMPORARY TABLE IF EXISTS tvf_ListingStatus;
    CREATE TEMPORARY TABLE tvf_ListingStatus (
        PropertyID    INT PRIMARY KEY,
        Address       VARCHAR(200),
        OfferType     VARCHAR(10),
        PricePerM2    DECIMAL(14,2),
        MarketPerM2   DECIMAL(14,2),
        Ratio         DECIMAL(6,3),
        DaysListed    INT,
        MarketStatus  VARCHAR(20),
        Stale         VARCHAR(20)
    );
    INSERT INTO tvf_ListingStatus (PropertyID, Address, OfferType, PricePerM2, MarketPerM2, DaysListed)
    SELECT p.PropertyID, p.Address, p.OfferType, fn_PricePerM2(p.Price, p.Area), m.AvgPerM2,
           DATEDIFF(CURDATE(), p.ListedAt)
    FROM Properties AS p
    JOIN tmp_market_avg AS m
      ON m.TypeID = p.TypeID AND m.OfferType = p.OfferType AND m.DistrictID = p.DistrictID
    WHERE p.Status = 'активен';

    -- шаг 3: сравнение с рынком и классификация
    UPDATE tvf_ListingStatus
    SET Ratio = IF(MarketPerM2 IS NULL OR MarketPerM2 = 0, 1, PricePerM2 / MarketPerM2);

    UPDATE tvf_ListingStatus
    SET MarketStatus = CASE
                           WHEN Ratio < 0.95 THEN 'ниже рынка'
                           WHEN Ratio > 1.05 THEN 'выше рынка'
                           ELSE 'в рынке'
                       END,
        Stale = IF(DaysListed > 90, 'залежался', 'нет');

    DROP TEMPORARY TABLE IF EXISTS tmp_market_avg;

    -- шаг 4: вывод результата
    SELECT * FROM tvf_ListingStatus ORDER BY Ratio DESC;
END$$

DELIMITER ;

/* =====================================================================
   4. ПРИМЕНЕНИЕ ФУНКЦИЙ В СУЩЕСТВУЮЩИХ ОБЪЕКТАХ ЭТАПОВ 1–2
   ===================================================================== */

-- 4.1. Представление этапа 1: цена за м² считается функцией, а не формулой
CREATE OR REPLACE VIEW v_ActiveListings AS
SELECT
    p.PropertyID                                   AS PropertyID,
    p.OfferType                                    AS ТипПредложения,
    t.Name                                         AS ТипОбъекта,
    d.Name                                         AS Район,
    p.Address                                      AS Адрес,
    p.Area                                         AS Площадь,
    p.Rooms                                        AS Комнат,
    p.Price                                        AS Цена,
    fn_PricePerM2(p.Price, p.Area)                 AS ЦенаЗаМ2,
    CONCAT(e.LastName, ' ', e.FirstName)           AS Агент,
    e.Phone                                        AS ТелефонАгента,
    p.ListedAt                                     AS ДатаРазмещения
FROM Properties    AS p
JOIN PropertyTypes AS t ON t.TypeID     = p.TypeID
JOIN Districts     AS d ON d.DistrictID = p.DistrictID
JOIN Employees     AS e ON e.EmployeeID = p.EmployeeID
WHERE p.Status = 'активен';

-- 4.2. Процедуры этапа 2, переписанные с использованием функций:
--      proc_Clients_Create  — проверка совершеннолетия через fn_AgeYears;
--      proc_Deals_Create    — комиссия по умолчанию через fn_CommissionDefault.
--      Поведение процедур не изменилось — это подтверждает повторный запуск
--      тестов этапа 2 (realty_procedures_tests.sql).

DELIMITER $$

DROP PROCEDURE IF EXISTS proc_Clients_Create$$
CREATE PROCEDURE proc_Clients_Create(
    IN  p_LastName   VARCHAR(50),
    IN  p_FirstName  VARCHAR(50),
    IN  p_MiddleName VARCHAR(50),
    IN  p_BirthDate  DATE,
    IN  p_Phone      VARCHAR(12),
    IN  p_Email      VARCHAR(100),
    OUT p_ClientID   INT)
BEGIN
    DECLARE v_errno INT;
    DECLARE v_msg   VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        CALL proc_ErrorLog_Add('proc_Clients_Create', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_ClientID = NULL;
    IF NULLIF(TRIM(p_LastName), '') IS NULL OR NULLIF(TRIM(p_FirstName), '') IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Фамилия и имя клиента обязательны.';
    END IF;
    IF p_Phone IS NULL OR p_Phone NOT REGEXP '^\\+7[0-9]{10}$' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Телефон должен быть в формате +7XXXXXXXXXX.';
    END IF;
    IF p_BirthDate IS NULL OR IFNULL(fn_AgeYears(p_BirthDate), 0) < 18 THEN   -- этап 3: функция вместо формулы
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Клиент должен быть совершеннолетним.';
    END IF;
    IF p_Email IS NOT NULL AND p_Email NOT LIKE '%_@_%._%' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Некорректный адрес e-mail.';
    END IF;
    IF EXISTS (SELECT 1 FROM Clients WHERE Phone = p_Phone) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50006, MESSAGE_TEXT = 'Клиент с таким телефоном уже зарегистрирован.';
    END IF;
    IF p_Email IS NOT NULL AND EXISTS (SELECT 1 FROM Clients WHERE Email = p_Email) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50006, MESSAGE_TEXT = 'Клиент с таким e-mail уже зарегистрирован.';
    END IF;

    INSERT INTO Clients (LastName, FirstName, MiddleName, BirthDate, Phone, Email)
    VALUES (TRIM(p_LastName), TRIM(p_FirstName), NULLIF(TRIM(p_MiddleName), ''), p_BirthDate, p_Phone, p_Email);

    SET p_ClientID = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS proc_Deals_Create$$
CREATE PROCEDURE proc_Deals_Create(
    IN  p_PropertyID       INT,
    IN  p_ClientID         INT,
    IN  p_EmployeeID       INT,
    IN  p_Amount           DECIMAL(14,2),
    IN  p_CommissionAmount DECIMAL(12,2),
    IN  p_LeaseMonths      INT,
    IN  p_Deposit          DECIMAL(14,2),
    OUT p_DealID           INT)
BEGIN
    DECLARE v_Status    VARCHAR(20) DEFAULT NULL;
    DECLARE v_OfferType VARCHAR(10);
    DECLARE v_Price     DECIMAL(14,2);
    DECLARE v_OwnerID   INT;
    DECLARE v_TypeID    INT;
    DECLARE v_LeaseEnd  DATE DEFAULT NULL;
    DECLARE v_Today     DATE DEFAULT (CURDATE());
    DECLARE v_errno     INT;
    DECLARE v_msg       VARCHAR(1000);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        SET p_DealID = NULL;
        CALL proc_ErrorLog_Add('proc_Deals_Create', v_errno, v_msg);
        SET v_msg = LEFT(v_msg, 128);
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = v_errno, MESSAGE_TEXT = v_msg;
    END;

    SET p_DealID = NULL;
    SELECT Status, OfferType, Price, OwnerClientID, TypeID
    INTO v_Status, v_OfferType, v_Price, v_OwnerID, v_TypeID
    FROM Properties WHERE PropertyID = p_PropertyID;

    IF v_Status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50002, MESSAGE_TEXT = 'Объект недвижимости не найден.';
    END IF;
    IF v_Status <> 'активен' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50005, MESSAGE_TEXT = 'Объект недоступен для сделки (забронирован, продан, сдан или снят).';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Clients WHERE ClientID = p_ClientID) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50001, MESSAGE_TEXT = 'Покупатель/арендатор не найден.';
    END IF;
    IF p_ClientID = v_OwnerID THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Покупатель не может совпадать с собственником объекта.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Employees WHERE EmployeeID = p_EmployeeID AND IsActive) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50003, MESSAGE_TEXT = 'Агент не найден или не работает в агентстве.';
    END IF;

    SET p_Amount = IFNULL(p_Amount, v_Price);
    IF p_Amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Цена договора должна быть больше нуля.';
    END IF;
    -- этап 3: стандартная комиссия считается функцией (раньше здесь была формула)
    SET p_CommissionAmount = IFNULL(p_CommissionAmount, fn_CommissionDefault(v_OfferType, p_Amount));
    IF p_CommissionAmount < 0 OR p_CommissionAmount > p_Amount THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Комиссия должна быть от 0 до суммы договора.';
    END IF;
    IF v_OfferType = 'аренда' THEN
        SET p_LeaseMonths = IFNULL(p_LeaseMonths, 12);
        IF p_LeaseMonths NOT BETWEEN 1 AND 120 THEN
            SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Срок аренды должен быть от 1 до 120 месяцев.';
        END IF;
        SET v_LeaseEnd = v_Today + INTERVAL p_LeaseMonths MONTH - INTERVAL 1 DAY;
    END IF;
    IF p_Deposit IS NOT NULL AND (p_Deposit <= 0 OR p_Deposit > p_Amount) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50004, MESSAGE_TEXT = 'Задаток должен быть больше нуля и не больше цены договора.';
    END IF;

    START TRANSACTION;
        INSERT INTO Deals (PropertyID, ClientID, EmployeeID, DealType, DealDate, Amount,
                           CommissionAmount, LeaseEndDate, Status)
        VALUES (p_PropertyID, p_ClientID, p_EmployeeID, v_OfferType, v_Today, p_Amount,
                p_CommissionAmount, v_LeaseEnd, 'оформляется');
        SET p_DealID = LAST_INSERT_ID();

        UPDATE Properties SET Status = 'забронирован' WHERE PropertyID = p_PropertyID;

        IF p_Deposit IS NOT NULL THEN
            INSERT INTO Payments (DealID, PaymentDate, Amount, Method, Purpose)
            VALUES (p_DealID, v_Today, p_Deposit, 'перевод', 'задаток');
        END IF;

        UPDATE Requests
        SET Status = 'в работе', EmployeeID = IFNULL(EmployeeID, p_EmployeeID)
        WHERE ClientID = p_ClientID AND OfferType = v_OfferType AND TypeID = v_TypeID
          AND Status IN ('открыта', 'в работе');

        -- запланированные показы этого объекта другим клиентам отменяются
        UPDATE Viewings
        SET Result = 'отменён', Comment = 'Объект забронирован'
        WHERE PropertyID = p_PropertyID AND Result = 'запланирован' AND ClientID <> p_ClientID;
    COMMIT;
END$$

DELIMITER ;

/* ---------------------------------------------------------------------
   Список функций и процедур-аналогов этапа 3
   --------------------------------------------------------------------- */
SELECT ROUTINE_TYPE AS Тип, ROUTINE_NAME AS Имя, DATA_TYPE AS Возвращает,
       IS_DETERMINISTIC AS Детерминированная, SQL_DATA_ACCESS AS ДоступКДанным
FROM information_schema.ROUTINES
WHERE ROUTINE_SCHEMA = 'realty_pm11'
  AND (ROUTINE_NAME LIKE 'fn\_%' OR ROUTINE_NAME LIKE 'proc\_tvf\_%')
ORDER BY ROUTINE_TYPE, ROUTINE_NAME;

SELECT TABLE_NAME AS Представление FROM information_schema.VIEWS
WHERE TABLE_SCHEMA = 'realty_pm11' AND TABLE_NAME LIKE 'tvf\_%';
