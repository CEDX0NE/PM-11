/* =====================================================================
   Учебная практика ПМ.11, этап 3 — демонстрация и тестирование функций
   Файл: realty_functions_tests.sql
   СУБД: MySQL 8.0
   Запуск: после realty_functions.sql, на базе с тестовыми данными этапа 1.
   В скрипте нет DELIMITER, поэтому его можно выполнять и в VS Code,
   и в консоли mysql (source путь/к/realty_functions_tests.sql).

   Часть 1 — демонстрационные запросы (функции в SELECT, WHERE, ORDER BY,
             JOIN и подзапросах).
   Часть 2 — автотесты: результат каждой проверки записывается в таблицу
             test_functions со статусом PASS / FAIL.
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;

/* =====================================================================
   ЧАСТЬ 1. ДЕМОНСТРАЦИОННЫЕ ЗАПРОСЫ
   ===================================================================== */

-- Д1. Скалярные функции в SELECT, WHERE и ORDER BY:
--     квартиры дешевле 300 000 руб. за м², от дешёвых к дорогим
SELECT PropertyID                          AS `№`,
       Address                             AS Адрес,
       fn_FormatRub(Price)                 AS Цена,
       fn_PricePerM2(Price, Area)          AS ЦенаЗаМ2,
       fn_ClientShortName(OwnerClientID)   AS Собственник
FROM Properties
WHERE OfferType = 'продажа' AND TypeID = 1
  AND fn_PricePerM2(Price, Area) < 300000
ORDER BY fn_PricePerM2(Price, Area);

-- Д2. Скалярная функция как «ручная» проверка данных: совпадает ли комиссия
--     в сделках со стандартной (расхождения — договорные скидки)
SELECT DealID AS `№ сделки`, DealType AS Вид, fn_FormatRub(Amount) AS Сумма,
       CommissionAmount AS Комиссия, fn_CommissionDefault(DealType, Amount) AS Стандартная,
       CommissionAmount - fn_CommissionDefault(DealType, Amount) AS Разница
FROM Deals
ORDER BY DealID;

-- Д3. Возраст клиентов: средний возраст покупателей и арендаторов
SELECT dl.DealType AS Вид, COUNT(*) AS Сделок, ROUND(AVG(fn_AgeYears(c.BirthDate)), 1) AS СреднийВозраст
FROM Deals AS dl
JOIN Clients AS c ON c.ClientID = dl.ClientID
WHERE dl.Status = 'завершена'
GROUP BY dl.DealType;

-- Д4. Аналог inline-табличной функции: сделки клиента № 16 за 2026 год
SELECT * FROM tvf_ClientDeals
WHERE ClientID = 16 AND DealDate BETWEEN '2026-01-01' AND '2026-12-31';

-- Д5. tvf_ActiveOffers в JOIN: подбор предложений под все открытые заявки
SELECT r.RequestID                          AS `№ заявки`,
       fn_ClientShortName(r.ClientID)       AS Клиент,
       o.Address                            AS Объект,
       o.PriceText                          AS Цена,
       o.PricePerM2                         AS ЦенаЗаМ2
FROM Requests AS r
JOIN tvf_ActiveOffers AS o
  ON o.TypeID = r.TypeID AND o.OfferType = r.OfferType
 AND o.Price <= r.MaxBudget
 AND o.OwnerClientID <> r.ClientID
 AND (r.DistrictID IS NULL OR o.DistrictID = r.DistrictID)
 AND (r.MinRooms   IS NULL OR o.Rooms     >= r.MinRooms)
 AND (r.MinArea    IS NULL OR o.Area      >= r.MinArea)
WHERE r.Status IN ('открыта', 'в работе')
ORDER BY r.RequestID, o.Price;

-- Д6. tvf_ActiveOffers в подзапросе: районы, где есть предложения дешевле
--     средней цены за м² по всей базе
SELECT DISTINCT District AS Район
FROM tvf_ActiveOffers
WHERE OfferType = 'продажа'
  AND PricePerM2 < (SELECT AVG(fn_PricePerM2(Price, Area)) FROM Properties WHERE OfferType = 'продажа')
ORDER BY District;

-- Д7. Аналог многооператорной функции: рейтинг агентов, затем JOIN с её результатом
CALL proc_tvf_AgentRating('2025-01-01', '2026-12-31');
SELECT r.Agent AS Агент, r.Rating AS Рейтинг, pos.Title AS Должность, fn_FormatRub(r.Commission) AS Комиссия
FROM tvf_AgentRating AS r
JOIN Employees AS e   ON e.EmployeeID  = r.EmployeeID
JOIN Positions AS pos ON pos.PositionID = e.PositionID
ORDER BY r.Commission DESC;

-- Д8. Оценка предложений относительно рынка
CALL proc_tvf_ListingStatus();

-- Д9. Цена использования скалярной функции: сравните время двух команд
--     (MySQL выводит время выполнения каждой команды)
SELECT BENCHMARK(1000000, fn_PricePerM2(10000000, 50))   AS `Функция, 1 млн вызовов`;
SELECT BENCHMARK(1000000, ROUND(10000000 / 50, 2))        AS `Выражение, 1 млн раз`;

/* =====================================================================
   ЧАСТЬ 2. АВТОТЕСТЫ
   ===================================================================== */

DROP TABLE IF EXISTS test_functions;
CREATE TABLE test_functions (
    N          INT AUTO_INCREMENT PRIMARY KEY,
    Объект     VARCHAR(40),
    Сценарий   VARCHAR(150),
    Ожидается  VARCHAR(100),
    Фактически VARCHAR(200),
    Статус     VARCHAR(4)
);

-- ---------- fn_CommissionDefault ----------
SET @r = fn_CommissionDefault('продажа', 10000000);
INSERT INTO test_functions VALUES (NULL, 'fn_CommissionDefault', 'Продажа за 10 000 000', '300000.00', IFNULL(@r, 'NULL'), IF(@r = 300000, 'PASS', 'FAIL'));
SET @r = fn_CommissionDefault('аренда', 95000);
INSERT INTO test_functions VALUES (NULL, 'fn_CommissionDefault', 'Аренда 95 000 в месяц', '47500.00', IFNULL(@r, 'NULL'), IF(@r = 47500, 'PASS', 'FAIL'));
SET @r = fn_CommissionDefault('продажа', NULL);
INSERT INTO test_functions VALUES (NULL, 'fn_CommissionDefault', 'Сумма NULL', 'NULL без ошибки', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));
SET @r = fn_CommissionDefault('продажа', 0);
INSERT INTO test_functions VALUES (NULL, 'fn_CommissionDefault', 'Сумма 0', '0.00', IFNULL(@r, 'NULL'), IF(@r = 0, 'PASS', 'FAIL'));
SET @r = fn_CommissionDefault('обмен', 1000000);
INSERT INTO test_functions VALUES (NULL, 'fn_CommissionDefault', 'Неизвестный вид сделки «обмен»', 'NULL', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));
SET @r = (SELECT COUNT(*) FROM Deals WHERE CommissionAmount <> fn_CommissionDefault(DealType, Amount));
INSERT INTO test_functions VALUES (NULL, 'fn_CommissionDefault', 'Сверка с комиссией во всех 20 сделках (ручной расчёт)', '0 расхождений', CONCAT(@r, ' расхождений'), IF(@r = 0, 'PASS', 'FAIL'));

-- ---------- fn_PricePerM2 ----------
SET @r = fn_PricePerM2(10000000, 50);
INSERT INTO test_functions VALUES (NULL, 'fn_PricePerM2', '10 000 000 за 50 м²', '200000.00', IFNULL(@r, 'NULL'), IF(@r = 200000, 'PASS', 'FAIL'));
SET @r = fn_PricePerM2(10000000, 0);
INSERT INTO test_functions VALUES (NULL, 'fn_PricePerM2', 'Площадь 0 (деление на ноль)', 'NULL без ошибки', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));
SET @r = fn_PricePerM2(NULL, 50);
INSERT INTO test_functions VALUES (NULL, 'fn_PricePerM2', 'Цена NULL', 'NULL', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));

-- ---------- fn_FormatRub ----------
SET @r = fn_FormatRub(32570000);
INSERT INTO test_functions VALUES (NULL, 'fn_FormatRub', 'Сумма 32 570 000', '«32 570 000 ₽»', IFNULL(@r, 'NULL'), IF(@r = '32 570 000 ₽', 'PASS', 'FAIL'));
SET @r = fn_FormatRub(0);
INSERT INTO test_functions VALUES (NULL, 'fn_FormatRub', 'Сумма 0', '«0 ₽»', IFNULL(@r, 'NULL'), IF(@r = '0 ₽', 'PASS', 'FAIL'));
SET @r = fn_FormatRub(NULL);
INSERT INTO test_functions VALUES (NULL, 'fn_FormatRub', 'Сумма NULL', 'NULL', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));

-- ---------- fn_AgeYears ----------
SET @r = fn_AgeYears(CURDATE() - INTERVAL 18 YEAR);
INSERT INTO test_functions VALUES (NULL, 'fn_AgeYears', '18 лет исполняется сегодня (граница)', '18', IFNULL(@r, 'NULL'), IF(@r = 18, 'PASS', 'FAIL'));
SET @r = fn_AgeYears(CURDATE() - INTERVAL 18 YEAR + INTERVAL 1 DAY);
INSERT INTO test_functions VALUES (NULL, 'fn_AgeYears', '18 лет исполнится завтра', '17', IFNULL(@r, 'NULL'), IF(@r = 17, 'PASS', 'FAIL'));
SET @r = fn_AgeYears(CURDATE() + INTERVAL 1 DAY);
INSERT INTO test_functions VALUES (NULL, 'fn_AgeYears', 'Дата рождения в будущем', 'NULL', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));

-- ---------- fn_ClientShortName ----------
SET @r = fn_ClientShortName(1);
INSERT INTO test_functions VALUES (NULL, 'fn_ClientShortName', 'Клиент № 1', '«Иванов С. А.»', IFNULL(@r, 'NULL'), IF(@r = 'Иванов С. А.', 'PASS', 'FAIL'));
SET @r = fn_ClientShortName(99999);
INSERT INTO test_functions VALUES (NULL, 'fn_ClientShortName', 'Несуществующий клиент', 'NULL', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));

-- ---------- fn_DealPaidPercent ----------
SET @r = fn_DealPaidPercent(1);
INSERT INTO test_functions VALUES (NULL, 'fn_DealPaidPercent', 'Завершённая продажа № 1', '100.0', IFNULL(@r, 'NULL'), IF(@r = 100, 'PASS', 'FAIL'));
SET @r = fn_DealPaidPercent(20);
INSERT INTO test_functions VALUES (NULL, 'fn_DealPaidPercent', 'Сделка № 20: внесён только задаток 500 000 из 23 100 000', '2.2', IFNULL(@r, 'NULL'), IF(@r = 2.2, 'PASS', 'FAIL'));
SET @r = fn_DealPaidPercent(13);
INSERT INTO test_functions VALUES (NULL, 'fn_DealPaidPercent', 'Аренда № 13: оплачен первый месяц', '100.0', IFNULL(@r, 'NULL'), IF(@r = 100, 'PASS', 'FAIL'));
SET @r = fn_DealPaidPercent(99999);
INSERT INTO test_functions VALUES (NULL, 'fn_DealPaidPercent', 'Несуществующая сделка', 'NULL', IFNULL(@r, 'NULL'), IF(@r IS NULL, 'PASS', 'FAIL'));

-- ---------- tvf_ClientDeals ----------
SET @r = (SELECT COUNT(*) FROM tvf_ClientDeals WHERE ClientID = 16);
INSERT INTO test_functions VALUES (NULL, 'tvf_ClientDeals', 'Сделки клиента № 16', '2 сделки', CONCAT(@r, ' сделки'), IF(@r = 2, 'PASS', 'FAIL'));
SET @r = (SELECT COUNT(*) FROM tvf_ClientDeals WHERE ClientID = 16 AND DealDate BETWEEN '2020-01-01' AND '2020-12-31');
INSERT INTO test_functions VALUES (NULL, 'tvf_ClientDeals', 'Клиент № 16, период без сделок (2020)', 'Пустая выборка', CONCAT(@r, ' строк'), IF(@r = 0, 'PASS', 'FAIL'));

-- ---------- tvf_ActiveOffers ----------
SET @r = (SELECT COUNT(*) FROM tvf_ActiveOffers WHERE OfferType = 'продажа' AND TypeID = 1 AND Price <= 25000000);
INSERT INTO test_functions VALUES (NULL, 'tvf_ActiveOffers', 'Квартиры на продажу до 25 млн', '3 объекта (как proc_Properties_Search)', CONCAT(@r, ' объекта'), IF(@r = 3, 'PASS', 'FAIL'));
SET @r = (SELECT COUNT(*) FROM Requests AS r
          JOIN tvf_ActiveOffers AS o
            ON o.TypeID = r.TypeID AND o.OfferType = r.OfferType AND o.Price <= r.MaxBudget
           AND o.OwnerClientID <> r.ClientID
           AND (r.DistrictID IS NULL OR o.DistrictID = r.DistrictID)
           AND (r.MinRooms IS NULL OR o.Rooms >= r.MinRooms)
           AND (r.MinArea IS NULL OR o.Area >= r.MinArea)
          WHERE r.RequestID = 16);
INSERT INTO test_functions VALUES (NULL, 'tvf_ActiveOffers', 'JOIN с заявкой № 16', '1 объект (как proc_Report_RequestMatches)', CONCAT(@r, ' объект'), IF(@r = 1, 'PASS', 'FAIL'));
SET @r = (SELECT COUNT(*) FROM tvf_ActiveOffers WHERE PricePerM2 <> ROUND(Price / Area, 2));
INSERT INTO test_functions VALUES (NULL, 'tvf_ActiveOffers', 'Цена за м² совпадает с ручным расчётом Price / Area', '0 расхождений', CONCAT(@r, ' расхождений'), IF(@r = 0, 'PASS', 'FAIL'));

-- ---------- proc_tvf_AgentRating ----------
CALL proc_tvf_AgentRating('2025-01-01', '2026-12-31');
SET @rows    = (SELECT COUNT(*) FROM tvf_AgentRating);
SET @leaders = (SELECT COUNT(*) FROM tvf_AgentRating WHERE Rating = 'лидер');
SET @comm    = (SELECT SUM(Commission) FROM tvf_AgentRating);
SET @manual  = (SELECT SUM(CommissionAmount) FROM Deals WHERE Status = 'завершена' AND DealDate BETWEEN '2025-01-01' AND '2026-12-31');
INSERT INTO test_functions VALUES (NULL, 'proc_tvf_AgentRating', 'Период 2025–2026: число агентов', '6 строк', CONCAT(@rows, ' строк'), IF(@rows = 6, 'PASS', 'FAIL'));
INSERT INTO test_functions VALUES (NULL, 'proc_tvf_AgentRating', 'Период 2025–2026: лидеры (комиссия ≥ 1 млн)', '3 лидера', CONCAT(@leaders, ' лидера'), IF(@leaders = 3, 'PASS', 'FAIL'));
INSERT INTO test_functions VALUES (NULL, 'proc_tvf_AgentRating', 'Сумма комиссий = ручному запросу', CONCAT(@manual), CONCAT(@comm), IF(@comm = @manual, 'PASS', 'FAIL'));
CALL proc_tvf_AgentRating('2020-01-01', '2020-12-31');
SET @r = (SELECT COUNT(*) FROM tvf_AgentRating WHERE Rating = 'нет сделок');
INSERT INTO test_functions VALUES (NULL, 'proc_tvf_AgentRating', 'Период без сделок (2020)', 'У всех 6 агентов «нет сделок»', CONCAT(@r, ' агентов'), IF(@r = 6, 'PASS', 'FAIL'));

-- ---------- proc_tvf_ListingStatus ----------
CALL proc_tvf_ListingStatus();
SET @rows   = (SELECT COUNT(*) FROM tvf_ListingStatus);
SET @status = (SELECT MarketStatus FROM tvf_ListingStatus WHERE PropertyID = 21);
SET @nulls  = (SELECT COUNT(*) FROM tvf_ListingStatus WHERE MarketStatus IS NULL OR Stale IS NULL);
INSERT INTO test_functions VALUES (NULL, 'proc_tvf_ListingStatus', 'Все активные объекты оценены', '11 строк, без пустых статусов', CONCAT(@rows, ' строк, пустых: ', @nulls), IF(@rows = 11 AND @nulls = 0, 'PASS', 'FAIL'));
INSERT INTO test_functions VALUES (NULL, 'proc_tvf_ListingStatus', 'Объект № 21 (Арбат): 725 490 при средней 715 155 за м²', '«в рынке»', IFNULL(@status, 'NULL'), IF(@status = 'в рынке', 'PASS', 'FAIL'));

-- ---------- применение в существующих объектах ----------
SET @r = (SELECT COUNT(*) FROM information_schema.ROUTINES
          WHERE ROUTINE_SCHEMA = 'realty_pm11' AND ROUTINE_NAME = 'proc_Deals_Create'
            AND ROUTINE_DEFINITION LIKE '%fn_CommissionDefault%');
INSERT INTO test_functions VALUES (NULL, 'proc_Deals_Create', 'Процедура этапа 2 использует fn_CommissionDefault', 'Да', IF(@r = 1, 'Да', 'Нет'), IF(@r = 1, 'PASS', 'FAIL'));
SET @r = (SELECT COUNT(*) FROM information_schema.ROUTINES
          WHERE ROUTINE_SCHEMA = 'realty_pm11' AND ROUTINE_NAME = 'proc_Clients_Create'
            AND ROUTINE_DEFINITION LIKE '%fn_AgeYears%');
INSERT INTO test_functions VALUES (NULL, 'proc_Clients_Create', 'Процедура этапа 2 использует fn_AgeYears', 'Да', IF(@r = 1, 'Да', 'Нет'), IF(@r = 1, 'PASS', 'FAIL'));
SET @rows = (SELECT COUNT(*) FROM v_ActiveListings);
SET @r    = (SELECT COUNT(*) FROM v_ActiveListings WHERE ЦенаЗаМ2 <> fn_PricePerM2(Цена, Площадь));
INSERT INTO test_functions VALUES (NULL, 'v_ActiveListings', 'Представление этапа 1 считает цену за м² функцией', '11 строк, 0 расхождений', CONCAT(@rows, ' строк, расхождений: ', @r), IF(@rows = 11 AND @r = 0, 'PASS', 'FAIL'));

/* =====================================================================
   Итог
   ===================================================================== */
SELECT N, Объект, Сценарий, Ожидается, Фактически, Статус FROM test_functions ORDER BY N;

SELECT COUNT(*)                                          AS `Всего тестов`,
       SUM(CASE WHEN Статус = 'PASS' THEN 1 ELSE 0 END)  AS Пройдено,
       SUM(CASE WHEN Статус = 'FAIL' THEN 1 ELSE 0 END)  AS `Не пройдено`
FROM test_functions;
