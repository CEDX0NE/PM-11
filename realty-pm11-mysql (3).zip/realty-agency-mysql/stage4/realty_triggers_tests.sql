/* =====================================================================
   Учебная практика ПМ.11, этап 4 — тестирование триггеров
   Файл: realty_triggers_tests.sql
   СУБД: MySQL 8.0 (запускать в консоли mysql: source путь/к/файлу.sql)
   Запуск: после realty_triggers.sql, на базе с тестовыми данными этапа 1.

   Для каждого триггера проверяются три вида сценариев:
     • корректная операция — выполняется, аудит заполняется;
     • нарушающая операция — ошибка с кодом, данные не изменились;
     • многострочная операция — обрабатываются все строки / пакет
       откатывается целиком.
   Результаты пишутся в таблицу test_triggers (PASS / FAIL).
   Тестовые записи удаляются в конце; записи журнала AuditLog остаются —
   журнал по определению не очищается.
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;
SET SQL_SAFE_UPDATES = 0;

DROP TABLE IF EXISTS test_triggers;
CREATE TABLE test_triggers (
    N          INT AUTO_INCREMENT PRIMARY KEY,
    Триггер    VARCHAR(40),
    Сценарий   VARCHAR(150),
    Ожидается  VARCHAR(200),
    Фактически VARCHAR(500),
    Статус     VARCHAR(4)
);

DELIMITER $$

-- выполняет команду и возвращает номер и текст ошибки (NULL — без ошибки)
DROP PROCEDURE IF EXISTS t4_run$$
CREATE PROCEDURE t4_run(IN p_sql TEXT, OUT p_errno INT, OUT p_err VARCHAR(500))
BEGIN
    DECLARE v_no  INT;
    DECLARE v_msg VARCHAR(500);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_no = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        SET p_errno = v_no, p_err = CONCAT(v_no, ': ', v_msg);
    END;
    SET p_errno = NULL, p_err = NULL;
    SET @t4_sql = p_sql;
    PREPARE t4_stmt FROM @t4_sql;
    EXECUTE t4_stmt;
    DEALLOCATE PREPARE t4_stmt;
END$$

-- негативный сценарий: команда должна завершиться ошибкой p_errno,
-- а число строк, которое считает p_count_sql, — не измениться
DROP PROCEDURE IF EXISTS t4_expect_error$$
CREATE PROCEDURE t4_expect_error(IN p_trg VARCHAR(40), IN p_case VARCHAR(150), IN p_errno INT,
                                 IN p_sql TEXT, IN p_count_sql TEXT)
BEGIN
    DECLARE v_no  INT;
    DECLARE v_err VARCHAR(500);
    DECLARE v_before INT;
    DECLARE v_after  INT;
    SET @t4_cnt_sql = CONCAT('SELECT (', p_count_sql, ') INTO @t4_cnt');
    PREPARE c FROM @t4_cnt_sql; EXECUTE c; SET v_before = @t4_cnt;
    CALL t4_run(p_sql, v_no, v_err);
    EXECUTE c; SET v_after = @t4_cnt; DEALLOCATE PREPARE c;
    INSERT INTO test_triggers (Триггер, Сценарий, Ожидается, Фактически, Статус)
    VALUES (p_trg, p_case, CONCAT('Ошибка ', p_errno, ', изменений нет'),
            CONCAT(IFNULL(v_err, 'ошибки нет'), ' | строк было ', v_before, ', стало ', v_after),
            IF(v_no = p_errno AND v_before = v_after, 'PASS', 'FAIL'));
END$$

DELIMITER ;

-- остатки прерванного запуска
DELETE FROM Payments WHERE Method = 'перевод' AND DealID = 20 AND PaymentDate = CURRENT_DATE AND Amount IN (1000000, 11000000);
DELETE FROM Viewings WHERE ViewingDateTime >= '2027-03-01' AND ViewingDateTime < '2027-03-03';
DELETE FROM Deals    WHERE PropertyID IN (SELECT PropertyID FROM (SELECT PropertyID FROM Properties WHERE Address LIKE 'ТЕСТ4:%') AS x);
DELETE FROM Properties WHERE Address LIKE 'ТЕСТ4:%';

/* =====================================================================
   1. АУДИТ ОБЪЕКТОВ (trg_Properties_Audit*)
   ===================================================================== */

-- 1.1 Многострочный INSERT: три объекта одной инструкцией → три записи аудита
SET @a0 = (SELECT IFNULL(MAX(AuditID), 0) FROM AuditLog);
INSERT INTO Properties (OwnerClientID, EmployeeID, TypeID, DistrictID, OfferType, Address, Area, Rooms, Price) VALUES
    (1, 1, 1, 1, 'продажа', 'ТЕСТ4: ул. Тестовая, д. 1', 50, 2, 15000000),
    (1, 1, 1, 1, 'продажа', 'ТЕСТ4: ул. Тестовая, д. 2', 60, 3, 18000000),
    (1, 1, 1, 1, 'продажа', 'ТЕСТ4: ул. Тестовая, д. 3', 70, 3, 21000000);
SET @P1 = (SELECT PropertyID FROM Properties WHERE Address = 'ТЕСТ4: ул. Тестовая, д. 1');
SET @r = (SELECT COUNT(*) FROM AuditLog WHERE AuditID > @a0 AND TableName = 'Properties' AND Operation = 'INSERT');
INSERT INTO test_triggers VALUES (NULL, 'trg_Properties_AuditInsert', 'Многострочный INSERT трёх объектов', '3 записи INSERT в AuditLog', CONCAT(@r, ' записи'), IF(@r = 3, 'PASS', 'FAIL'));

-- 1.2 UPDATE цены одного объекта → старое и новое значение в журнале
SET @a0 = (SELECT MAX(AuditID) FROM AuditLog);
UPDATE Properties SET Price = 14500000 WHERE PropertyID = @P1;
SET @old = (SELECT JSON_UNQUOTE(JSON_EXTRACT(OldValue, '$.Price')) FROM AuditLog WHERE AuditID > @a0 AND RecordID = @P1);
SET @new = (SELECT JSON_UNQUOTE(JSON_EXTRACT(NewValue, '$.Price')) FROM AuditLog WHERE AuditID > @a0 AND RecordID = @P1);
INSERT INTO test_triggers VALUES (NULL, 'trg_Properties_AuditUpdate', 'UPDATE цены объекта 15 000 000 → 14 500 000', 'Строка UPDATE: было 15000000.00, стало 14500000.00', CONCAT('было ', IFNULL(@old, 'NULL'), ', стало ', IFNULL(@new, 'NULL')), IF(@old = '15000000.00' AND @new = '14500000.00', 'PASS', 'FAIL'));

-- 1.3 UPDATE неотслеживаемого поля (описание) → запись не создаётся
SET @a0 = (SELECT MAX(AuditID) FROM AuditLog);
UPDATE Properties SET Description = 'Тестовое описание' WHERE PropertyID = @P1;
SET @r = (SELECT COUNT(*) FROM AuditLog WHERE AuditID > @a0);
INSERT INTO test_triggers VALUES (NULL, 'trg_Properties_AuditUpdate', 'UPDATE только описания объекта', '0 записей (поле не отслеживается)', CONCAT(@r, ' записей'), IF(@r = 0, 'PASS', 'FAIL'));

-- 1.4 Многострочный UPDATE: повышение цены трёх объектов на 5 %
SET @a0 = (SELECT MAX(AuditID) FROM AuditLog);
UPDATE Properties SET Price = ROUND(Price * 1.05, -3) WHERE Address LIKE 'ТЕСТ4:%';
SET @r = (SELECT COUNT(*) FROM AuditLog WHERE AuditID > @a0 AND Operation = 'UPDATE'
          AND JSON_EXTRACT(NewValue, '$.Price') > JSON_EXTRACT(OldValue, '$.Price'));
INSERT INTO test_triggers VALUES (NULL, 'trg_Properties_AuditUpdate', 'Многострочный UPDATE: цена трёх объектов +5 %', '3 записи UPDATE, новая цена больше старой', CONCAT(@r, ' записи'), IF(@r = 3, 'PASS', 'FAIL'));

/* =====================================================================
   2. АУДИТ СДЕЛОК (trg_Deals_Audit*)
   ===================================================================== */

-- 2.1 INSERT сделки
SET @a0 = (SELECT MAX(AuditID) FROM AuditLog);
INSERT INTO Deals (PropertyID, ClientID, EmployeeID, DealType, Amount, CommissionAmount)
VALUES (@P1, 2, 1, 'продажа', 15000000, 450000);
SET @D1 = LAST_INSERT_ID();
SET @r = (SELECT JSON_UNQUOTE(JSON_EXTRACT(NewValue, '$.Status')) FROM AuditLog WHERE AuditID > @a0 AND TableName = 'Deals' AND Operation = 'INSERT' AND RecordID = @D1);
INSERT INTO test_triggers VALUES (NULL, 'trg_Deals_AuditInsert', 'INSERT сделки по тестовому объекту', 'Строка INSERT, статус «оформляется»', IFNULL(@r, 'записи нет'), IF(@r = 'оформляется', 'PASS', 'FAIL'));

-- 2.2 UPDATE статуса сделки
SET @a0 = (SELECT MAX(AuditID) FROM AuditLog);
UPDATE Deals SET Status = 'расторгнута' WHERE DealID = @D1;
SET @r = (SELECT CONCAT(JSON_UNQUOTE(JSON_EXTRACT(OldValue, '$.Status')), ' → ', JSON_UNQUOTE(JSON_EXTRACT(NewValue, '$.Status')))
          FROM AuditLog WHERE AuditID > @a0 AND TableName = 'Deals' AND RecordID = @D1);
INSERT INTO test_triggers VALUES (NULL, 'trg_Deals_AuditUpdate', 'Расторжение сделки (UPDATE статуса)', 'оформляется → расторгнута', IFNULL(@r, 'записи нет'), IF(@r = 'оформляется → расторгнута', 'PASS', 'FAIL'));

/* =====================================================================
   3. КОНТРОЛЬ ПЛАТЕЖЕЙ (trg_Payments_CheckTotal)
   Сделка № 20: продажа за 23 100 000, уже оплачено 500 000.
   ===================================================================== */

-- 3.1 Корректный платёж
SET @n0 = (SELECT COUNT(*) FROM Payments WHERE DealID = 20);
CALL t4_run('INSERT INTO Payments (DealID, Amount, Method, Purpose) VALUES (20, 1000000, ''перевод'', ''основной платёж'')', @no, @err);
SET @n1 = (SELECT COUNT(*) FROM Payments WHERE DealID = 20);
INSERT INTO test_triggers VALUES (NULL, 'trg_Payments_CheckTotal', 'Платёж 1 000 000 по сделке № 20 (в пределах цены)', 'Платёж принят', IFNULL(@err, CONCAT('принят, платежей ', @n0, ' → ', @n1)), IF(@no IS NULL AND @n1 = @n0 + 1, 'PASS', 'FAIL'));

-- 3.2 Превышение цены договора
CALL t4_expect_error('trg_Payments_CheckTotal', 'Платёж 23 000 000 — сумма превысит цену договора', 50009,
    'INSERT INTO Payments (DealID, Amount, Method, Purpose) VALUES (20, 23000000, ''перевод'', ''основной платёж'')',
    'SELECT COUNT(*) FROM Payments WHERE DealID = 20');

-- 3.3 Многострочный INSERT: 2 платежа по 11 000 000 — второй выходит за цену
CALL t4_expect_error('trg_Payments_CheckTotal', 'Многострочный INSERT: 2 × 11 000 000, второй превышает цену', 50009,
    'INSERT INTO Payments (DealID, Amount, Method, Purpose) VALUES (20, 11000000, ''перевод'', ''основной платёж''), (20, 11000000, ''перевод'', ''основной платёж'')',
    'SELECT COUNT(*) FROM Payments WHERE DealID = 20');

-- 3.4 Платёж по расторгнутой сделке (тестовая сделка из 2.2)
SET @sql = CONCAT('INSERT INTO Payments (DealID, Amount, Method, Purpose) VALUES (', @D1, ', 100000, ''наличные'', ''задаток'')');
SET @cnt = CONCAT('SELECT COUNT(*) FROM Payments WHERE DealID = ', @D1);
CALL t4_expect_error('trg_Payments_CheckTotal', 'Задаток по расторгнутой сделке', 50008, @sql, @cnt);

/* =====================================================================
   4. ИНТЕРВАЛ ПОКАЗОВ (trg_Viewings_CheckInterval / ...Upd)
   Агент № 5, объект № 21, клиент № 3, 1 марта 2027 г.
   ===================================================================== */

-- 4.1 Корректный показ
CALL t4_run('INSERT INTO Viewings (PropertyID, ClientID, EmployeeID, ViewingDateTime) VALUES (21, 3, 5, ''2027-03-01 10:00:00'')', @no, @err);
INSERT INTO test_triggers VALUES (NULL, 'trg_Viewings_CheckInterval', 'Показ агента № 5 на 01.03.2027 10:00', 'Показ создан', IFNULL(@err, 'создан'), IF(@no IS NULL, 'PASS', 'FAIL'));
SET @V1 = (SELECT ViewingID FROM Viewings WHERE EmployeeID = 5 AND ViewingDateTime = '2027-03-01 10:00:00');

-- 4.2 Второй показ через 30 минут — нарушение (UNIQUE этого не ловит)
CALL t4_expect_error('trg_Viewings_CheckInterval', 'Второй показ того же агента через 30 минут (10:30)', 50010,
    'INSERT INTO Viewings (PropertyID, ClientID, EmployeeID, ViewingDateTime) VALUES (21, 4, 5, ''2027-03-01 10:30:00'')',
    'SELECT COUNT(*) FROM Viewings WHERE EmployeeID = 5');

-- 4.3 Граница: ровно через час — допустимо
CALL t4_run('INSERT INTO Viewings (PropertyID, ClientID, EmployeeID, ViewingDateTime) VALUES (21, 4, 5, ''2027-03-01 11:00:00'')', @no, @err);
INSERT INTO test_triggers VALUES (NULL, 'trg_Viewings_CheckInterval', 'Показ ровно через час (11:00) — граница', 'Показ создан', IFNULL(@err, 'создан'), IF(@no IS NULL, 'PASS', 'FAIL'));

-- 4.4 Многострочный INSERT: два показа на 15:00 и 15:20 — конфликт внутри пакета
CALL t4_expect_error('trg_Viewings_CheckInterval', 'Многострочный INSERT: 15:00 и 15:20 в одном пакете', 50010,
    'INSERT INTO Viewings (PropertyID, ClientID, EmployeeID, ViewingDateTime) VALUES (21, 3, 5, ''2027-03-01 15:00:00''), (21, 4, 5, ''2027-03-01 15:20:00'')',
    'SELECT COUNT(*) FROM Viewings WHERE EmployeeID = 5');

-- 4.5 UPDATE: перенос показа 10:00 на 11:30 — пересекается с показом в 11:00
SET @sql = CONCAT('UPDATE Viewings SET ViewingDateTime = ''2027-03-01 11:30:00'' WHERE ViewingID = ', @V1);
CALL t4_expect_error('trg_Viewings_CheckIntervalUpd', 'Перенос показа 10:00 → 11:30 (рядом показ в 11:00)', 50010, @sql,
    'SELECT COUNT(*) FROM Viewings WHERE EmployeeID = 5 AND ViewingDateTime = ''2027-03-01 11:30:00''');

-- 4.6 UPDATE результата показа без смены времени — проверка не мешает
SET @sql = CONCAT('UPDATE Viewings SET Result = ''отменён'' WHERE ViewingID = ', @V1);
CALL t4_run(@sql, @no, @err);
INSERT INTO test_triggers VALUES (NULL, 'trg_Viewings_CheckIntervalUpd', 'Отмена показа 10:00 (меняется только результат)', 'Изменение выполнено', IFNULL(@err, 'выполнено'), IF(@no IS NULL, 'PASS', 'FAIL'));

-- 4.7 После отмены показа 10:00 время 9:30 свободно (отменённые показы не учитываются)
CALL t4_run('INSERT INTO Viewings (PropertyID, ClientID, EmployeeID, ViewingDateTime) VALUES (21, 4, 5, ''2027-03-01 09:30:00'')', @no, @err);
INSERT INTO test_triggers VALUES (NULL, 'trg_Viewings_CheckInterval', 'Показ в 9:30 рядом с отменённым показом 10:00', 'Показ создан', IFNULL(@err, 'создан'), IF(@no IS NULL, 'PASS', 'FAIL'));

/* =====================================================================
   5. ЗАПРЕТ УДАЛЕНИЯ СОТРУДНИКА (trg_Employees_PreventDelete)
   ===================================================================== */

-- 5.1 DELETE сотрудника № 8 (Гусев, без связанных записей — FK бы не помешал)
CALL t4_expect_error('trg_Employees_PreventDelete', 'DELETE сотрудника № 8 без связанных записей', 50012,
    'DELETE FROM Employees WHERE EmployeeID = 8',
    'SELECT COUNT(*) FROM Employees');

-- 5.2 Многострочный DELETE — отменяется целиком
CALL t4_expect_error('trg_Employees_PreventDelete', 'Многострочный DELETE сотрудников № 7 и 8', 50012,
    'DELETE FROM Employees WHERE EmployeeID IN (7, 8)',
    'SELECT COUNT(*) FROM Employees');

-- 5.3 «Архивирование» вместо удаления: признак IsActive
UPDATE Employees SET IsActive = FALSE WHERE EmployeeID = 8;
SET @r = (SELECT CONCAT('IsActive = ', IsActive, ', строка сохранена') FROM Employees WHERE EmployeeID = 8);
INSERT INTO test_triggers VALUES (NULL, 'trg_Employees_PreventDelete', 'Увольнение сотрудника № 8 через IsActive = FALSE', 'IsActive = 0, строка сохранена', IFNULL(@r, 'строки нет'), IF(@r = 'IsActive = 0, строка сохранена', 'PASS', 'FAIL'));
UPDATE Employees SET IsActive = TRUE WHERE EmployeeID = 8;   -- возвращаем исходные данные

/* =====================================================================
   6. УДАЛЕНИЕ ТЕСТОВЫХ ДАННЫХ = ПРОВЕРКА АУДИТА DELETE
   ===================================================================== */
SET @a0 = (SELECT MAX(AuditID) FROM AuditLog);
DELETE FROM Payments WHERE DealID = 20 AND Amount = 1000000 AND PaymentDate = CURRENT_DATE;
DELETE FROM Viewings WHERE ViewingDateTime >= '2027-03-01' AND ViewingDateTime < '2027-03-03';
DELETE FROM Deals WHERE DealID = @D1;
DELETE FROM Properties WHERE Address LIKE 'ТЕСТ4:%';
SET @d = (SELECT COUNT(*) FROM AuditLog WHERE AuditID > @a0 AND TableName = 'Deals' AND Operation = 'DELETE' AND JSON_EXTRACT(OldValue, '$.Status') = 'расторгнута');
SET @p = (SELECT COUNT(*) FROM AuditLog WHERE AuditID > @a0 AND TableName = 'Properties' AND Operation = 'DELETE' AND NewValue IS NULL);
INSERT INTO test_triggers VALUES (NULL, 'trg_Deals_AuditDelete', 'DELETE тестовой сделки', '1 запись DELETE со старыми значениями', CONCAT(@d, ' запись'), IF(@d = 1, 'PASS', 'FAIL'));
INSERT INTO test_triggers VALUES (NULL, 'trg_Properties_AuditDelete', 'Многострочный DELETE трёх тестовых объектов', '3 записи DELETE, NewValue = NULL', CONCAT(@p, ' записи'), IF(@p = 3, 'PASS', 'FAIL'));

DROP PROCEDURE IF EXISTS t4_expect_error;
DROP PROCEDURE IF EXISTS t4_run;

/* =====================================================================
   Итог
   ===================================================================== */

-- последние записи журнала аудита (демонстрация)
SELECT AuditID AS `№`, TableName AS Таблица, RecordID AS Запись, Operation AS Операция,
       OldValue AS Было, NewValue AS Стало, ChangedBy AS Пользователь, ChangedAt AS Когда
FROM AuditLog ORDER BY AuditID DESC LIMIT 12;

SELECT N, Триггер, Сценарий, Ожидается, Фактически, Статус FROM test_triggers ORDER BY N;

SELECT COUNT(*)                                          AS `Всего тестов`,
       SUM(CASE WHEN Статус = 'PASS' THEN 1 ELSE 0 END)  AS Пройдено,
       SUM(CASE WHEN Статус = 'FAIL' THEN 1 ELSE 0 END)  AS `Не пройдено`
FROM test_triggers;
