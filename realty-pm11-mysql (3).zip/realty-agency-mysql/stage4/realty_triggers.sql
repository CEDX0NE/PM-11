/* =====================================================================
   Учебная практика ПМ.11, этап 4 — «Разработка триггеров для
   автоматизации работы базы данных»
   Кейс-задача: «Информационная система риэлторского агентства «КлючДом»»
   Файл: realty_triggers.sql
   База данных: realty_pm11 (этапы 1–3)
   СУБД: MySQL 8.0 — запускать в консоли mysql: source путь/к/realty_triggers.sql
   Автор: ______________________     Дата: 30.10.2026

   Особенности триггеров MySQL по сравнению с T-SQL из задания:
     • триггер строчный (FOR EACH ROW): выполняется для каждой строки
       многострочной операции; вместо таблиц inserted / deleted —
       псевдозаписи NEW (новая строка) и OLD (старая строка);
     • ошибка в триггере (SIGNAL) отменяет всю инструкцию целиком —
       в InnoDB многострочный INSERT/UPDATE не применяется частично;
     • триггеров INSTEAD OF в MySQL нет; замещение DELETE «архивом»
       реализовано запретом удаления (BEFORE DELETE + SIGNAL) и мягким
       удалением через признак IsActive (см. раздел 4);
     • на одно событие таблицы (BEFORE/AFTER × INSERT/UPDATE/DELETE)
       создаётся отдельный триггер.

   Стандарт именования: trg_<Таблица>_<Назначение>

   Коды бизнес-ошибок (продолжают список этапа 2):
     50008 — платёж по расторгнутой сделке
     50009 — сумма платежей больше цены договора
     50010 — у агента другой показ ближе чем за час
     50012 — физическое удаление сотрудника запрещено

   Скрипт можно запускать повторно (DROP ... IF EXISTS).
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;

/* =====================================================================
   1. ТАБЛИЦА АУДИТА
   ===================================================================== */

-- Журнал изменений ключевых таблиц: что, когда и кем изменено.
-- Старое и новое значения хранятся в формате JSON (аналог NVARCHAR
-- из задания): в одной строке видны все отслеживаемые поля записи.
CREATE TABLE IF NOT EXISTS AuditLog (
    AuditID     INT          NOT NULL AUTO_INCREMENT,
    TableName   VARCHAR(64)  NOT NULL,                      -- таблица
    RecordID    INT          NOT NULL,                      -- первичный ключ записи
    Operation   VARCHAR(6)   NOT NULL,                      -- INSERT / UPDATE / DELETE
    OldValue    JSON         NULL,                          -- значения до изменения
    NewValue    JSON         NULL,                          -- значения после изменения
    ChangedBy   VARCHAR(100) NOT NULL,                      -- пользователь (USER())
    ChangedAt   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT PK_AuditLog PRIMARY KEY (AuditID),
    INDEX IX_AuditLog_Record (TableName, RecordID),
    CONSTRAINT CK_AuditLog_Operation CHECK (Operation IN ('INSERT', 'UPDATE', 'DELETE')),
    -- у INSERT нет старого значения, у DELETE — нового
    CONSTRAINT CK_AuditLog_Values CHECK (
        (Operation = 'INSERT' AND OldValue IS NULL AND NewValue IS NOT NULL) OR
        (Operation = 'UPDATE' AND OldValue IS NOT NULL AND NewValue IS NOT NULL) OR
        (Operation = 'DELETE' AND OldValue IS NOT NULL AND NewValue IS NULL))
) ENGINE = InnoDB;

DELIMITER $$

/* =====================================================================
   2. AFTER-ТРИГГЕРЫ АУДИТА
   ===================================================================== */

/* ---------------------------------------------------------------------
   trg_Properties_AuditInsert / AuditUpdate / AuditDelete
   Таблица:   Properties (объекты недвижимости)
   Событие:   AFTER INSERT / UPDATE / DELETE
   Действие:  запись в AuditLog: адрес, вид предложения, цена, статус,
              ответственный агент. UPDATE протоколируется, только если
              изменилось хотя бы одно из этих полей.
   --------------------------------------------------------------------- */
DROP TRIGGER IF EXISTS trg_Properties_AuditInsert$$
CREATE TRIGGER trg_Properties_AuditInsert
AFTER INSERT ON Properties
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (TableName, RecordID, Operation, OldValue, NewValue, ChangedBy)
    VALUES ('Properties', NEW.PropertyID, 'INSERT', NULL,
            JSON_OBJECT('Address', NEW.Address, 'OfferType', NEW.OfferType, 'Price', NEW.Price,
                        'Status', NEW.Status, 'EmployeeID', NEW.EmployeeID),
            USER());
END$$

DROP TRIGGER IF EXISTS trg_Properties_AuditUpdate$$
CREATE TRIGGER trg_Properties_AuditUpdate
AFTER UPDATE ON Properties
FOR EACH ROW
BEGIN
    -- оператор <=> корректно сравнивает и значения NULL
    IF NOT (OLD.Address <=> NEW.Address AND OLD.OfferType <=> NEW.OfferType
            AND OLD.Price <=> NEW.Price AND OLD.Status <=> NEW.Status
            AND OLD.EmployeeID <=> NEW.EmployeeID) THEN
        INSERT INTO AuditLog (TableName, RecordID, Operation, OldValue, NewValue, ChangedBy)
        VALUES ('Properties', NEW.PropertyID, 'UPDATE',
                JSON_OBJECT('Address', OLD.Address, 'OfferType', OLD.OfferType, 'Price', OLD.Price,
                            'Status', OLD.Status, 'EmployeeID', OLD.EmployeeID),
                JSON_OBJECT('Address', NEW.Address, 'OfferType', NEW.OfferType, 'Price', NEW.Price,
                            'Status', NEW.Status, 'EmployeeID', NEW.EmployeeID),
                USER());
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_Properties_AuditDelete$$
CREATE TRIGGER trg_Properties_AuditDelete
AFTER DELETE ON Properties
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (TableName, RecordID, Operation, OldValue, NewValue, ChangedBy)
    VALUES ('Properties', OLD.PropertyID, 'DELETE',
            JSON_OBJECT('Address', OLD.Address, 'OfferType', OLD.OfferType, 'Price', OLD.Price,
                        'Status', OLD.Status, 'EmployeeID', OLD.EmployeeID),
            NULL, USER());
END$$

/* ---------------------------------------------------------------------
   trg_Deals_AuditInsert / AuditUpdate / AuditDelete
   Таблица:   Deals (сделки)
   Событие:   AFTER INSERT / UPDATE / DELETE
   Действие:  запись в AuditLog: объект, клиент, агент, сумма, комиссия,
              статус. UPDATE — только при изменении этих полей
              (смена статуса, корректировка суммы или комиссии).
   --------------------------------------------------------------------- */
DROP TRIGGER IF EXISTS trg_Deals_AuditInsert$$
CREATE TRIGGER trg_Deals_AuditInsert
AFTER INSERT ON Deals
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (TableName, RecordID, Operation, OldValue, NewValue, ChangedBy)
    VALUES ('Deals', NEW.DealID, 'INSERT', NULL,
            JSON_OBJECT('PropertyID', NEW.PropertyID, 'ClientID', NEW.ClientID, 'EmployeeID', NEW.EmployeeID,
                        'Amount', NEW.Amount, 'CommissionAmount', NEW.CommissionAmount, 'Status', NEW.Status),
            USER());
END$$

DROP TRIGGER IF EXISTS trg_Deals_AuditUpdate$$
CREATE TRIGGER trg_Deals_AuditUpdate
AFTER UPDATE ON Deals
FOR EACH ROW
BEGIN
    IF NOT (OLD.PropertyID <=> NEW.PropertyID AND OLD.ClientID <=> NEW.ClientID
            AND OLD.EmployeeID <=> NEW.EmployeeID AND OLD.Amount <=> NEW.Amount
            AND OLD.CommissionAmount <=> NEW.CommissionAmount AND OLD.Status <=> NEW.Status) THEN
        INSERT INTO AuditLog (TableName, RecordID, Operation, OldValue, NewValue, ChangedBy)
        VALUES ('Deals', NEW.DealID, 'UPDATE',
                JSON_OBJECT('PropertyID', OLD.PropertyID, 'ClientID', OLD.ClientID, 'EmployeeID', OLD.EmployeeID,
                            'Amount', OLD.Amount, 'CommissionAmount', OLD.CommissionAmount, 'Status', OLD.Status),
                JSON_OBJECT('PropertyID', NEW.PropertyID, 'ClientID', NEW.ClientID, 'EmployeeID', NEW.EmployeeID,
                            'Amount', NEW.Amount, 'CommissionAmount', NEW.CommissionAmount, 'Status', NEW.Status),
                USER());
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_Deals_AuditDelete$$
CREATE TRIGGER trg_Deals_AuditDelete
AFTER DELETE ON Deals
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (TableName, RecordID, Operation, OldValue, NewValue, ChangedBy)
    VALUES ('Deals', OLD.DealID, 'DELETE',
            JSON_OBJECT('PropertyID', OLD.PropertyID, 'ClientID', OLD.ClientID, 'EmployeeID', OLD.EmployeeID,
                        'Amount', OLD.Amount, 'CommissionAmount', OLD.CommissionAmount, 'Status', OLD.Status),
            NULL, USER());
END$$

/* =====================================================================
   3. ТРИГГЕРЫ КОНТРОЛЯ БИЗНЕС-ПРАВИЛ (BEFORE + SIGNAL)
   Правила уже проверяют процедуры этапа 2, но процедуру можно обойти
   прямым INSERT/UPDATE. Триггер — последний рубеж: правило соблюдается
   при любом способе изменения данных. Ограничением CHECK эти правила
   не выразить — они сравнивают строку с ДРУГИМИ строками таблицы.
   ===================================================================== */

/* ---------------------------------------------------------------------
   trg_Viewings_CheckInterval (INSERT) и trg_Viewings_CheckIntervalUpd (UPDATE)
   Таблица:   Viewings (показы)
   Правило:   у агента не может быть двух действующих (не отменённых)
              показов ближе чем за 60 минут. UNIQUE (EmployeeID,
              ViewingDateTime) этапа 1 ловит только точное совпадение
              времени, а показ через 30 минут пропускает.
   Ошибка:    50010; инструкция отменяется целиком.
   Многострочно: строки многострочного INSERT проверяются по очереди,
              каждая видит ранее вставленные строки той же инструкции,
              поэтому конфликт внутри пакета тоже обнаруживается.
   --------------------------------------------------------------------- */
DROP TRIGGER IF EXISTS trg_Viewings_CheckInterval$$
CREATE TRIGGER trg_Viewings_CheckInterval
BEFORE INSERT ON Viewings
FOR EACH ROW
BEGIN
    IF NEW.Result <> 'отменён' AND EXISTS (
        SELECT 1 FROM Viewings
        WHERE EmployeeID = NEW.EmployeeID
          AND Result <> 'отменён'
          AND ABS(TIMESTAMPDIFF(MINUTE, ViewingDateTime, NEW.ViewingDateTime)) < 60) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50010,
            MESSAGE_TEXT = 'У агента уже есть показ в это время (интервал не менее часа).';
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_Viewings_CheckIntervalUpd$$
CREATE TRIGGER trg_Viewings_CheckIntervalUpd
BEFORE UPDATE ON Viewings
FOR EACH ROW
BEGIN
    -- проверяем, только если изменилось время, агент или показ «восстановлен»
    -- из отменённых; смена результата показа проверку не запускает
    IF NEW.Result <> 'отменён'
       AND (NOT (NEW.EmployeeID <=> OLD.EmployeeID)
            OR NOT (NEW.ViewingDateTime <=> OLD.ViewingDateTime)
            OR OLD.Result = 'отменён')
       AND EXISTS (
            SELECT 1 FROM Viewings
            WHERE EmployeeID = NEW.EmployeeID
              AND ViewingID <> NEW.ViewingID
              AND Result <> 'отменён'
              AND ABS(TIMESTAMPDIFF(MINUTE, ViewingDateTime, NEW.ViewingDateTime)) < 60) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50010,
            MESSAGE_TEXT = 'У агента уже есть показ в это время (интервал не менее часа).';
    END IF;
END$$

/* ---------------------------------------------------------------------
   trg_Payments_CheckTotal
   Таблица:   Payments (платежи)
   Событие:   BEFORE INSERT
   Правила:   1) по расторгнутой сделке платежи не принимаются (50008);
              2) по сделке купли-продажи задаток и основные платежи
                 в сумме не превышают цену договора (50009).
   Многострочно: каждая следующая строка пакета учитывает уже
              вставленные строки того же INSERT; при превышении
              отменяется весь пакет.
   --------------------------------------------------------------------- */
DROP TRIGGER IF EXISTS trg_Payments_CheckTotal$$
CREATE TRIGGER trg_Payments_CheckTotal
BEFORE INSERT ON Payments
FOR EACH ROW
BEGIN
    DECLARE v_DealType   VARCHAR(10);
    DECLARE v_DealStatus VARCHAR(15);
    DECLARE v_DealAmount DECIMAL(14,2);
    DECLARE v_Paid       DECIMAL(14,2);

    SELECT DealType, Status, Amount INTO v_DealType, v_DealStatus, v_DealAmount
    FROM Deals WHERE DealID = NEW.DealID;

    IF v_DealStatus = 'расторгнута' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50008,
            MESSAGE_TEXT = 'Нельзя принимать платежи по расторгнутой сделке.';
    END IF;

    IF v_DealType = 'продажа' AND NEW.Purpose IN ('задаток', 'основной платёж') THEN
        SELECT IFNULL(SUM(Amount), 0) INTO v_Paid FROM Payments
        WHERE DealID = NEW.DealID AND Purpose IN ('задаток', 'основной платёж');
        IF v_Paid + NEW.Amount > v_DealAmount THEN
            SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50009,
                MESSAGE_TEXT = 'Сумма платежей превысит цену договора.';
        END IF;
    END IF;
END$$

/* =====================================================================
   4. ЗАМЕНА INSTEAD OF-ТРИГГЕРА
   В MySQL триггеров INSTEAD OF нет, а триггер не может изменить строки
   своей же таблицы (ошибка 1442), поэтому «DELETE → пометка архива»
   внутри одного триггера невозможна. Решение:
     • BEFORE DELETE запрещает физическое удаление сотрудника и
       подсказывает правильную операцию;
     • «архивирование» выполняется обычным UPDATE признака IsActive,
       который уже есть в таблице Employees (этап 1).
   История сделок, показов и объектов агента при этом сохраняется.
   ===================================================================== */

/* ---------------------------------------------------------------------
   trg_Employees_PreventDelete
   Таблица:   Employees (сотрудники)
   Событие:   BEFORE DELETE
   Действие:  отменяет удаление с ошибкой 50012. FK с RESTRICT
              не защищают сотрудника без связанных записей —
              триггер запрещает удаление всегда.
   --------------------------------------------------------------------- */
DROP TRIGGER IF EXISTS trg_Employees_PreventDelete$$
CREATE TRIGGER trg_Employees_PreventDelete
BEFORE DELETE ON Employees
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 50012,
        MESSAGE_TEXT = 'Сотрудника нельзя удалить: увольте его (UPDATE Employees SET IsActive = FALSE).';
END$$

DELIMITER ;

SELECT 'Таблица AuditLog и 10 триггеров созданы.' AS Сообщение;
