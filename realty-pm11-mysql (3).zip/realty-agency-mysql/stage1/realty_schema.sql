/* =====================================================================
   Учебная практика ПМ.11, этап 1
   Кейс-задача: «Информационная система риэлторского агентства «КлючДом»»
   Скрипт 1 из 4: создание базы данных и таблиц (DDL)
   СУБД: MySQL 8.0 (8.0.16 и новее — нужна проверка ограничений CHECK)
   ВНИМАНИЕ: скрипт пересоздаёт базу realty_pm11 с нуля.
   ===================================================================== */

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS realty_pm11;
CREATE DATABASE realty_pm11
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;

USE realty_pm11;

/* ---------------------------------------------------------------------
   Справочники
   --------------------------------------------------------------------- */

-- Районы города
CREATE TABLE Districts (
    DistrictID   INT          NOT NULL AUTO_INCREMENT,
    Name         VARCHAR(60)  NOT NULL,
    City         VARCHAR(60)  NOT NULL DEFAULT 'Москва',
    CONSTRAINT PK_Districts PRIMARY KEY (DistrictID),
    CONSTRAINT UQ_Districts_City_Name UNIQUE (City, Name)
) ENGINE = InnoDB;

-- Типы объектов недвижимости
CREATE TABLE PropertyTypes (
    TypeID        INT          NOT NULL AUTO_INCREMENT,
    Name          VARCHAR(50)  NOT NULL,
    IsResidential BOOLEAN      NOT NULL DEFAULT TRUE,
    CONSTRAINT PK_PropertyTypes PRIMARY KEY (TypeID),
    CONSTRAINT UQ_PropertyTypes_Name UNIQUE (Name)
) ENGINE = InnoDB;

-- Должности сотрудников
CREATE TABLE Positions (
    PositionID   INT            NOT NULL AUTO_INCREMENT,
    Title        VARCHAR(60)    NOT NULL,
    BaseSalary   DECIMAL(10,2)  NOT NULL,
    CONSTRAINT PK_Positions PRIMARY KEY (PositionID),
    CONSTRAINT UQ_Positions_Title UNIQUE (Title),
    CONSTRAINT CK_Positions_BaseSalary CHECK (BaseSalary > 0)
) ENGINE = InnoDB;

-- Характеристики (удобства) объектов: балкон, лифт, парковка...
CREATE TABLE Features (
    FeatureID    INT          NOT NULL AUTO_INCREMENT,
    Name         VARCHAR(60)  NOT NULL,
    CONSTRAINT PK_Features PRIMARY KEY (FeatureID),
    CONSTRAINT UQ_Features_Name UNIQUE (Name)
) ENGINE = InnoDB;

/* ---------------------------------------------------------------------
   Участники
   --------------------------------------------------------------------- */

-- Сотрудники агентства
CREATE TABLE Employees (
    EmployeeID      INT            NOT NULL AUTO_INCREMENT,
    LastName        VARCHAR(50)    NOT NULL,
    FirstName       VARCHAR(50)    NOT NULL,
    MiddleName      VARCHAR(50)    NULL,
    PositionID      INT            NOT NULL,
    Phone           VARCHAR(12)    NOT NULL,
    Email           VARCHAR(100)   NOT NULL,
    HireDate        DATE           NOT NULL DEFAULT (CURRENT_DATE),
    CommissionShare DECIMAL(5,2)   NOT NULL DEFAULT 0,
    IsActive        BOOLEAN        NOT NULL DEFAULT TRUE,
    CONSTRAINT PK_Employees PRIMARY KEY (EmployeeID),
    CONSTRAINT FK_Employees_Positions FOREIGN KEY (PositionID)
        REFERENCES Positions (PositionID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT UQ_Employees_Phone UNIQUE (Phone),
    CONSTRAINT UQ_Employees_Email UNIQUE (Email),
    CONSTRAINT CK_Employees_Phone CHECK (Phone REGEXP '^\\+7[0-9]{10}$'),
    CONSTRAINT CK_Employees_Email CHECK (Email LIKE '%_@_%._%'),
    CONSTRAINT CK_Employees_CommissionShare CHECK (CommissionShare BETWEEN 0 AND 100)
) ENGINE = InnoDB;

-- Клиенты (продавцы, покупатели, арендодатели, арендаторы)
CREATE TABLE Clients (
    ClientID      INT           NOT NULL AUTO_INCREMENT,
    LastName      VARCHAR(50)   NOT NULL,
    FirstName     VARCHAR(50)   NOT NULL,
    MiddleName    VARCHAR(50)   NULL,
    BirthDate     DATE          NOT NULL,
    Phone         VARCHAR(12)   NOT NULL,
    Email         VARCHAR(100)  NULL,
    RegisteredAt  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT PK_Clients PRIMARY KEY (ClientID),
    CONSTRAINT UQ_Clients_Phone UNIQUE (Phone),
    CONSTRAINT UQ_Clients_Email UNIQUE (Email),     -- в MySQL допускает несколько NULL
    CONSTRAINT CK_Clients_Phone CHECK (Phone REGEXP '^\\+7[0-9]{10}$'),
    CONSTRAINT CK_Clients_Email CHECK (Email IS NULL OR Email LIKE '%_@_%._%'),
    -- MySQL не разрешает CURRENT_DATE в CHECK, поэтому здесь только проверка
    -- правдоподобности даты; совершеннолетие проверяет процедура регистрации (этап 2)
    CONSTRAINT CK_Clients_BirthDate CHECK (BirthDate >= '1900-01-01')
) ENGINE = InnoDB;

/* ---------------------------------------------------------------------
   Объекты недвижимости
   --------------------------------------------------------------------- */

CREATE TABLE Properties (
    PropertyID     INT             NOT NULL AUTO_INCREMENT,
    OwnerClientID  INT             NOT NULL,   -- собственник
    EmployeeID     INT             NOT NULL,   -- ответственный агент
    TypeID         INT             NOT NULL,
    DistrictID     INT             NOT NULL,
    OfferType      VARCHAR(10)     NOT NULL,   -- продажа / аренда
    Address        VARCHAR(200)    NOT NULL,
    Area           DECIMAL(8,2)    NOT NULL,   -- общая площадь, м2
    Rooms          TINYINT         NULL,       -- NULL для участков и помещений без комнат
    Floor          SMALLINT        NULL,
    TotalFloors    SMALLINT        NULL,
    BuildYear      SMALLINT        NULL,
    Price          DECIMAL(14,2)   NOT NULL,   -- цена продажи или аренда в месяц, руб.
    Status         VARCHAR(20)     NOT NULL DEFAULT 'активен',
    ListedAt       DATE            NOT NULL DEFAULT (CURRENT_DATE),
    Description    VARCHAR(1000)   NULL,
    CONSTRAINT PK_Properties PRIMARY KEY (PropertyID),
    CONSTRAINT FK_Properties_Clients FOREIGN KEY (OwnerClientID)
        REFERENCES Clients (ClientID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Properties_Employees FOREIGN KEY (EmployeeID)
        REFERENCES Employees (EmployeeID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Properties_PropertyTypes FOREIGN KEY (TypeID)
        REFERENCES PropertyTypes (TypeID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Properties_Districts FOREIGN KEY (DistrictID)
        REFERENCES Districts (DistrictID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT UQ_Properties_Address UNIQUE (Address),
    CONSTRAINT CK_Properties_OfferType CHECK (OfferType IN ('продажа', 'аренда')),
    CONSTRAINT CK_Properties_Status CHECK (Status IN ('активен', 'забронирован', 'продан', 'сдан', 'снят')),
    -- проданным может быть только объект на продажу, сданным — только объект в аренду
    CONSTRAINT CK_Properties_StatusOffer CHECK (
        (OfferType = 'продажа' AND Status <> 'сдан') OR
        (OfferType = 'аренда'  AND Status <> 'продан')),
    CONSTRAINT CK_Properties_Area CHECK (Area > 0),
    CONSTRAINT CK_Properties_Rooms CHECK (Rooms IS NULL OR Rooms BETWEEN 0 AND 20),
    CONSTRAINT CK_Properties_Floors CHECK (
        (Floor IS NULL OR Floor >= -2) AND
        (TotalFloors IS NULL OR TotalFloors >= 1) AND
        (Floor IS NULL OR TotalFloors IS NULL OR Floor <= TotalFloors)),
    CONSTRAINT CK_Properties_BuildYear CHECK (BuildYear IS NULL OR BuildYear BETWEEN 1800 AND 2030),
    CONSTRAINT CK_Properties_Price CHECK (Price > 0)
) ENGINE = InnoDB;

-- Связующая таблица М:N «Объект — Характеристика»
CREATE TABLE PropertyFeatures (
    PropertyID  INT NOT NULL,
    FeatureID   INT NOT NULL,
    CONSTRAINT PK_PropertyFeatures PRIMARY KEY (PropertyID, FeatureID),
    CONSTRAINT FK_PropertyFeatures_Properties FOREIGN KEY (PropertyID)
        REFERENCES Properties (PropertyID)
        ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT FK_PropertyFeatures_Features FOREIGN KEY (FeatureID)
        REFERENCES Features (FeatureID)
        ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB;

/* ---------------------------------------------------------------------
   Операционные таблицы
   --------------------------------------------------------------------- */

-- Заявки клиентов на подбор объекта
CREATE TABLE Requests (
    RequestID    INT            NOT NULL AUTO_INCREMENT,
    ClientID     INT            NOT NULL,
    EmployeeID   INT            NULL,         -- агент может быть ещё не назначен
    OfferType    VARCHAR(10)    NOT NULL,     -- что ищет клиент: продажа (купить) / аренда (снять)
    TypeID       INT            NOT NULL,
    DistrictID   INT            NULL,         -- NULL = район не важен
    MinRooms     TINYINT        NULL,
    MinArea      DECIMAL(8,2)   NULL,
    MaxBudget    DECIMAL(14,2)  NOT NULL,
    Status       VARCHAR(15)    NOT NULL DEFAULT 'открыта',
    CreatedAt    DATE           NOT NULL DEFAULT (CURRENT_DATE),
    CONSTRAINT PK_Requests PRIMARY KEY (RequestID),
    CONSTRAINT FK_Requests_Clients FOREIGN KEY (ClientID)
        REFERENCES Clients (ClientID)
        ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT FK_Requests_Employees FOREIGN KEY (EmployeeID)
        REFERENCES Employees (EmployeeID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Requests_PropertyTypes FOREIGN KEY (TypeID)
        REFERENCES PropertyTypes (TypeID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Requests_Districts FOREIGN KEY (DistrictID)
        REFERENCES Districts (DistrictID)
        ON DELETE SET NULL ON UPDATE RESTRICT,
    CONSTRAINT CK_Requests_OfferType CHECK (OfferType IN ('продажа', 'аренда')),
    CONSTRAINT CK_Requests_Status CHECK (Status IN ('открыта', 'в работе', 'закрыта', 'отменена')),
    CONSTRAINT CK_Requests_MinRooms CHECK (MinRooms IS NULL OR MinRooms BETWEEN 0 AND 20),
    CONSTRAINT CK_Requests_MinArea CHECK (MinArea IS NULL OR MinArea > 0),
    CONSTRAINT CK_Requests_MaxBudget CHECK (MaxBudget > 0)
) ENGINE = InnoDB;

-- Показы объектов клиентам
CREATE TABLE Viewings (
    ViewingID       INT           NOT NULL AUTO_INCREMENT,
    PropertyID      INT           NOT NULL,
    ClientID        INT           NOT NULL,
    EmployeeID      INT           NOT NULL,
    ViewingDateTime DATETIME      NOT NULL,
    Result          VARCHAR(20)   NOT NULL DEFAULT 'запланирован',
    Comment         VARCHAR(500)  NULL,
    CONSTRAINT PK_Viewings PRIMARY KEY (ViewingID),
    CONSTRAINT FK_Viewings_Properties FOREIGN KEY (PropertyID)
        REFERENCES Properties (PropertyID)
        ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT FK_Viewings_Clients FOREIGN KEY (ClientID)
        REFERENCES Clients (ClientID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Viewings_Employees FOREIGN KEY (EmployeeID)
        REFERENCES Employees (EmployeeID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    -- агент не может проводить два показа в одно и то же время
    CONSTRAINT UQ_Viewings_Employee_Time UNIQUE (EmployeeID, ViewingDateTime),
    CONSTRAINT CK_Viewings_Result CHECK (Result IN ('запланирован', 'понравилось', 'не понравилось', 'отменён'))
) ENGINE = InnoDB;

-- Сделки (купля-продажа и аренда)
CREATE TABLE Deals (
    DealID           INT            NOT NULL AUTO_INCREMENT,
    PropertyID       INT            NOT NULL,
    ClientID         INT            NOT NULL,   -- покупатель / арендатор
    EmployeeID       INT            NOT NULL,   -- агент, проводивший сделку
    DealType         VARCHAR(10)    NOT NULL,
    DealDate         DATE           NOT NULL DEFAULT (CURRENT_DATE),
    Amount           DECIMAL(14,2)  NOT NULL,   -- цена договора (для аренды — плата в месяц)
    CommissionAmount DECIMAL(12,2)  NOT NULL DEFAULT 0,
    LeaseEndDate     DATE           NULL,       -- только для аренды
    Status           VARCHAR(15)    NOT NULL DEFAULT 'оформляется',
    CONSTRAINT PK_Deals PRIMARY KEY (DealID),
    CONSTRAINT FK_Deals_Properties FOREIGN KEY (PropertyID)
        REFERENCES Properties (PropertyID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Deals_Clients FOREIGN KEY (ClientID)
        REFERENCES Clients (ClientID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT FK_Deals_Employees FOREIGN KEY (EmployeeID)
        REFERENCES Employees (EmployeeID)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT CK_Deals_DealType CHECK (DealType IN ('продажа', 'аренда')),
    CONSTRAINT CK_Deals_Status CHECK (Status IN ('оформляется', 'завершена', 'расторгнута')),
    CONSTRAINT CK_Deals_Amount CHECK (Amount > 0),
    CONSTRAINT CK_Deals_Commission CHECK (CommissionAmount >= 0 AND CommissionAmount <= Amount),
    -- дата окончания аренды есть только у аренды и она позже даты сделки
    CONSTRAINT CK_Deals_LeaseEnd CHECK (
        (DealType = 'продажа' AND LeaseEndDate IS NULL) OR
        (DealType = 'аренда'  AND LeaseEndDate IS NOT NULL AND LeaseEndDate > DealDate))
) ENGINE = InnoDB;

-- Платежи по сделкам
CREATE TABLE Payments (
    PaymentID    INT            NOT NULL AUTO_INCREMENT,
    DealID       INT            NOT NULL,
    PaymentDate  DATE           NOT NULL DEFAULT (CURRENT_DATE),
    Amount       DECIMAL(14,2)  NOT NULL,
    Method       VARCHAR(20)    NOT NULL,
    Purpose      VARCHAR(30)    NOT NULL,
    CONSTRAINT PK_Payments PRIMARY KEY (PaymentID),
    CONSTRAINT FK_Payments_Deals FOREIGN KEY (DealID)
        REFERENCES Deals (DealID)
        ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT CK_Payments_Amount CHECK (Amount > 0),
    CONSTRAINT CK_Payments_Method CHECK (Method IN ('наличные', 'банковская карта', 'перевод', 'ипотека')),
    CONSTRAINT CK_Payments_Purpose CHECK (Purpose IN ('задаток', 'основной платёж', 'арендная плата', 'комиссия агентства'))
) ENGINE = InnoDB;

SELECT 'Структура базы данных realty_pm11 создана.' AS Сообщение;
