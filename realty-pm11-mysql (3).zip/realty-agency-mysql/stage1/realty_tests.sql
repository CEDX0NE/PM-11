/* =====================================================================
   Учебная практика ПМ.11, этап 1 — «Риэлторское агентство»
   Скрипт 4 из 4: проверка ограничений целостности и контрольные запросы
   СУБД: MySQL 8.0 (запускать в консоли mysql: source путь/к/файлу.sql)
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;
SET SQL_SAFE_UPDATES = 0;   -- безопасный режим обновлений мешает тестовым DELETE/UPDATE

/* ---------------------------------------------------------------------
   Часть 1. Проверка срабатывания ограничений.
   Вспомогательная процедура выполняет команду, которая намеренно нарушает
   одно ограничение, перехватывает ошибку и записывает результат в таблицу
   test_constraints. Любые изменения откатываются.
   Ожидаемый результат: во всех строках «ОТКЛОНЕНО» и «PASS».
   --------------------------------------------------------------------- */

DROP TABLE IF EXISTS test_constraints;
CREATE TABLE test_constraints (
    N           INT AUTO_INCREMENT PRIMARY KEY,
    Проверка    VARCHAR(120),
    ОжидаемаяОшибка INT,
    Результат   VARCHAR(20),
    Сообщение   VARCHAR(400),
    Статус      VARCHAR(4)
);

DROP PROCEDURE IF EXISTS t_expect_error;
DELIMITER $$
CREATE PROCEDURE t_expect_error(IN p_title VARCHAR(120), IN p_errno INT, IN p_sql TEXT)
BEGIN
    DECLARE v_no  INT;
    DECLARE v_msg TEXT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_no = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
        ROLLBACK;
        INSERT INTO test_constraints (Проверка, ОжидаемаяОшибка, Результат, Сообщение, Статус)
        VALUES (p_title, p_errno, 'ОТКЛОНЕНО', CONCAT(v_no, ': ', v_msg), IF(v_no = p_errno, 'PASS', 'FAIL'));
    END;

    START TRANSACTION;
    SET @t_sql = p_sql;
    PREPARE t_stmt FROM @t_sql;
    EXECUTE t_stmt;
    DEALLOCATE PREPARE t_stmt;
    ROLLBACK;
    INSERT INTO test_constraints (Проверка, ОжидаемаяОшибка, Результат, Сообщение, Статус)
    VALUES (p_title, p_errno, 'ПРИНЯТО (ошибка!)', NULL, 'FAIL');
END$$
DELIMITER ;

-- Коды ошибок MySQL: 3819 — нарушение CHECK, 1062 — дубликат UNIQUE,
-- 1452 — нет родительской строки (FK), 1451 — есть дочерние строки (FK), 1048 — NULL в NOT NULL

CALL t_expect_error('Отрицательная цена объекта', 3819,
    "INSERT INTO Properties (OwnerClientID, EmployeeID, TypeID, DistrictID, OfferType, Address, Area, Price)
     VALUES (1, 1, 1, 1, 'продажа', 'Тест, д. 1', 40, -100)");

CALL t_expect_error('Этаж 12 в 9-этажном доме', 3819,
    "INSERT INTO Properties (OwnerClientID, EmployeeID, TypeID, DistrictID, OfferType, Address, Area, Floor, TotalFloors, Price)
     VALUES (1, 1, 1, 1, 'продажа', 'Тест, д. 2', 40, 12, 9, 10000000)");

CALL t_expect_error('Статус «сдан» у объекта на продажу', 3819,
    "UPDATE Properties SET Status = 'сдан' WHERE PropertyID = 21");

CALL t_expect_error('Несуществующий статус заявки', 3819,
    "UPDATE Requests SET Status = 'потеряна' WHERE RequestID = 1");

CALL t_expect_error('Дата рождения клиента раньше 1900 года', 3819,
    "INSERT INTO Clients (LastName, FirstName, BirthDate, Phone) VALUES ('Старый', 'Тест', '1850-01-01', '+79990000001')");

CALL t_expect_error('Телефон в неверном формате', 3819,
    "INSERT INTO Clients (LastName, FirstName, BirthDate, Phone) VALUES ('Тестов', 'Тест', '1990-01-01', '8-999-123')");

CALL t_expect_error('Дубликат телефона клиента', 1062,
    "INSERT INTO Clients (LastName, FirstName, BirthDate, Phone)
     SELECT 'Двойник', 'Тест', '1990-01-01', Phone FROM Clients WHERE ClientID = 1");

CALL t_expect_error('Дубликат e-mail клиента', 1062,
    "INSERT INTO Clients (LastName, FirstName, BirthDate, Phone, Email)
     SELECT 'Двойник', 'Тест', '1990-01-01', '+79990000002', Email FROM Clients WHERE ClientID = 1");

CALL t_expect_error('Сделка по несуществующему объекту', 1452,
    "INSERT INTO Deals (PropertyID, ClientID, EmployeeID, DealType, Amount) VALUES (9999, 1, 1, 'продажа', 1000000)");

CALL t_expect_error('Удаление района, в котором есть объекты', 1451,
    "DELETE FROM Districts WHERE DistrictID = 1");

CALL t_expect_error('Дата окончания аренды у сделки купли-продажи', 3819,
    "INSERT INTO Deals (PropertyID, ClientID, EmployeeID, DealType, Amount, LeaseEndDate)
     VALUES (21, 1, 3, 'продажа', 70000000, '2027-01-01')");

CALL t_expect_error('Два показа агента в одно и то же время', 1062,
    "INSERT INTO Viewings (PropertyID, ClientID, EmployeeID, ViewingDateTime)
     SELECT 22, 1, EmployeeID, ViewingDateTime FROM Viewings WHERE ViewingID = 1");

CALL t_expect_error('Объект без адреса (NULL)', 1048,
    "INSERT INTO Properties (OwnerClientID, EmployeeID, TypeID, DistrictID, OfferType, Address, Area, Price)
     VALUES (1, 1, 1, 1, 'продажа', NULL, 40, 10000000)");

SELECT N, Проверка, ОжидаемаяОшибка, Результат, Сообщение, Статус FROM test_constraints ORDER BY N;

DROP PROCEDURE IF EXISTS t_expect_error;

/* ---------------------------------------------------------------------
   Часть 2. Проверка DEFAULT и каскадного удаления (ON DELETE CASCADE).
   Выполняется в транзакции и откатывается — данные не меняются.
   --------------------------------------------------------------------- */
START TRANSACTION;

INSERT INTO Properties (OwnerClientID, EmployeeID, TypeID, DistrictID, OfferType, Address, Area, Rooms, Price)
VALUES (1, 4, 1, 9, 'продажа', 'ул. Братиславская, д. 99, кв. 1 (тест)', 33, 1, 9000000);

SET @NewID = LAST_INSERT_ID();
INSERT INTO PropertyFeatures (PropertyID, FeatureID) VALUES (@NewID, 1), (@NewID, 2);

-- DEFAULT: статус «активен» и сегодняшняя дата размещения подставились автоматически
SELECT PropertyID, Status AS `Статус (DEFAULT)`, ListedAt AS `Дата размещения (DEFAULT)`
FROM Properties WHERE PropertyID = @NewID;

SELECT COUNT(*) AS `Характеристик до удаления` FROM PropertyFeatures WHERE PropertyID = @NewID;
DELETE FROM Properties WHERE PropertyID = @NewID;
SELECT COUNT(*) AS `Характеристик после удаления (CASCADE)` FROM PropertyFeatures WHERE PropertyID = @NewID;

ROLLBACK;

/* ---------------------------------------------------------------------
   Часть 3. Контрольные SELECT-запросы с соединением таблиц
   --------------------------------------------------------------------- */

-- Запрос 1. Квартиры на продажу до 25 млн руб. с районом, агентом и удобствами
--           (Properties + PropertyTypes + Districts + Employees + PropertyFeatures + Features)
SELECT
    p.PropertyID                                         AS `№`,
    d.Name                                               AS Район,
    p.Address                                            AS Адрес,
    p.Rooms                                              AS Комнат,
    p.Area                                               AS `Площадь, м2`,
    p.Price                                              AS `Цена, руб.`,
    CONCAT(e.LastName, ' ', e.FirstName)                 AS Агент,
    GROUP_CONCAT(f.Name ORDER BY f.Name SEPARATOR ', ')  AS Удобства
FROM Properties            AS p
JOIN PropertyTypes         AS t  ON t.TypeID      = p.TypeID
JOIN Districts             AS d  ON d.DistrictID  = p.DistrictID
JOIN Employees             AS e  ON e.EmployeeID  = p.EmployeeID
LEFT JOIN PropertyFeatures AS pf ON pf.PropertyID = p.PropertyID
LEFT JOIN Features         AS f  ON f.FeatureID   = pf.FeatureID
WHERE p.OfferType = 'продажа'
  AND p.Status    = 'активен'
  AND t.Name      = 'Квартира'
  AND p.Price    <= 25000000
GROUP BY p.PropertyID, d.Name, p.Address, p.Rooms, p.Area, p.Price, e.LastName, e.FirstName
ORDER BY p.Price;

-- Запрос 2. Журнал завершённых сделок: продавец (собственник), покупатель, агент
SELECT
    dl.DealID                                            AS `№ сделки`,
    dl.DealDate                                          AS Дата,
    dl.DealType                                          AS Тип,
    p.Address                                            AS Объект,
    CONCAT(own.LastName, ' ', LEFT(own.FirstName, 1), '.') AS Собственник,
    CONCAT(cl.LastName,  ' ', LEFT(cl.FirstName, 1),  '.') AS `Покупатель / арендатор`,
    e.LastName                                           AS Агент,
    dl.Amount                                            AS Сумма,
    dl.CommissionAmount                                  AS Комиссия
FROM Deals      AS dl
JOIN Properties AS p   ON p.PropertyID  = dl.PropertyID
JOIN Clients    AS own ON own.ClientID  = p.OwnerClientID
JOIN Clients    AS cl  ON cl.ClientID   = dl.ClientID
JOIN Employees  AS e   ON e.EmployeeID  = dl.EmployeeID
WHERE dl.Status = 'завершена'
ORDER BY dl.DealDate;

-- Запрос 3. Сверка оплат: сколько поступило по каждой сделке купли-продажи
SELECT
    dl.DealID                          AS `№ сделки`,
    p.Address                          AS Объект,
    dl.Amount                          AS `Цена договора`,
    SUM(pay.Amount)                    AS Оплачено,
    dl.Amount - SUM(pay.Amount)        AS Остаток,
    dl.Status                          AS `Статус сделки`
FROM Deals      AS dl
JOIN Properties AS p   ON p.PropertyID = dl.PropertyID
JOIN Payments   AS pay ON pay.DealID   = dl.DealID
WHERE dl.DealType = 'продажа'
  AND pay.Purpose IN ('задаток', 'основной платёж')
GROUP BY dl.DealID, p.Address, dl.Amount, dl.Status
ORDER BY Остаток DESC, dl.DealID;

-- Запрос 4. Подбор объектов под открытые заявки клиентов
SELECT
    r.RequestID                              AS `№ заявки`,
    CONCAT(c.LastName, ' ', c.FirstName)     AS Клиент,
    r.OfferType                              AS Ищет,
    t.Name                                   AS `Тип объекта`,
    r.MaxBudget                              AS Бюджет,
    p.Address                                AS `Подходящий объект`,
    p.Price                                  AS Цена
FROM Requests      AS r
JOIN Clients       AS c ON c.ClientID = r.ClientID
JOIN PropertyTypes AS t ON t.TypeID   = r.TypeID
JOIN Properties    AS p ON p.TypeID    = r.TypeID
                       AND p.OfferType = r.OfferType
                       AND p.Status    = 'активен'
                       AND p.Price    <= r.MaxBudget
                       AND (r.DistrictID IS NULL OR p.DistrictID = r.DistrictID)
                       AND (r.MinRooms   IS NULL OR p.Rooms     >= r.MinRooms)
                       AND (r.MinArea    IS NULL OR p.Area      >= r.MinArea)
WHERE r.Status IN ('открыта', 'в работе')
ORDER BY r.RequestID, p.Price;

-- Запрос 5. Представления: результативность агентов, выручка по месяцам, витрина
SELECT * FROM v_AgentPerformance ORDER BY КомиссияАгентства DESC;
SELECT * FROM v_MonthlyRevenue   ORDER BY Год, Месяц;
SELECT * FROM v_ActiveListings   ORDER BY ТипПредложения, Цена;
