/* =====================================================================
   Учебная практика ПМ.11, этап 1 — «Риэлторское агентство»
   Скрипт 2 из 4: индексы и представления
   СУБД: MySQL 8.0
   ===================================================================== */

SET NAMES utf8mb4;
USE realty_pm11;

/* ---------------------------------------------------------------------
   Индексы
   В InnoDB первичный ключ — кластерный индекс, ограничения UNIQUE создают
   уникальные индексы, а для каждого внешнего ключа MySQL сам создаёт индекс
   (если подходящего ещё нет). Ниже — составные индексы под частые запросы.
   Во вторичный индекс InnoDB всегда неявно входит первичный ключ.
   --------------------------------------------------------------------- */

-- 1. Поиск объектов по параметрам заявки:
--    «квартиры на продажу, активные, в районе N, до такой-то цены»
CREATE INDEX IX_Properties_Search
    ON Properties (OfferType, Status, DistrictID, TypeID, Price);

-- 2. Сортировка и фильтрация объектов по цене
CREATE INDEX IX_Properties_Price
    ON Properties (Price);

-- 3. Отчёты по сделкам за период (выручка по месяцам, по агентам) —
--    покрывающий индекс: запрос читает только его
CREATE INDEX IX_Deals_DealDate
    ON Deals (DealDate, Status, EmployeeID, Amount, CommissionAmount);

-- 4. Поиск клиента по фамилии и имени
CREATE INDEX IX_Clients_FullName
    ON Clients (LastName, FirstName);

-- 5. Расписание показов по объекту
CREATE INDEX IX_Viewings_Property_Date
    ON Viewings (PropertyID, ViewingDateTime);

-- 6. Рабочий список заявок: открытые / в работе
CREATE INDEX IX_Requests_Status
    ON Requests (Status, OfferType, TypeID);

-- 7. Платежи по сделке в хронологическом порядке
CREATE INDEX IX_Payments_Deal_Date
    ON Payments (DealID, PaymentDate);

/* ---------------------------------------------------------------------
   Представления
   --------------------------------------------------------------------- */

-- 1. Витрина актуальных предложений (для сайта и менеджеров)
CREATE OR REPLACE VIEW v_ActiveListings AS
SELECT
    p.PropertyID                                   AS PropertyID,
    p.OfferType                                    AS ТипПредложения,
    t.Name                                         AS ТипОбъекта,
    d.Name                                         AS Район,
    p.Address                                      AS Адрес,
    p.Area                                         AS Площадь,
    p.Rooms                                        AS Комнат,
    p.Price                                        AS Цена,
    CAST(ROUND(p.Price / p.Area, 0) AS DECIMAL(14,0)) AS ЦенаЗаМ2,
    CONCAT(e.LastName, ' ', e.FirstName)           AS Агент,
    e.Phone                                        AS ТелефонАгента,
    p.ListedAt                                     AS ДатаРазмещения
FROM Properties    AS p
JOIN PropertyTypes AS t ON t.TypeID     = p.TypeID
JOIN Districts     AS d ON d.DistrictID = p.DistrictID
JOIN Employees     AS e ON e.EmployeeID = p.EmployeeID
WHERE p.Status = 'активен';

-- 2. Результативность агентов (только завершённые сделки)
CREATE OR REPLACE VIEW v_AgentPerformance AS
SELECT
    e.EmployeeID                                                AS EmployeeID,
    CONCAT(e.LastName, ' ', e.FirstName)                        AS Агент,
    pos.Title                                                   AS Должность,
    COUNT(dl.DealID)                                            AS ЧислоСделок,
    SUM(CASE WHEN dl.DealType = 'продажа' THEN 1 ELSE 0 END)    AS Продаж,
    SUM(CASE WHEN dl.DealType = 'аренда'  THEN 1 ELSE 0 END)    AS Аренд,
    IFNULL(SUM(dl.CommissionAmount), 0)                         AS КомиссияАгентства,
    CAST(IFNULL(SUM(dl.CommissionAmount), 0) * e.CommissionShare / 100
         AS DECIMAL(12,2))                                      AS ДоляАгента
FROM Employees      AS e
JOIN Positions      AS pos ON pos.PositionID = e.PositionID
LEFT JOIN Deals     AS dl  ON dl.EmployeeID  = e.EmployeeID
                          AND dl.Status      = 'завершена'
WHERE e.CommissionShare > 0
GROUP BY e.EmployeeID, e.LastName, e.FirstName, pos.Title, e.CommissionShare;

-- 3. Выручка агентства (комиссия) по месяцам
CREATE OR REPLACE VIEW v_MonthlyRevenue AS
SELECT
    YEAR(dl.DealDate)            AS Год,
    MONTH(dl.DealDate)           AS Месяц,
    COUNT(*)                     AS ЧислоСделок,
    SUM(dl.Amount)               AS ОбъёмСделок,
    SUM(dl.CommissionAmount)     AS Выручка
FROM Deals AS dl
WHERE dl.Status = 'завершена'
GROUP BY YEAR(dl.DealDate), MONTH(dl.DealDate);

SELECT 'Индексы и представления созданы.' AS Сообщение;
