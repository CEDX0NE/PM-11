# База данных «Риэлторское агентство» — MySQL 8.0

Нужен MySQL 8.0.16 или новее (с этой версии работают ограничения CHECK).
Запуск из PowerShell (оператор `<` в PowerShell не работает, поэтому через source):

    mysql -u root -p --default-character-set=utf8mb4
    mysql> source C:/путь/к/stage1/realty_schema.sql

Пути пиши с прямыми слэшами `/`. Консоль mysql понимает DELIMITER, поэтому процедуры этапа 2 тоже запускай через неё.
Кодировка файлов — UTF-8.

## Этап 1 (stage1)
1. `realty_schema.sql` — пересоздаёт базу realty_pm11 и 12 таблиц
2. `realty_indexes_views.sql` — индексы и 3 представления
3. `realty_data.sql` — тестовые данные (259 строк)
4. `realty_tests.sql` — 13 проверок ограничений (таблица test_constraints, всё должно быть PASS) и контрольные запросы

## Этап 2 (stage2)
1. `realty_procedures.sql` — таблица ErrorLog и 28 процедур (можно запускать повторно)
2. `realty_procedures_tests.sql` — 48 автотестов; итог — таблица test_results и строка «Всего / Пройдено / Не пройдено».
   Процедуры выборки выводят свои результаты отдельными вкладками, итоговые таблицы — последние.

Тестам этапа 2 нужны исходные данные этапа 1: если база менялась, перезапусти скрипты этапа 1.

## Этап 3 — пользовательские функции
В консоли mysql (файл содержит DELIMITER, в VS Code не запустится):
    source C:/путь/stage3/realty_functions.sql
Затем тесты (можно в консоли или в VS Code):
    source C:/путь/stage3/realty_functions_tests.sql
Ожидается: 35 из 35 PASS. После этого повторно запустите stage2/realty_procedures_tests.sql — процедуры этапа 2 изменены (используют функции) и должны проходить как раньше.

## Этап 4 — триггеры (stage4)
В консоли mysql (файлы содержат DELIMITER, в VS Code не запустятся):
    source C:/путь/stage4/realty_triggers.sql
    source C:/путь/stage4/realty_triggers_tests.sql
1. `realty_triggers.sql` — таблица аудита AuditLog и 10 триггеров:
   6 триггеров аудита (Properties, Deals), 3 триггера бизнес-правил
   (интервал показов агента, платежи по сделке), запрет удаления сотрудника.
2. `realty_triggers_tests.sql` — 22 автотеста (таблица test_triggers); ожидается 22 из 22 PASS.
После установки триггеров тесты этапов 2 и 3 по-прежнему проходят (48/48 и 35/35).
